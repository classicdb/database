-- Thanks danielsreichenbach for fixing
-- Updated Blackwing lair / UBRS reload at respawn exit to Blackrock Spire entrance
UPDATE `areatrigger_teleport` SET `target_map` = 0, `target_position_x` = -7524.19, `target_position_y` = -1230.13, `target_position_z` = 285.743, `target_orientation` = 2.09544 WHERE `id` = 3728;
