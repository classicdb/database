-- Recipe for Mighty Troll's Blood Elixir should be removed from Sylvanna Forestmoon, ordinary Expert Alchemist in Darnassus
-- This recipe is intended to be reward from NPC Henry Stern, who resides in Razorfen Dawns instance.
-- Source: http://www.wowhead.com/spell=3451#taught-by-item
DELETE FROM `npc_trainer` WHERE `entry` = 11042 AND `spell` = 13030;