-- Added support from SD2 for quests 2118 (Plagued Lands) and 2904 (A Fine Mess)
UPDATE creature_template SET ScriptName='npc_rabid_bear' WHERE entry=2164;
UPDATE creature_template SET ScriptName='npc_kernobee' WHERE entry=7850;