-- Updated scale of creatures 16030 (Maggot)
-- as they were way too big
UPDATE `creature_template` SET `scale` = 0 WHERE `entry` = 16030;
