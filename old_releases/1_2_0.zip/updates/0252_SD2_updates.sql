-- Added support from SD2 for quests 660, 1222 and 1270
UPDATE creature_template SET ScriptName='npc_kinelory' WHERE entry=2713;
UPDATE creature_template SET ScriptName='npc_stinky_ignatz' WHERE entry=4880;
