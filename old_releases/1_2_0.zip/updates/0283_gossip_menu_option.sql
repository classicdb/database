-- Typo, replace "pald" with "paid"
UPDATE `gossip_menu_option` SET `option_text` = "I have paid your price, "
    "Gloom'rel. Now teach me your secrets!" WHERE `menu_id` = 1945 and `id` = 1;
