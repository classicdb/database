-- Updated size of creature 2348 (Elder Moss Creeper) as it was bigger than other spiders around
UPDATE `creature_template` SET `scale` = 0 WHERE entry = 2348;
