-- Fix typo, replace "guage" with "gauge"
UPDATE `page_text` SET `text` = "Hi Felnok! My studies in the Burning Steppes "
    "are proceeding splendidly. And I owe $N a lot for all $ghis:her; help! "
    "Here's what I need to continue: A steelcoil bumber-bitzel A 17-gauge "
    "ice-spanner 12 pounds of duck feathers A jar of that glue you make Thanks "
    "a lot Felnok, and when we see each other again remind me not to put coal "
    "in your boots! -Tinkee" where `entry` = 1710;
