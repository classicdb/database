


-- --------------

SET @CHORUSH := '14324'; -- Cho'Rush the Observer

UPDATE `creature` SET `position_x`='833.9951', `position_y`='489.5435', `position_z`='37.40153', `orientation`='3.211406', `MovementType`='0' WHERE `id`=@CHORUSH;
