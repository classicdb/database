-- Setting movement type to waypoint based for npc #guid 49525 (Alaindia)
--
UPDATE `creature`
SET `MovementType` = 2, `position_x` = 9714.28, `position_y` = 2525.74, `position_z` = 1335.68 
WHERE `id` = 3562;
