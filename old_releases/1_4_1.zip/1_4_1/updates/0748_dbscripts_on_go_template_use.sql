
-- ---------------------------------------

DELETE FROM `dbscripts_on_go_template_use` WHERE `id` IN ('17156', '17157');
INSERT INTO `dbscripts_on_go_template_use` (`id`, `delay`, `command`, `datalong`, `datalong2`, `buddy_entry`, `search_radius`, `data_flags`, `dataint`, `dataint2`, `dataint3`, `dataint4`, `x`, `y`, `z`, `o`, `comments`) VALUES
('17156', '0', '11', '0', '15', '150138', '10', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Stonewrought Pass - Northern Door Lever'),
('17157', '0', '11', '0', '15', '150137', '10', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Stonewrought Pass - Southern Door Lever');
