
-- --------------------------

UPDATE `areatrigger_teleport` SET `required_quest_done`='9378' WHERE `id`='4055';

