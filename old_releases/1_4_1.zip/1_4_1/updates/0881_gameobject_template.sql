


-- -------------------------

UPDATE `gameobject_template` SET `faction`='1375' WHERE `entry` IN ('97700', '104600');
