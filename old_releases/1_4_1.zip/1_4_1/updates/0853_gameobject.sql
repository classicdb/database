


-- ----------------

UPDATE `gameobject` SET `position_x`='129.4811', `position_y`='544.9671', `position_z`='-48.46632', `orientation`='0', `rotation2`='0.7253742', `rotation3`='0.6883547', `spawntimesecs`='0', `animprogress`='100' WHERE `id`='179517';
