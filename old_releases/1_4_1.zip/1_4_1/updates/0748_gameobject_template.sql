
-- -------------------------

UPDATE `gameobject_template` SET `flags`='34' WHERE `entry`='150138';
