


-- -------------------------

UPDATE `gameobject_template` SET `flags`='34', `size`='1.482917' WHERE `entry`='177217';
UPDATE `gameobject_template` SET `flags`='34' WHERE `entry`='177219';
UPDATE `gameobject_template` SET `faction`='114' WHERE `entry`='179549';
UPDATE `gameobject_template` SET `size`='1.02' WHERE `entry`='179550';
UPDATE `gameobject_template` SET `size`='0.465763' WHERE `entry`='177221';
