


-- -------------------------

UPDATE `item_template` SET `area`='2557', `Map`='429' WHERE `entry`='18268';
UPDATE `item_template` SET `area`='2557', `Map`='429' WHERE `entry`='18266';
