


-- ---------------------

UPDATE `areatrigger_teleport` SET `required_level`='10' WHERE `id`='78';
