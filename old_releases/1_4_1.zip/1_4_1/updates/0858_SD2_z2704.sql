-- Removed quest 9180 - not available in classic
UPDATE creature_template SET ScriptName='' WHERE entry=10181;
