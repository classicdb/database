


-- ---------------------------------

DELETE FROM `creature_questrelation` WHERE `quest`='1318';
