UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3; -- Flesh Eater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6; -- Kobold Vermin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 30; -- Forest Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 36; -- Harvest Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 38; -- Defias Thug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 40; -- Kobold Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 43; -- Mine Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 46; -- Murloc Forager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 48; -- Skeletal Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 54; -- Corina Steele
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 60; -- Ruklar the Trapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 61; -- Thuros Lightfingers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 66; -- Tharynn Bouden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 68; -- Stormwind City Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 69; -- Timber Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 74; -- Kurran Steele
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 78; -- Janos Hammerknuckle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 79; -- Narg the Taskmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 80; -- Kobold Laborer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 92; -- Rock Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 94; -- Defias Cutpurse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 95; -- Defias Smuggler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 97; -- Riverpaw Runt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 98; -- Riverpaw Taskmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 99; -- Morgaine the Sly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 103; -- Garrick Padfoot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 113; -- Stonetusk Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 114; -- Harvest Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 115; -- Harvest Reaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 116; -- Defias Bandit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 117; -- Riverpaw Gnoll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 118; -- Prowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 121; -- Defias Pathstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 122; -- Defias Highwayman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 123; -- Riverpaw Mongrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 124; -- Riverpaw Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 125; -- Riverpaw Overseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 126; -- Murloc Coastrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 127; -- Murloc Tidehunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 151; -- Brog Hamfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 152; -- Brother Danil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 154; -- Greater Fleshripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 157; -- Goretusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 167; -- Morhan Coppertongue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 171; -- Murloc Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 190; -- Dermot Johns
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 193; -- Blue Dragonspawn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 196; -- Eagan Peltskinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 197; -- Marshal McBride
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 198; -- Khelden Bremen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 199; -- Young Fleshripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 202; -- Skeletal Horror
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 203; -- Skeletal Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 205; -- Nightbane Dark Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 206; -- Nightbane Vile Fang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 210; -- Bone Chewer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 212; -- Splinter Fist Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 213; -- Starving Dire Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 215; -- Defias Night Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 217; -- Venom Web Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 218; -- Grave Robber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 222; -- Nillen Andemar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 223; -- Dan Golthas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 225; -- Gavin Gnarltree
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 226; -- Morg Gnarltree
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 227; -- Mabel Solaj
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 228; -- Avette Fellwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 232; -- Farmer Ray
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 233; -- Farmer Saldean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 234; -- Gryan Stoutmantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 235; -- Salma Saldean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 237; -- Farmer Furlbrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 238; -- Verna Furlbrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 239; -- Grimbooze Thunderbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 240; -- Marshal Dughan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 241; -- Remy "Two Times"
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 244; -- Ma Stonefield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 246; -- "Auntie" Bernice Stonefield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 247; -- Billy Maclure
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 248; -- Gramma Stonefield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 250; -- Pa Maclure
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 251; -- Maybell Maclure
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 252; -- Tommy Joe Stonefield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 253; -- William Pestle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 255; -- Gerard Tiller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 257; -- Kobold Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 258; -- Joshua Maclure
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 261; -- Guard Thomas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 263; -- Lord Ello Ebonlocke
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 264; -- Commander Althea Ebonlocke
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 265; -- Madame Eva
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 266; -- Wiley the Black
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 267; -- Clerk Daltry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 268; -- Sirra Von'Indi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 269; -- Role Dreuger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 270; -- Councilman Millstipe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 271; -- Ambassador Berrybuck
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 272; -- Chef Grual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 273; -- Tavernkeep Smitts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 274; -- Barkeep Hann
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 275; -- Whit Wantmal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 276; -- Viktori Prism'Antras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 277; -- Roberto Pupellyverbos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 278; -- Sara Timberlain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 279; -- Morgan Pestle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 285; -- Murloc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 288; -- Jitters
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 289; -- Abercrombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 294; -- Marshal Haggard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 295; -- Innkeeper Farley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 299; -- Young Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 300; -- Zzarc' Vul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 302; -- Blind Mary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 311; -- Sven Yorgen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 313; -- Theocritus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 315; -- Stalvan Mistmantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 325; -- Hogan Ference
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 327; -- Goldtooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 328; -- Zaldimar Wefhellt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 330; -- Princess
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 332; -- Master Mathias Shaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 334; -- Gath'Ilzogg
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 335; -- Singe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 340; -- Kendor Kabonka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 341; -- Foreman Oslow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 342; -- Martie Jainrose
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 343; -- Chef Breanna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 344; -- Magistrate Solomon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 345; -- Bellygrub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 346; -- Barkeep Daniels
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 347; -- Grizzle Halfmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 348; -- Zem Leeward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 349; -- Corporal Keeshan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 352; -- Dungar Longdrink
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 372; -- Karm Ironquill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 374; -- Cog Glitzspinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 375; -- Priestess Anetta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 377; -- Priestess Josetta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 379; -- Darcy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 381; -- Dockmaster Baren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 382; -- Marshal Marris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 383; -- Jason Mathers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 384; -- Katie Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 385; -- Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 390; -- Porcine Entourage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 391; -- Old Murk-Eye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 392; -- Captain Grayson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 395; -- Markus
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 397; -- Morganth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 415; -- Verner Osgood
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 416; -- Imp
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 417; -- Felhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 422; -- Murloc Flesheater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 423; -- Redridge Mongrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 424; -- Redridge Poacher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 426; -- Redridge Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 428; -- Dire Condor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 429; -- Shadowhide Darkweaver
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 430; -- Redridge Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 431; -- Shadowhide Slayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 432; -- Shadowhide Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 433; -- Shadowhide Gnoll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 434; -- Rabid Shadowhide Gnoll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 435; -- Blackrock Champion
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 436; -- Blackrock Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 437; -- Blackrock Renegade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 440; -- Blackrock Grunt
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 441; -- Black Dragon Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 442; -- Tarantula
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 445; -- Redridge Alpha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 446; -- Redridge Basher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 448; -- Hogger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 449; -- Defias Knuckleduster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 452; -- Riverpaw Bandit
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 453; -- Riverpaw Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 454; -- Young Goretusk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 456; -- Murloc Minor Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 458; -- Murloc Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 459; -- Drusilla La Salle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 460; -- Alamar Grimm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 464; -- Guard Parker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 465; -- Barkeep Dobbins
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 466; -- General Marcus Jonathan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 467; -- The Defias Traitor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 468; -- Town Crier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 469; -- Lieutenant Doren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 471; -- Mother Fang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 472; -- Fedfennel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 473; -- Morgan the Collector
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 474; -- Defias Rogue Wizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 475; -- Kobold Tunneler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 476; -- Kobold Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 478; -- Riverpaw Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 480; -- Rusty Harvest Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 481; -- Defias Footpad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 482; -- Elling Trias
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 483; -- Elaine Trias
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 485; -- Blackrock Outrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 486; -- Tharil'zun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 487; -- Protector Bialon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 488; -- Protector Weaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 489; -- Protector Dutfield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 490; -- Protector Gariel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 491; -- Quartermaster Lewis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 494; -- Watcher Bukouris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 495; -- Watcher Keefer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 499; -- Watcher Paige
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 500; -- Riverpaw Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 501; -- Riverpaw Herbalist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 502; -- Benny Blaanco
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 503; -- Lord Malathrom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 504; -- Defias Trapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 505; -- Greater Tarantula
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 506; -- Sergeant Brashclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 511; -- Insane Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 513; -- Murloc Netter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 514; -- Smith Argus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 515; -- Murloc Raider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 517; -- Murloc Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 518; -- Yowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 519; -- Slark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 520; -- Brack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 522; -- Mor'Ladim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 523; -- Thor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 524; -- Rockhide Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 525; -- Mangy Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 531; -- Skeletal Fiend
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 533; -- Nightbane Shadow Weaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 534; -- Nefaru
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 539; -- Pygmy Venom Web Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 543; -- Nalesette Wildbringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 544; -- Murloc Nightcrawler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 545; -- Murloc Tidecaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 547; -- Great Goretusk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 548; -- Murloc Minor Tidecaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 550; -- Defias Messenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 565; -- Rabid Dire Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 568; -- Shadowhide Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 569; -- Green Recluse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 570; -- Brain Eater
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 572; -- Leprithus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 573; -- Foe Reaper 4000
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 574; -- Naraxis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 575; -- Fire Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 576; -- Watcher Ladimore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 578; -- Murloc Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 579; -- Shadowhide Assassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 580; -- Redridge Drudger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 582; -- Old Blanchy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 587; -- Bloodscalp Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 588; -- Bloodscalp Scout
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 589; -- Defias Pillager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 590; -- Defias Looter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 594; -- Defias Henchman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 595; -- Bloodscalp Hunter
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 596; -- Brainwashed Noble
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 597; -- Bloodscalp Berserker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 598; -- Defias Miner
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 599; -- Marisa du'Paige
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 604; -- Plague Spreader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 615; -- Blackrock Tracker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 616; -- Chatter
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 619; -- Defias Conjurer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 620; -- Chicken
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 622; -- Goblin Engineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 623; -- Skeletal Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 624; -- Undead Excavator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 625; -- Undead Dynamiter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 626; -- Foreman Thistlenettle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 628; -- Black Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 633; -- Elaine Carevin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 634; -- Defias Overseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 636; -- Defias Blackguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 639; -- Edwin VanCleef
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 641; -- Goblin Woodcarver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 642; -- Sneed's Shredder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 644; -- Rhahk'Zor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 645; -- Cookie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 646; -- Mr. Smite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 647; -- Captain Greenskin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 657; -- Defias Pirate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 658; -- Sten Stoutarm
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 660; -- Bloodscalp Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 661; -- Jonathan Carevin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 663; -- Calor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 664; -- Benjamin Carevin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 667; -- Skullsplitter Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 669; -- Skullsplitter Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 670; -- Skullsplitter Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 671; -- Bloodscalp Headhunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 672; -- Skullsplitter Spiritchaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 674; -- Venture Co. Strip Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 675; -- Venture Co. Foreman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 676; -- Venture Co. Surveyor
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 677; -- Venture Co. Tinkerer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 678; -- Mosh'Ogg Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 679; -- Mosh'Ogg Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 680; -- Mosh'Ogg Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 681; -- Young Stranglethorn Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 682; -- Stranglethorn Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 683; -- Young Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 684; -- Shadowmaw Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 685; -- Stranglethorn Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 686; -- Lashtail Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 687; -- Jungle Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 688; -- Stone Maw Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 689; -- Crystal Spine Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 690; -- Cold Eye Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 691; -- Lesser Water Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 694; -- Bloodscalp Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 696; -- Skullsplitter Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 697; -- Bloodscalp Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 698; -- Bloodscalp Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 699; -- Bloodscalp Beastmaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 701; -- Bloodscalp Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 702; -- Bloodscalp Scavenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 703; -- Lieutenant Fangore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 704; -- Ragged Timber Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 705; -- Ragged Young Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 706; -- Frostmane Troll Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 707; -- Rockjaw Trogg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 708; -- Small Crag Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 709; -- Mosh'Ogg Warmonger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 710; -- Mosh'Ogg Spellcrafter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 711; -- Ardo Dirtpaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 712; -- Redridge Thrasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 713; -- Balir Frosthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 714; -- Talin Keeneye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 715; -- Hemet Nesingwary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 716; -- Barnil Stonepot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 717; -- Ajeck Rouack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 718; -- Sir S. J. Erlgadin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 721; -- Rabbit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 724; -- Burly Rockjaw Trogg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 727; -- Ironforge Mountaineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 728; -- Bhag'thera
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 729; -- Sin'Dall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 730; -- Tethis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 731; -- King Bangalash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 732; -- Murloc Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 733; -- Sergeant Yohwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 734; -- Corporal Bluth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 735; -- Murloc Streamrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 736; -- Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 737; -- Kebok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 738; -- Private Thorsen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 739; -- Brother Nimetz
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 740; -- Adolescent Whelp
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 741; -- Dreaming Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 742; -- Green Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 743; -- Wyrmkin Dreamwalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 744; -- Green Scalebane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 745; -- Scalebane Captain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 746; -- Elder Dragonkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 747; -- Marsh Murloc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 750; -- Marsh Inkspewer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 751; -- Marsh Flesheater
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 752; -- Marsh Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 754; -- Rebel Watchman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 755; -- Lost One Mudlurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 756; -- Skullsplitter Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 757; -- Lost One Fisherman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 759; -- Lost One Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 760; -- Lost One Muckdweller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 761; -- Lost One Seer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 762; -- Lost One Riftseeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 763; -- Lost One Chieftain
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 764; -- Swampwalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 765; -- Swampwalker Elder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 766; -- Tangled Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 767; -- Swamp Jaguar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 768; -- Shadow Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 769; -- Deathstrike Tarantula
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 770; -- Corporal Kaleb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 771; -- Commander Felstrom
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 780; -- Skullsplitter Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 781; -- Skullsplitter Headhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 782; -- Skullsplitter Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 783; -- Skullsplitter Berserker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 784; -- Skullsplitter Beastmaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 785; -- Skeletal Warder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 786; -- Grelin Whitebeard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 787; -- Skeletal Healer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 789; -- Kimberly Hiett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 790; -- Karen Taylor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 791; -- Lindsay Ashlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 793; -- Kara Adams
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 794; -- Matt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 795; -- Mark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 796; -- Joshua
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 797; -- Bo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 804; -- Dana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 805; -- Cameron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 806; -- John
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 807; -- Lisa
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 808; -- Grik'nir the Cold
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 810; -- Aaron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 811; -- Jose
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 812; -- Alma Jainrose
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 813; -- Colonel Kurzen
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 814; -- Sergeant Malthus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 818; -- Mai'Zoth
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 819; -- Servant of Ilgalar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 820; -- Scout Riell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 821; -- Captain Danuvin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 822; -- Young Forest Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 823; -- Deputy Willem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 824; -- Defias Digger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 826; -- Watcher Jan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 827; -- Watcher Mocarski
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 828; -- Watcher Petras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 829; -- Adlin Pridedrift
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 830; -- Sand Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 831; -- Sea Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 832; -- Dust Devil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 833; -- Coyote Packleader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 834; -- Coyote
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 836; -- Durnan Furcutter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 837; -- Branstock Khalder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 840; -- Watcher Backus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 842; -- Lumberjack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 843; -- Gina MacGregor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 844; -- Antonio Perelli
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 847; -- Nathan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 848; -- Madison
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 849; -- Rachel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 850; -- Erin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 851; -- Hannah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 853; -- Coldridge Mountaineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 854; -- Young Jungle Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 855; -- Young Stranglethorn Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 856; -- Young Lashtail Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 857; -- Donal Osgood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 858; -- Sorrow Spinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 859; -- Guard Berton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 861; -- Stonard Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 862; -- Stonard Explorer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 863; -- Stonard Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 864; -- Stonard Orc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 865; -- Stonard Wayfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 866; -- Stonard Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 867; -- Stonard Cartographer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 868; -- Stonard Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 869; -- Protector Dorana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 870; -- Protector Deni
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 871; -- Saltscale Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 873; -- Saltscale Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 874; -- Protector Korelor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 875; -- Saltscale Tide Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 876; -- Protector Leick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 877; -- Saltscale Forager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 878; -- Scout Galiaan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 879; -- Saltscale Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 880; -- Erlan Drudgemoor
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 881; -- Surena Caledon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 883; -- Deer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 885; -- Watcher Keller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 886; -- Watcher Hartin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 887; -- Watcher Jordan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 888; -- Watcher Dodds
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 889; -- Splinter Fist Ogre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 890; -- Fawn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 891; -- Splinter Fist Fire Weaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 892; -- Splinter Fist Taskmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 893; -- Lars
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 894; -- Homer Stonefield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 895; -- Thorgas Grimson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 896; -- Veldan Lightfoot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 898; -- Nightbane Worgen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 900; -- Bailiff Conacher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 903; -- Guard Howe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 905; -- Sharptooth Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 906; -- Maximillian Crowe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 907; -- Keras Wolfheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 908; -- Flora Silverwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 909; -- Defias Night Blade
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 910; -- Defias Enchanter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 911; -- Llane Beshere
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 912; -- Thran Khorman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 913; -- Lyria Du Lac
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 914; -- Ander Germaine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 915; -- Jorik Kerridan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 916; -- Solm Hargrin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 917; -- Keryn Sylvius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 918; -- Osborne the Night Man
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 920; -- Nightbane Tainted One
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 921; -- Venture Co. Lumberjack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 922; -- Silt Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 923; -- Young Black Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 925; -- Brother Sammuel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 926; -- Bromos Grummner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 927; -- Brother Wilhelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 930; -- Black Widow Hatchling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 931; -- Ariena Stormfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 932; -- Guard Ashlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 933; -- Guard Hiett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 934; -- Guard Clarke
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 935; -- Guard Pearce
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 936; -- Guard Adams
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 937; -- Kurzen Jungle Fighter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 938; -- Kurzen Commando
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 939; -- Kurzen Elite
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 940; -- Kurzen Medicine Man
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 941; -- Kurzen Headshrinker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 942; -- Kurzen Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 943; -- Kurzen Wrangler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 944; -- Marryk Nurribit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 945; -- Rybrad Coldbank
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 946; -- Frostmane Novice
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 948; -- Rotted One
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 949; -- Carrion Recluse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 950; -- Swamp Talker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 951; -- Brother Paxton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 952; -- Brother Neals
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 954; -- Kat Sampson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 955; -- Sergeant De Vries
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 956; -- Dorin Songblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 958; -- Dawn Brightstar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 959; -- Morley Eberlein
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 960; -- Gunder Thornbush
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 963; -- Deputy Rainer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 976; -- Kurzen War Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 977; -- Kurzen War Panther
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 978; -- Kurzen Subchief
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 979; -- Kurzen Shadow Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 980; -- Grimnal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 981; -- Hartash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 982; -- Thultash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 983; -- Thultazor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 984; -- Thralosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 985; -- Malosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 986; -- Haromm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 987; -- Ogromm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 988; -- Kartosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 989; -- Banalash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 999; -- Watcher Royce
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1007; -- Mosshide Gnoll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1008; -- Mosshide Mongrel
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1009; -- Mosshide Mistweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1010; -- Mosshide Fenrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1011; -- Mosshide Trapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1012; -- Mosshide Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1013; -- Mosshide Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1014; -- Mosshide Alpha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1015; -- Highland Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1016; -- Highland Lashtail
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1017; -- Highland Scytheclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1018; -- Highland Razormaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1019; -- Elder Razormaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1020; -- Mottled Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1021; -- Mottled Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1022; -- Mottled Scytheclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1023; -- Mottled Razormaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1024; -- Bluegill Murloc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1025; -- Bluegill Puddlejumper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1026; -- Bluegill Forager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1027; -- Bluegill Warrior
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1028; -- Bluegill Muckdweller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1029; -- Bluegill Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1030; -- Black Slime
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1031; -- Crimson Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1032; -- Black Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1033; -- Monstrous Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1034; -- Dragonmaw Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1035; -- Dragonmaw Swamprunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1036; -- Dragonmaw Centurion
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1038; -- Dragonmaw Shadowwarder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1039; -- Fen Dweller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1040; -- Fen Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1041; -- Fen Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1042; -- Red Whelp
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1043; -- Lost Whelp
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1044; -- Flamesnorting Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1045; -- Red Dragonspawn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1046; -- Red Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1047; -- Red Scalebane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1048; -- Scalebane Lieutenant
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1049; -- Wyrmkin Firebrand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1050; -- Scalebane Royal Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1051; -- Dark Iron Dwarf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1052; -- Dark Iron Saboteur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1053; -- Dark Iron Tunneler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1054; -- Dark Iron Demolitionist
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1057; -- Dragonmaw Bonewarder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1059; -- Ana'thek the Cruel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1060; -- Mogh the Undying
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1062; -- Nezzliok the Dire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1064; -- Grom'gol Grunt
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1065; -- Riverpaw Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1068; -- Gorn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1069; -- Crimson Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1070; -- Deputy Feldon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1071; -- Longbraid the Grim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1072; -- Roggo Harlbarrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1073; -- Ashlan Stonesmirk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1074; -- Motley Garmason
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1075; -- Rhag Garmason
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1076; -- Merrin Rockweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1077; -- Prospector Whelgar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1078; -- Ormer Ironbraid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1081; -- Mire Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1082; -- Sawtooth Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1083; -- Murloc Shorestriker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1084; -- Young Sawtooth Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1085; -- Elder Stranglethorn Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1087; -- Sawtooth Snapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1088; -- Monstrous Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1089; -- Mountaineer Cobbleflint
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1090; -- Mountaineer Wallbang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1091; -- Mountaineer Gravelgaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1092; -- Captain Rugelfuss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1093; -- Chief Engineer Hinderweir VII
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1094; -- Venture Co. Miner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1096; -- Venture Co. Geologist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1097; -- Venture Co. Mechanic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1103; -- Eldrin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1104; -- Grundel Harkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1105; -- Jern Hornhelm
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1106; -- Lost One Cook
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1108; -- Mistvale Gorilla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1109; -- Fleshripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1110; -- Skeletal Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1111; -- Leech Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1114; -- Jungle Thunderer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1115; -- Rockjaw Skullthumper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1116; -- Rockjaw Ambusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1117; -- Rockjaw Bonesnapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1118; -- Rockjaw Backbreaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1120; -- Frostmane Troll
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1121; -- Frostmane Snowstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1122; -- Frostmane Hideskinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1123; -- Frostmane Headhunter
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1124; -- Frostmane Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1125; -- Crag Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1126; -- Large Crag Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1127; -- Elder Crag Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1128; -- Young Black Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1131; -- Winter Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1132; -- Timber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1133; -- Starving Winter Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1134; -- Young Wendigo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1135; -- Wendigo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1137; -- Edan the Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1138; -- Snow Tracker Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1139; -- Magistrate Bluntnose
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1140; -- Razormaw Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1142; -- Mosh'Ogg Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1144; -- Mosh'Ogg Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1146; -- Vharr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1147; -- Hragran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1148; -- Nerrist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1149; -- Uthok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1150; -- River Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1151; -- Saltwater Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1152; -- Snapjaw Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1153; -- Torren Squarejaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1154; -- Marek Ironheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1155; -- Kelt Thomasin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1156; -- Vyrin Swiftwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1157; -- Cursed Sailor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1158; -- Cursed Marine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1159; -- First Mate Snellig
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1160; -- Captain Halyndor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1161; -- Stonesplinter Trogg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1162; -- Stonesplinter Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1163; -- Stonesplinter Skullthumper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1164; -- Stonesplinter Bonesnapper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1165; -- Stonesplinter Geomancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1166; -- Stonesplinter Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1167; -- Stonesplinter Digger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1169; -- Dark Iron Insurgent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1172; -- Tunnel Rat Vermin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1173; -- Tunnel Rat Scout
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1174; -- Tunnel Rat Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1175; -- Tunnel Rat Digger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1176; -- Tunnel Rat Forager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1177; -- Tunnel Rat Surveyor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1178; -- Mo'grosh Ogre
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1179; -- Mo'grosh Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1180; -- Mo'grosh Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1181; -- Mo'grosh Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1182; -- Brother Anton
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1183; -- Mo'grosh Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1184; -- Cliff Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1185; -- Wood Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1186; -- Elder Black Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1187; -- Daryl the Youngling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1188; -- Grizzled Black Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1189; -- Black Bear Patriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1190; -- Mountain Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1191; -- Mangy Mountain Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1192; -- Elder Mountain Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1193; -- Loch Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1194; -- Mountain Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1195; -- Forest Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1196; -- Ice Claw Bear
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1197; -- Stonesplinter Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1198; -- Rallic Finn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1199; -- Juvenile Snow Leopard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1200; -- Morbent Fel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1201; -- Snow Leopard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1202; -- Tunnel Rat Kobold
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1205; -- Grawmug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1206; -- Gnasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1207; -- Brawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1210; -- Chok'sul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1211; -- Leper Gnome
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1213; -- Godric Rothgar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1214; -- Aldren Cordon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1216; -- Shore Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1217; -- Glorin Steelbrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1222; -- Dark Iron Sapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1224; -- Young Threshadon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1225; -- Ol' Sooty
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1226; -- Maxan Anvol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1228; -- Magis Sparkmantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1229; -- Granis Swiftaxe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1231; -- Grif Wildheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1232; -- Azar Stronghammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1234; -- Hogral Bakkan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1236; -- Kobold Digger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1237; -- Kazan Mogosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1238; -- Gamili Frosthide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1239; -- First Mate Fitzsimmons
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1240; -- Boran Ironclink
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1241; -- Tognus Flintfire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1242; -- Karl Boran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1243; -- Hegnar Rumbleshot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1244; -- Rethiel the Greenwarden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1245; -- Kogan Forgestone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1246; -- Vosur Brakthel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1247; -- Innkeeper Belm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1249; -- Quartermaster Hudson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1250; -- Drake Lindgren
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1251; -- Splinter Fist Firemonger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1252; -- Senir Whitebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1253; -- Father Gavin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1254; -- Foreman Stonebrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1255; -- Prospector Gehn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1256; -- Quarrymaster Thesten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1257; -- Keldric Boucher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1258; -- Black Ravager Mastiff
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1259; -- Gobbler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1260; -- Great Father Arctikus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1261; -- Veron Amberstill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1263; -- Yarlyn Amberstill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1265; -- Rudra Amberstill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1266; -- Tundra MacGrann
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1267; -- Ragnar Thunderbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1268; -- Ozzie Togglevolt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1269; -- Razzle Sprysprocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1270; -- Fetid Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1271; -- Old Icebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1273; -- Grawn Thromwyn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1274; -- Senator Barin Redstone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1275; -- Kyra Boucher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1276; -- Mountaineer Brokk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1277; -- Mountaineer Ganin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1278; -- Mountaineer Stenn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1279; -- Mountaineer Flint
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1280; -- Mountaineer Droken
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1281; -- Mountaineer Zaren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1282; -- Mountaineer Veek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1283; -- Mountaineer Kalmir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1285; -- Thurman Mullby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1286; -- Edna Mullby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1287; -- Marda Weller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1289; -- Gunther Weller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1291; -- Carla Granger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1292; -- Maris Granger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1294; -- Aldric Moore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1295; -- Lara Moore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1296; -- Felder Stover
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1297; -- Lina Stover
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1298; -- Frederick Stover
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1299; -- Lisbeth Schneider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1300; -- Lawrence Schneider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1301; -- Julia Gallina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1302; -- Bernard Gump
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1303; -- Felicia Gump
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1313; -- Maria Lumere
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1314; -- Duncan Cullen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1315; -- Allan Hafgan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1317; -- Lucan Cordell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1319; -- Bryan Cross
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1320; -- Seoman Griffith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1321; -- Alyssa Griffith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1322; -- Maxton Strang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1323; -- Osric Strang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1324; -- Heinrich Stone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1325; -- Jasper Fel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1326; -- Sloan McCoy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1327; -- Reese Langston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1328; -- Elly Langston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1329; -- Mountaineer Naarh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1330; -- Mountaineer Tyraw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1331; -- Mountaineer Luxst
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1332; -- Mountaineer Morran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1333; -- Gerik Koen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1334; -- Mountaineer Hammerfall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1335; -- Mountaineer Yuttha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1336; -- Mountaineer Zwarn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1337; -- Mountaineer Gwarth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1338; -- Mountaineer Dalk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1339; -- Mayda Thane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1340; -- Mountaineer Kadrell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1341; -- Wilhelm Strang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1342; -- Mountaineer Rockgar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1343; -- Mountaineer Stormpike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1344; -- Prospector Ironband
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1345; -- Magmar Fellhew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1346; -- Georgio Bolero
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1347; -- Alexandra Bolero
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1349; -- Agustus Moulaine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1350; -- Theresa Moulaine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1352; -- Fluffy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1353; -- Sarltooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1354; -- Apprentice Soren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1355; -- Cook Ghilm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1356; -- Prospector Stormpike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1358; -- Miner Grothor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1360; -- Miner Grumnal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1362; -- Gothor Brumn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1364; -- Balgaras the Foul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1366; -- Adam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1367; -- Billy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1368; -- Justin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1370; -- Brandon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1371; -- Roman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1373; -- Jarven Thunderbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1374; -- Rejold Barleybrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1375; -- Marleth Barleybrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1376; -- Beldin Steelgrill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1377; -- Pilot Stonegear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1378; -- Pilot Bellowfiz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1379; -- Miran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1381; -- Krakk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1382; -- Mudduk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1383; -- Snarl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1385; -- Brawn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1386; -- Rogvar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1387; -- Thysta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1388; -- Vagash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1393; -- Berserk Trogg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1395; -- Ol' Beasley
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1397; -- Frostmane Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1398; -- Boss Galgosh
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1399; -- Magosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1400; -- Wetlands Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1402; -- Topper McNabb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1404; -- Kragg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1405; -- Morris Lawry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1407; -- Sranda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1411; -- Ian Strom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1412; -- Squirrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1417; -- Young Wetlands Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1418; -- Bluegill Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1420; -- Toad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1421; -- Private Merle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1422; -- Corporal Sethman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1423; -- Stormwind Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1424; -- Master Digger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1425; -- Grizlak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1426; -- Riverpaw Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1427; -- Harlan Bagley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1428; -- Rema Schneider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1430; -- Tomas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1431; -- Suzetta Gallina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1432; -- Renato Gallina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1434; -- Menethil Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1437; -- Thomas Booker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1439; -- Lord Baurles K. Wishock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1441; -- Brak Durnad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1442; -- Helgrum the Swift
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1443; -- Fel'zerul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1444; -- Brother Kristoff
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1445; -- Jesse Halloran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1446; -- Regina Halloran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1447; -- Gimlok Rumdnul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1448; -- Neal Allen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1449; -- Witch Doctor Unbagwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1450; -- Brahnmar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1451; -- Camerick Jongleur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1452; -- Gruham Rumdnul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1453; -- Dewin Shimmerdawn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1454; -- Jennabink Powerseam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1456; -- Kersok Prond
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1457; -- Samor Festivus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1458; -- Telurinon Moonshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1459; -- Naela Trance
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1460; -- Unger Statforth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1461; -- Murndan Derth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1462; -- Edwina Monzor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1463; -- Falkan Armonis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1464; -- Innkeeper Helbrek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1465; -- Drac Roughcut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1466; -- Gretta Finespindle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1469; -- Vrok Blunderblast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1470; -- Ghak Healtouch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1471; -- Jannos Ironwill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1473; -- Kali Healtouch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1474; -- Rann Flamespinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1476; -- Hargin Mundar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1477; -- Christoph Faral
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1478; -- Aedis Brom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1479; -- Timothy Clark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1480; -- Caitlin Grassman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1481; -- Bart Tidewater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1482; -- Andrea Halloran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1483; -- Murphy West
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1484; -- Derina Rumdnul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1487; -- Splinter Fist Enslaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1488; -- Zanzil Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1489; -- Zanzil Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1490; -- Zanzil Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1491; -- Zanzil Naga
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1492; -- Gorlash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1493; -- Mok'rash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1495; -- Deathguard Linnea
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1496; -- Deathguard Dillinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1497; -- Gunther Arcanus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1498; -- Bethor Iceshard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1499; -- Magistrate Sevren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1500; -- Coleman Farthing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1501; -- Mindless Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1502; -- Wretched Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1504; -- Young Night Web Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1505; -- Night Web Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1506; -- Scarlet Convert
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1507; -- Scarlet Initiate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1508; -- Young Scavenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1509; -- Ragged Scavenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1512; -- Duskbat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1513; -- Mangy Duskbat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1515; -- Executor Zygand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1518; -- Apothecary Johaan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1519; -- Deathguard Simmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1520; -- Rattlecage Soldier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1521; -- Gretchen Dedmar
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1522; -- Darkeye Bonecaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1523; -- Cracked Skull Soldier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1525; -- Rotting Dead
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1526; -- Ravaged Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1527; -- Hungering Dead
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1528; -- Shambling Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1529; -- Bleeding Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1530; -- Rotting Ancestor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1531; -- Lost Soul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1532; -- Wandering Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1534; -- Wailing Ancestor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1535; -- Scarlet Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1536; -- Scarlet Missionary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1537; -- Scarlet Zealot
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1538; -- Scarlet Friar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1539; -- Scarlet Neophyte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1540; -- Scarlet Vanguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1543; -- Vile Fin Puddlejumper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1544; -- Vile Fin Minor Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1545; -- Vile Fin Muckdweller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1547; -- Decrepit Darkhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1548; -- Cursed Darkhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1549; -- Ravenous Darkhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1550; -- Thrashtail Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1551; -- Ironjaw Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1552; -- Scale Belly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1553; -- Greater Duskbat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1554; -- Vampiric Duskbat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1555; -- Vicious Night Web Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1557; -- Elder Mistvale Gorilla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1558; -- Silverback Patriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1559; -- King Mukla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1560; -- Yvette Farthing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1561; -- Bloodsail Raider
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1562; -- Bloodsail Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1563; -- Bloodsail Swashbuckler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1564; -- Bloodsail Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1565; -- Bloodsail Sea Dog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1568; -- Undertaker Mordo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1569; -- Shadow Priest Sarvis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1570; -- Executor Arren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1571; -- Shellei Brondir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1572; -- Thorgrum Borrelson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1573; -- Gryth Thurden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1632; -- Adele Fielder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1642; -- Northshire Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1645; -- Quartermaster Hicks
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1646; -- Baros Alexston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1650; -- Terry Palin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1651; -- Lee Brown
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1652; -- Deathguard Burgess
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1653; -- Bloodsail Elder Magus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1654; -- Gregor Agamand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1655; -- Nissa Agamand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1656; -- Thurman Agamand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1657; -- Devlin Agamand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1658; -- Captain Dargol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1660; -- Scarlet Bodyguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1661; -- Novice Elreth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1662; -- Captain Perrine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1663; -- Dextren Ward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1664; -- Captain Vachon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1665; -- Captain Melrache
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1666; -- Kam Deepfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1667; -- Meven Korgal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1668; -- William MacGregor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1669; -- Defias Profiteer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1670; -- Mike Miller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1671; -- Lamar Veisilli
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1672; -- Lohgan Eva
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1673; -- Alyssa Eva
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1674; -- Rot Hide Gnoll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1675; -- Rot Hide Mongrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1676; -- Finbus Geargrind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1678; -- Vernon Hale
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1679; -- Avarus Kharag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1680; -- Matthew Hooper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1681; -- Brock Stoneseeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1682; -- Yanni Stoutheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1683; -- Warg Deepwater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1684; -- Khara Deepwater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1685; -- Xandar Goodbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1686; -- Irene Sureshot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1687; -- Cliff Hadin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1688; -- Night Web Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1689; -- Scarred Crag Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1690; -- Thrawn Boltar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1691; -- Kreg Bilmn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1692; -- Golorn Frostbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1693; -- Loch Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1694; -- Loslor Rudge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1695; -- Rendow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1697; -- Keeg Gibn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1698; -- Frast Dokner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1699; -- Gremlock Pilsnor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1700; -- Paxton Ganter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1701; -- Dank Drizzlecut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1702; -- Bronk Guzzlegear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1703; -- Uthrar Threx
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1706; -- Defias Prisoner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1707; -- Defias Captive
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1708; -- Defias Inmate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1711; -- Defias Convict
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1713; -- Elder Shadowmaw Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1715; -- Defias Insurgent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1716; -- Bazil Thredd
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1717; -- Hamhock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1718; -- Rockjaw Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1720; -- Bruegal Ironknuckle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1721; -- Nikova Raskol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1725; -- Defias Watchman
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1726; -- Defias Magician
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1727; -- Defias Worker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1729; -- Defias Evoker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1731; -- Goblin Craftsman
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1732; -- Defias Squallshaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1735; -- Deathguard Abraham
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1736; -- Deathguard Randolph
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1737; -- Deathguard Oliver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1738; -- Deathguard Terrence
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1739; -- Deathguard Phillip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1740; -- Deathguard Saltain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1741; -- Deathguard Bartrand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1742; -- Deathguard Bartholomew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1743; -- Deathguard Lawrence
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1744; -- Deathguard Mort
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1745; -- Deathguard Morris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1746; -- Deathguard Cyrus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1753; -- Maggot Eye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1756; -- Stormwind Royal Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1763; -- Gilnid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1765; -- Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1766; -- Mottled Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1767; -- Vile Fin Shredder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1768; -- Vile Fin Tidehunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1769; -- Moonrage Whitescalp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1770; -- Moonrage Darkrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1772; -- Rot Hide Gladerunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1773; -- Rot Hide Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1775; -- Zun'dartha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1776; -- Magtoor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1777; -- Dakk Blunderblast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1778; -- Ferocious Grizzled Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1779; -- Moonrage Glutton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1780; -- Moss Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1781; -- Mist Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1782; -- Moonrage Darksoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1783; -- Skeletal Flayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1784; -- Skeletal Sorcerer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1785; -- Skeletal Terror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1787; -- Skeletal Executioner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1788; -- Skeletal Warlord
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1789; -- Skeletal Acolyte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1791; -- Slavering Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1793; -- Rotting Ghoul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1794; -- Soulless Ghoul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1795; -- Searing Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1796; -- Freezing Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1797; -- Giant Grizzled Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1802; -- Hungering Wraith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1804; -- Wailing Death
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1805; -- Flesh Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1806; -- Vile Slime
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1808; -- Devouring Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1809; -- Carrion Vulture
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1812; -- Rotting Behemoth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1813; -- Decaying Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1815; -- Diseased Black Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1816; -- Diseased Grizzly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1817; -- Diseased Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1821; -- Carrion Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1822; -- Venom Mist Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1824; -- Plague Lurker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1826; -- Scarlet Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1827; -- Scarlet Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1831; -- Scarlet Hunter
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1832; -- Scarlet Magus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1833; -- Scarlet Knight
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1834; -- Scarlet Paladin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1835; -- Scarlet Invoker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1836; -- Scarlet Cavalier
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1837; -- Scarlet Judge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1839; -- Scarlet High Clerist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1840; -- Grand Inquisitor Isillien
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1842; -- Highlord Taelan Fordring
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1845; -- High Protector Tarsen
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1846; -- High Protector Lorik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1847; -- Foulmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1850; -- Putridius
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1852; -- Araj the Summoner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1854; -- High Priest Thel'danis
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1855; -- Tirion Fordring
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1860; -- Voidwalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1863; -- Succubus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1865; -- Ravenclaw Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1866; -- Ravenclaw Slave
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1867; -- Dalaran Apprentice
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1868; -- Ravenclaw Servant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1869; -- Ravenclaw Champion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1870; -- Hand of Ravenclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1872; -- Tharek Blackstone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1883; -- Scarlet Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1884; -- Scarlet Lumberjack
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1888; -- Dalaran Watcher
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1889; -- Dalaran Wizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1890; -- Rattlecage Skeleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1891; -- Pyrewood Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1894; -- Pyrewood Sentry
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1895; -- Pyrewood Elder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1901; -- Kelstrum Stonebreaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1907; -- Naga Explorer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1908; -- Vile Fin Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1909; -- Vile Fin Lakestalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1910; -- Muad
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1911; -- Deeb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1912; -- Dalaran Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1913; -- Dalaran Warder
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1914; -- Dalaran Mage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1915; -- Dalaran Conjuror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1916; -- Stephen Bhartec
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1917; -- Daniel Ulfman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1918; -- Karrel Grayves
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1919; -- Samuel Fipps
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1920; -- Dalaran Spellscribe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1922; -- Gray Forest Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1923; -- Bloodsnout Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1924; -- Moonrage Bloodhowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1931; -- Captured Scarlet Zealot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1933; -- Sheep
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1934; -- Tirisfal Farmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1935; -- Tirisfal Farmhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1936; -- Farmer Solliden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1937; -- Apothecary Renferrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1938; -- Dalar Dawnweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1939; -- Rot Hide Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1940; -- Rot Hide Plague Weaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1941; -- Rot Hide Graverobber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1942; -- Rot Hide Savage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1943; -- Raging Rot Hide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1944; -- Rot Hide Bruiser
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 1947; -- Thule Ravenclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1948; -- Snarlmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1949; -- Servant of Azora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1950; -- Rane Yorick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1951; -- Quinn Yorick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1952; -- High Executor Hadrec
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1953; -- Lake Skulker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1954; -- Elder Lake Skulker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1955; -- Lake Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1956; -- Elder Lake Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1957; -- Vile Fin Shorecreeper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1958; -- Vile Fin Tidecaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1959; -- Mountaineer Barleybrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1960; -- Pilot Hammerfoot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1961; -- Mangeclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1963; -- Vidra Hearthstove
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1965; -- Mountaineer Thalos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1971; -- Ivar the Foul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1972; -- Grimson the Pale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1973; -- Ravenclaw Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1974; -- Ravenclaw Drudger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1975; -- Eastvale Lumberjack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1976; -- Stormwind City Patroller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1977; -- Senator Mehr Stonehallow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1978; -- Deathstalker Erland
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1983; -- Nightlash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1984; -- Young Thistle Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1985; -- Thistle Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1986; -- Webwood Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1988; -- Grell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1989; -- Grellkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1992; -- Tarindrella
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 1993; -- Greenpaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1994; -- Githyiss the Vile
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1995; -- Strigid Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1996; -- Strigid Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1997; -- Strigid Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1998; -- Webwood Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 1999; -- Webwood Venomfang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2000; -- Webwood Silkspinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2001; -- Giant Webwood Spider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2002; -- Rascal Sprite
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2003; -- Shadow Sprite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2004; -- Dark Sprite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2005; -- Vicious Grell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2006; -- Gnarlpine Ursa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2007; -- Gnarlpine Gardener
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2008; -- Gnarlpine Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2009; -- Gnarlpine Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2010; -- Gnarlpine Defender
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2011; -- Gnarlpine Augur
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2012; -- Gnarlpine Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2013; -- Gnarlpine Avenger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2014; -- Gnarlpine Totemic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2015; -- Bloodfeather Harpy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2017; -- Bloodfeather Rogue
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2018; -- Bloodfeather Sorceress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2019; -- Bloodfeather Fury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2020; -- Bloodfeather Wind Witch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2021; -- Bloodfeather Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2022; -- Timberling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2025; -- Timberling Bark Ripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2027; -- Timberling Trampler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2029; -- Timberling Mire Beast
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2030; -- Elder Timberling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2031; -- Young Nightsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2032; -- Mangy Nightsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2033; -- Elder Nightsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2034; -- Feral Nightsaber
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2038; -- Lord Melenas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2039; -- Ursal the Mauler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2041; -- Ancient Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2042; -- Nightsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2043; -- Nightsaber Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2046; -- Andrew Krighton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2050; -- Raleigh Andrean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2053; -- Haggard Refugee
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2054; -- Sickly Refugee
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2055; -- Master Apothecary Faranell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2057; -- Huldar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2058; -- Deathstalker Faerleia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2069; -- Moonstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2070; -- Moonstalker Runt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2071; -- Moonstalker Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2077; -- Melithar Staghelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2078; -- Athridas Bearmantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2079; -- Conservator Ilthalaine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2080; -- Denalan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2081; -- Sentinel Kyra Starsong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2082; -- Gilshalan Windwalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2083; -- Syral Bladeleaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2084; -- Natheril Raincaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2086; -- Valstag Ironjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2089; -- Giant Wetlands Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2090; -- Ma'ruk Wyrmscale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2091; -- Chieftain Nek'rosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2092; -- Pilot Longbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2093; -- Einar Stonegrip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2094; -- James Halloran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2096; -- Tarrel Rockweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2097; -- Harlo Barnaby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2098; -- Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2099; -- Maiden's Virtue Crewman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2102; -- Dragonmaw Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2103; -- Dragonmaw Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2104; -- Captain Stoutfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2105; -- Mountaineer Dokkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2106; -- Apothecary Berard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2107; -- Gaerolas Talvethren
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2108; -- Garneg Charskull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2110; -- Black Rat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2111; -- Sida
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2112; -- Farrin Daris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2113; -- Archibald Kava
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2114; -- Faruza
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2115; -- Joshua Kien
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2116; -- Blacksmith Rand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2117; -- Harold Raims
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2118; -- Abigail Shiel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2119; -- Dannal Stern
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2120; -- Archmage Ataeric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2121; -- Shadow Priest Allister
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2122; -- David Trias
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2123; -- Dark Cleric Duesten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2124; -- Isabella
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2126; -- Maximillion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2127; -- Rupert Boch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2128; -- Cain Firesong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2129; -- Dark Cleric Beryl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2130; -- Marion Call
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2131; -- Austil de Mon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2132; -- Carolai Anise
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2134; -- Mrs. Winters
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2135; -- Abe Winters
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2136; -- Oliver Dwor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2137; -- Eliza Callen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2140; -- Edwin Harly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2142; -- Watcher Callahan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2150; -- Zenn Foulhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2151; -- Moon Priestess Amara
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2152; -- Gnarlpine Ambusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2153; -- Terl Arakor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2155; -- Sentinel Shayla Nightbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2156; -- Cracked Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2157; -- Stone Behemoth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2162; -- Agal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2163; -- Thistle Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2164; -- Rabid Thistle Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2165; -- Grizzled Thistle Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2166; -- Oakenscowl
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2167; -- Blackwood Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2168; -- Blackwood Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2169; -- Blackwood Totemic
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2170; -- Blackwood Ursa
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2171; -- Blackwood Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2172; -- Strider Clutchmother
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2173; -- Reef Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2174; -- Coastal Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2175; -- Shadowclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2176; -- Cursed Highborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2177; -- Writhing Highborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2178; -- Wailing Highborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2179; -- Stormscale Wave Rider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2180; -- Stormscale Siren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2181; -- Stormscale Myrmidon
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2182; -- Stormscale Sorceress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2183; -- Stormscale Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2184; -- Lady Moongazer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2185; -- Darkshore Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2187; -- Elder Darkshore Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2189; -- Vile Sprite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2190; -- Wild Grell
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2192; -- Firecaller Radison
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2198; -- Crier Goodman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2201; -- Greymist Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2202; -- Greymist Coastrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2203; -- Greymist Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2204; -- Greymist Netter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2205; -- Greymist Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2206; -- Greymist Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2207; -- Greymist Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2208; -- Greymist Tidehunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2209; -- Deathguard Gavin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2210; -- Deathguard Royann
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2211; -- Captured Mountaineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2212; -- Deth'ryll Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2214; -- Deathstalker Lesh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2215; -- High Executor Darthalia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2216; -- Apothecary Lydon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2226; -- Karos Razok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2227; -- Sharlindra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2228; -- Lieutenant Farren Orinelle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2229; -- Krusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2230; -- Umpi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2231; -- Pygmy Tide Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2232; -- Tide Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2233; -- Encrusted Tide Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2234; -- Young Reef Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2235; -- Reef Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2236; -- Raging Reef Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2237; -- Moonstalker Sire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2238; -- Tog'thar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2239; -- Drull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2240; -- Syndicate Footpad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2241; -- Syndicate Thief
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2242; -- Syndicate Spy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2243; -- Syndicate Sentry
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2244; -- Syndicate Shadow Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2245; -- Syndicate Saboteur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2246; -- Syndicate Assassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2247; -- Syndicate Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2248; -- Cave Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2249; -- Ferocious Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2250; -- Mountain Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2251; -- Giant Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2252; -- Crushridge Ogre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2253; -- Crushridge Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2254; -- Crushridge Mauler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2255; -- Crushridge Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2256; -- Crushridge Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2257; -- Mug'thol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2260; -- Syndicate Rogue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2261; -- Syndicate Watchman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2263; -- Marshal Redpath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2264; -- Hillsbrad Tailor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2265; -- Hillsbrad Apprentice Blacksmith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2266; -- Hillsbrad Farmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2267; -- Hillsbrad Peasant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2268; -- Hillsbrad Footman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2269; -- Hillsbrad Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2270; -- Hillsbrad Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2271; -- Dalaran Shield Guard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2272; -- Dalaran Theurgist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2274; -- Stanley
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2276; -- Magistrate Henry Maleb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2277; -- Loremaster Dibbs
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2278; -- Melisara
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2283; -- Ravenclaw Regent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2284; -- Captured Farmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2285; -- Count Remington Ridgewell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2287; -- Crushridge Warmonger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2299; -- Borgus Stoutarm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2302; -- Aethalas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2303; -- Lyranne Feathersong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2304; -- Captain Ironhill
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2305; -- Foreman Bonds
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2306; -- Baron Vardus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2307; -- Caretaker Caice
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2308; -- Andrew Brownell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2309; -- Thomas Arlento
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2310; -- Jamie Nore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2311; -- Doreen Beltis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2314; -- Sahvan Bloodshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2315; -- Maquell Ebonwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2316; -- Gol'dir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2317; -- Elysa
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2318; -- Argus Shadow Mage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2319; -- Syndicate Wizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2320; -- Nagaz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2321; -- Foreststrider Fledgling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2322; -- Foreststrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2323; -- Giant Foreststrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2324; -- Blackwood Windtalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2326; -- Thamner Pol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2329; -- Michelle Belle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2332; -- Valdred Moray
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2333; -- Henchman Valik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2334; -- Event Generator 001
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2335; -- Magistrate Burnside
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2336; -- Dark Strand Fanatic
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2337; -- Dark Strand Voidcaller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2338; -- Twilight Disciple
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2339; -- Twilight Thug
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2344; -- Dun Garok Mountaineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2345; -- Dun Garok Rifleman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2346; -- Dun Garok Priest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2347; -- Wild Gryphon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2348; -- Elder Moss Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2349; -- Giant Moss Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2350; -- Forest Moss Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2351; -- Gray Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2352; -- Innkeeper Anderson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2354; -- Vicious Gray Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2356; -- Elder Gray Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2357; -- Merideth Carlson
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2358; -- Dalaran Summoner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2359; -- Elemental Slave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2360; -- Hillsbrad Farmhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2361; -- Tamara Armstrong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2362; -- Hemmit Armstrong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2363; -- Apprentice Honeywell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2364; -- Neema
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2365; -- Bront Coldcleave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2366; -- Barkeep Kelly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2367; -- Donald Rabonne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2368; -- Daggerspine Shorestalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2369; -- Daggerspine Shorehunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2370; -- Daggerspine Screamer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2371; -- Daggerspine Siren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2372; -- Mudsnout Gnoll
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2373; -- Mudsnout Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2374; -- Torn Fin Muckdweller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2375; -- Torn Fin Coastrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2376; -- Torn Fin Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2377; -- Torn Fin Tidehunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2378; -- Kundric Zanden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2379; -- Caretaker Smithers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2380; -- Nandar Branson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2381; -- Micha Yance
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2382; -- Darren Malvew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2383; -- Lindea Rabonne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2384; -- Starving Mountain Lion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2385; -- Feral Mountain Lion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2386; -- Southshore Guard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2387; -- Hillsbrad Councilman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2388; -- Innkeeper Shay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2389; -- Zarise
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2390; -- Aranae Venomblood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2391; -- Serge Hinott
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2392; -- Delia Verana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2393; -- Christoph Jeffcoat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2394; -- Mallen Swain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2395; -- Vinna Wayne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2396; -- Hans Zandin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2397; -- Derak Nightfall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2398; -- Tara Coldgaze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2399; -- Daryl Stack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2400; -- Craig Hewitt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2401; -- Kayren Soothallow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2402; -- Shara Blazen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2403; -- Farmer Getz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2404; -- Blacksmith Verringtan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2405; -- Tarren Mill Deathguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2406; -- Mountain Lion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2407; -- Hulking Mountain Lion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2408; -- Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2409; -- Felicia Maline
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2410; -- Magus Wordeen Voidglare
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2411; -- Ricter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2412; -- Alina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2413; -- Dermot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2414; -- Kegan Darkmar
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2415; -- Warden Belamoore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2416; -- Crushridge Plunderer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2417; -- Grel'borg the Miser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2418; -- Deathguard Samsa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2419; -- Deathguard Humbert
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2420; -- Targ
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2421; -- Muckrake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2422; -- Glommus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2423; -- Lord Aliden Perenolde
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2425; -- Varimathras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2427; -- Jailor Eston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2428; -- Jailor Marlgen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2429; -- Novice Thaivand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2430; -- Chef Jessen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2431; -- Jailor Borhuin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2432; -- Darla Harris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2436; -- Farmer Kent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2437; -- Keeper Bel'varil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2438; -- Bartolo Ginsetti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2440; -- Drunken Footpad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2442; -- Cow
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2447; -- Narillasanz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2448; -- Clerk Horrace Whitesteed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2449; -- Citizen Wilkes
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2450; -- Miner Hackett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2451; -- Farmer Kalaba
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2452; -- Skhowl
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2453; -- Lo'Grosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2455; -- Olivia Burnside
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2456; -- Newton Burnside
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2457; -- John Burnside
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2458; -- Randolph Montague
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2459; -- Mortimer Montague
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2460; -- Barnum Stonemantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2461; -- Bailey Stonemantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2462; -- Flesh Eating Worm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2464; -- Commander Aggro'gosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2465; -- Far Seer Mok'thardin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2466; -- Mountaineer Grugelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2468; -- Mountaineer Thar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2469; -- Mountaineer Rharen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2470; -- Watcher Fraizer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2473; -- Granistad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2474; -- Kurdros
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2476; -- Large Loch Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2477; -- Gradok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2478; -- Haren Swifthoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2480; -- Bro'kin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2481; -- Bliztik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2482; -- Zarena Cromwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2483; -- Jaquilina Dramet
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2486; -- Fin Fizracket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2487; -- Fleet Master Seahorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2488; -- Deeg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2489; -- Milstaff Stormeye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2490; -- First Mate Crazz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2491; -- Whiskey Slim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2492; -- Lexington Mortaim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2493; -- Dizzy One-Eye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2494; -- Privateer Bloads
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2495; -- Drizzlik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2496; -- Baron Revilgaz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2497; -- Nimboya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2498; -- Crank Fizzlebub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2499; -- Markel Smythe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2500; -- Captain Hecklebury Smotts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2501; -- "Sea Wolf" MacKinley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2502; -- "Shaky" Phillipe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2503; -- Hillsbrad Foreman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2505; -- Saltwater Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2506; -- Mountaineer Harn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2507; -- Mountaineer Uthan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2508; -- Mountaineer Wuar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2509; -- Mountaineer Cragg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2510; -- Mountaineer Ozmok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2511; -- Mountaineer Bludd
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2512; -- Mountaineer Roghan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2513; -- Mountaineer Janha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2514; -- Mountaineer Modax
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2515; -- Mountaineer Fazgard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2516; -- Mountaineer Kamdar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2517; -- Mountaineer Langarr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2518; -- Mountaineer Swarth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2519; -- Kin'weelay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2520; -- Remote-Controlled Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2521; -- Skymane Gorilla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2522; -- Jaguero Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2524; -- Mountaineer Haggis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2525; -- Mountaineer Barn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2526; -- Mountaineer Morlic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2527; -- Mountaineer Angst
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2528; -- Mountaineer Haggil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2529; -- Son of Arugal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2530; -- Yenniku
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2532; -- Donna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2533; -- William
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2534; -- Zanzil the Outcast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2535; -- Maury "Club Foot" Wilkins
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2536; -- Jon-Jon the Crow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2537; -- Chucky "Ten Thumbs"
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2542; -- Catelyn the Blade
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2543; -- Archmage Ansirem Runeweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2544; -- Southern Sand Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2545; -- "Pretty Boy" Duncan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2546; -- Fleet Master Firallon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2547; -- Ironpatch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2548; -- Captain Keelhaul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2549; -- Garr Salthoof
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2550; -- Captain Stillwater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2551; -- Brutus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2552; -- Witherbark Troll
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2553; -- Witherbark Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2554; -- Witherbark Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2555; -- Witherbark Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2556; -- Witherbark Headhunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2557; -- Witherbark Shadow Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2558; -- Witherbark Berserker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2559; -- Highland Strider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2560; -- Highland Thrasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2561; -- Highland Fleshstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2562; -- Boulderfist Ogre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2563; -- Plains Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2564; -- Boulderfist Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2565; -- Giant Plains Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2566; -- Boulderfist Brute
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2567; -- Boulderfist Magus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2569; -- Boulderfist Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2570; -- Boulderfist Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2571; -- Boulderfist Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2572; -- Drywhisker Kobold
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2573; -- Drywhisker Surveyor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2574; -- Drywhisker Digger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2575; -- Dark Iron Supplier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2577; -- Dark Iron Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2578; -- Young Mesa Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2579; -- Mesa Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2580; -- Elder Mesa Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2581; -- Dabyrie Militia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2582; -- Dabyrie Laborer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2583; -- Stromgarde Troll Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2584; -- Stromgarde Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2585; -- Stromgarde Vindicator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2586; -- Syndicate Highwayman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2587; -- Syndicate Pathstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2588; -- Syndicate Prowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2589; -- Syndicate Mercenary
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2590; -- Syndicate Conjuror
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2591; -- Syndicate Magus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2592; -- Rumbling Exile
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2594; -- Sprogger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2595; -- Daggerspine Raider
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2596; -- Daggerspine Sorceress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2597; -- Lord Falconcrest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2599; -- Otto
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2600; -- Singer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2605; -- Zalas Witherbark
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2607; -- Prince Galen Trollbane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2608; -- Commander Amaren
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2609; -- Geomancer Flintdagger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2610; -- Shakes O'Breen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2611; -- Fozruk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2612; -- Lieutenant Valorcall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2616; -- Privateer Groy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2618; -- Hammerfall Peon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2619; -- Hammerfall Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2620; -- Prairie Dog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2621; -- Hammerfall Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2622; -- Sly Garrett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2625; -- Viznik Goldgrubber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2626; -- Old Man Heming
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2627; -- Grarnik Goodstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2628; -- Dalaran Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2634; -- Princess Poobah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2635; -- Elder Saltwater Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2636; -- Blackwater Deckhand
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2638; -- Syndicate Spectre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2639; -- Vilebranch Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2640; -- Vilebranch Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2641; -- Vilebranch Headhunter
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2642; -- Vilebranch Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2643; -- Vilebranch Berserker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2644; -- Vilebranch Hideskinner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2645; -- Vilebranch Shadow Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2646; -- Vilebranch Blood Drinker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2647; -- Vilebranch Soul Eater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2648; -- Vilebranch Aman'zasi Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2649; -- Witherbark Scalper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2650; -- Witherbark Zealot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2651; -- Witherbark Hideskinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2652; -- Witherbark Venomblood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2653; -- Witherbark Sadist
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2654; -- Witherbark Caller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2655; -- Green Sludge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2656; -- Jade Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2657; -- Trained Razorbeak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2658; -- Razorbeak Gryphon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2659; -- Razorbeak Skylord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2663; -- Narkk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2664; -- Kelsey Yance
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2668; -- Danielle Zipstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2669; -- Sheri Zipstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2670; -- Xizk Goodstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2672; -- Cowardly Crosby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2676; -- Compact Harvest Reaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2679; -- Wenna Silkbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2680; -- Vilebranch Wolf Pup
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2681; -- Vilebranch Raiding Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2682; -- Fradd Swiftgear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2684; -- Rizz Loosebolt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2685; -- Mazk Snipeshot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2686; -- Witherbark Broodguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2688; -- Ruppo Zipcoil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2691; -- Highvale Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2692; -- Highvale Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2693; -- Highvale Marksman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2694; -- Highvale Ranger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2695; -- Sara Balloo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2696; -- Foggy MacKreel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2697; -- Clyde Ranthal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2698; -- George Candarte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2699; -- Rikqiz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2700; -- Captain Nials
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2701; -- Dustbelcher Ogre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2703; -- Zengu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2704; -- Hanashi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2705; -- Brewmeister Bilger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2706; -- Tor'gan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2711; -- Phin Odelic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2712; -- Quae
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2713; -- Kinelory
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2714; -- Forsaken Courier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2715; -- Dustbelcher Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2716; -- Dustbelcher Wyrmhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2717; -- Dustbelcher Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2718; -- Dustbelcher Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2719; -- Dustbelcher Lord
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2720; -- Dustbelcher Ogre Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2721; -- Forsaken Bodyguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2723; -- Stone Golem
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2725; -- Scalding Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2726; -- Scorched Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2727; -- Crag Coyote
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2728; -- Feral Crag Coyote
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2729; -- Elder Crag Coyote
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2730; -- Rabid Crag Coyote
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2731; -- Ridge Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2732; -- Ridge Huntress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2733; -- Apothecary Jorell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2734; -- Ridge Stalker Patriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2735; -- Lesser Rock Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2736; -- Greater Rock Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2737; -- Durtham Greldon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2738; -- Stromgarde Cavalryman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2739; -- Shadowforge Tunneler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2740; -- Shadowforge Darkweaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2742; -- Shadowforge Chanter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2743; -- Shadowforge Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2745; -- Ambassador Infernus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2748; -- Archaedas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2752; -- Rumbler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2755; -- Myzrael
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2760; -- Burning Exile
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2761; -- Cresting Exile
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2762; -- Thundering Exile
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2764; -- Sleeby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2765; -- Znort
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2766; -- Lolo the Lookout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2767; -- First Mate Nilzlix
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2768; -- Professor Phizzlethorpe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2769; -- Captain Steelgut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2770; -- Tallow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2771; -- Drum Fel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2772; -- Korin Fel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2773; -- Or'Kalar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2774; -- Doctor Draxlegauge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2778; -- Deckhand Moishe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2780; -- Caretaker Nevlin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2781; -- Caretaker Weston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2782; -- Caretaker Alaric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2783; -- Marez Cowl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2784; -- King Magni Bronzebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2785; -- Theldurin the Lost
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2786; -- Gerrig Bonegrip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2787; -- Zaruk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2788; -- Apprentice Kryten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2789; -- Skuerto
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2790; -- Grand Mason Marblesten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2791; -- Enraged Rock Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2792; -- Gor'mul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2793; -- Kor'gresh Coldrage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2795; -- Lenny "Fingers" McCoy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2796; -- Faelyssa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2798; -- Pand Stonebinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2799; -- Lucian Fenner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2802; -- Susan Tillinghast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2803; -- Malygen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2804; -- Kurden Bloodclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2805; -- Deneb Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2806; -- Bale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2808; -- Vikki Lonsav
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2810; -- Hammon Karwn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2812; -- Drovnar Strongbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2814; -- Narj Deepslice
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2816; -- Androd Fadran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2817; -- Rigglefuzz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2818; -- Slagg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2819; -- Tunkk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2820; -- Graud
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2821; -- Keena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2829; -- Starving Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2830; -- Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2831; -- Giant Buzzard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2832; -- Nixxrax Fillamug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2834; -- Myizz Luckycatch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2835; -- Cedrik Prose
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2836; -- Brikk Keencraft
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2837; -- Jaxin Chong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2838; -- Crazk Sparks
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2839; -- Haren Kanmae
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2840; -- Kizz Bluntstrike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2842; -- Wigcik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2843; -- Jutak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2844; -- Hurklor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2845; -- Fargon Mortalak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2846; -- Blixrez Goodstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2847; -- Jansen Underwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2848; -- Glyx Brewright
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2849; -- Qixdi Goodstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2851; -- Urda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2852; -- Enslaved Druid of the Talon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2855; -- Snang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2856; -- Angrun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2857; -- Thund
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2858; -- Gringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2859; -- Gyll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2860; -- Sigrun Ironhew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2861; -- Gorrik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2878; -- Peria Lamenur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2888; -- Garek
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2892; -- Stonevault Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2893; -- Stonevault Bonesnapper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2894; -- Stonevault Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2906; -- Dustbelcher Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2907; -- Dustbelcher Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2908; -- Grawl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2909; -- Hammertoe Grez
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2910; -- Prospector Ryedol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2911; -- Archaeologist Flagongut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2912; -- Chief Archaeologist Greywhisker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2913; -- Archaeologist Hollee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2914; -- Snake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2916; -- Historian Karnik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2917; -- Prospector Remtravel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2918; -- Advisor Belgrum
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2920; -- Lucien Tosselwrench
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2921; -- Lotwil Veriatus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2922; -- Servo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2923; -- Mangy Silvermane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2924; -- Silvermane Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2925; -- Silvermane Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2926; -- Silvermane Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2927; -- Vicious Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2928; -- Primitive Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2929; -- Savage Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2930; -- Sentinel Glynda Nal'Shea
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2931; -- Zaricotl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2932; -- Magregan Deepshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2934; -- Keeper Bel'dugur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2941; -- Lanie Reed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2943; -- Ransin Donner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2944; -- Boss Tho'grun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2945; -- Murdaloc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2947; -- Harken Windtotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2948; -- Mull Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2949; -- Palemane Tanner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2950; -- Palemane Skinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2951; -- Palemane Poacher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2952; -- Bristleback Quilboar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2953; -- Bristleback Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2954; -- Bristleback Battleboar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2955; -- Plainstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2956; -- Adult Plainstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2957; -- Elder Plainstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2958; -- Prairie Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2959; -- Prairie Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2960; -- Prairie Wolf Alpha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2961; -- Mountain Cougar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2962; -- Windfury Harpy
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2963; -- Windfury Wind Witch
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2964; -- Windfury Sorceress
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 2965; -- Windfury Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2966; -- Battleboar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2967; -- Galak Centaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2968; -- Galak Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2969; -- Wiry Swoop
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2970; -- Swoop
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2971; -- Taloned Swoop
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2972; -- Kodo Calf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2973; -- Kodo Bull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2974; -- Kodo Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2975; -- Venture Co. Hireling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2976; -- Venture Co. Laborer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2977; -- Venture Co. Taskmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2978; -- Venture Co. Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2979; -- Venture Co. Supervisor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2980; -- Grull Hawkwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2981; -- Chief Hawkwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2982; -- Seer Graytongue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2984; -- Seer Wiserunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2985; -- Ruul Eagletalon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2986; -- Dorn Plainstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2987; -- Eyahn Eagletalon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2988; -- Morin Cloudstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2989; -- Bael'dun Digger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 2990; -- Bael'dun Appraiser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2991; -- Greatmother Hawkwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2993; -- Baine Bloodhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2994; -- Ancestral Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2995; -- Tal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2996; -- Torn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2997; -- Jyn Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2998; -- Karn Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 2999; -- Taur Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3000; -- Gibbert
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3001; -- Brek Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3002; -- Kurm Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3003; -- Fyr Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3004; -- Tepa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3005; -- Mahu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3007; -- Una
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3008; -- Mak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3009; -- Bena Winterhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3010; -- Mani Winterhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3011; -- Teg Dawnstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3012; -- Nata Dawnstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3013; -- Komin Winterhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3014; -- Nida Winterhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3015; -- Kuna Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3016; -- Tand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3017; -- Nan Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3018; -- Hogor Thunderhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3019; -- Delgo Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3020; -- Etu Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3021; -- Kard Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3022; -- Sunn Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3023; -- Sura Wildmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3024; -- Tah Winterhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3025; -- Kaga Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3026; -- Aska Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3027; -- Naal Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3028; -- Kah Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3029; -- Sewa Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3030; -- Siln Skychaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3031; -- Tigor Skychaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3032; -- Beram Skychaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3033; -- Turak Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3034; -- Sheal Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3035; -- Flatland Cougar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3036; -- Kym Wildmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3037; -- Sheza Wildmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3038; -- Kary Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3039; -- Holt Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3040; -- Urek Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3041; -- Torm Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3042; -- Sark Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3043; -- Ker Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3044; -- Miles Welsh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3045; -- Malakai Cross
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3046; -- Father Cobb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3047; -- Archmage Shymm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3048; -- Ursyn Ghull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3049; -- Thurston Xane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3050; -- Veren Tallstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3051; -- Supervisor Fizsprocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3052; -- Skorn Whitecloud
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3053; -- Synge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3054; -- Zarlman Two-Moons
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3055; -- Maur Raincaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3057; -- Cairne Bloodhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3058; -- Arra'chea
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3059; -- Harutt Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3060; -- Gart Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3061; -- Lanka Farshot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3062; -- Meela Dawnstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3063; -- Krang Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3064; -- Gennia Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3065; -- Yaw Sharpmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3066; -- Narm Skychaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3067; -- Pyall Silentstride
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3068; -- Mazzranache
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3069; -- Chaw Stronghide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3072; -- Kawnie Softbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3073; -- Marjak Keenblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3074; -- Varia Hardhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3075; -- Bronk Steelrage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3076; -- Moorat Longstride
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3077; -- Mahnott Roughwound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3078; -- Kennah Hawkseye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3079; -- Varg Windwhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3080; -- Harant Ironbrace
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3081; -- Wunna Darkmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3083; -- Honor Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3084; -- Bluffwatcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3085; -- Gloria Femmel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3086; -- Gretchen Vogel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3087; -- Crystal Boughman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3088; -- Henry Chapal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3089; -- Sherman Femmel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3090; -- Gerald Crawley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3091; -- Franklin Hamar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3092; -- Tagain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3093; -- Grod
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3095; -- Fela
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3096; -- Captured Servant of Azora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3097; -- Bernard Brubaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3098; -- Mottled Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3099; -- Dire Mottled Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3100; -- Elder Mottled Boar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3101; -- Vile Familiar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3102; -- Felstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3103; -- Makrura Clacker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3104; -- Makrura Shellhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3105; -- Makrura Snapclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3106; -- Pygmy Surf Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3107; -- Surf Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3108; -- Encrusted Surf Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3110; -- Dreadmaw Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3111; -- Razormane Quilboar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3112; -- Razormane Scout
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3113; -- Razormane Dustrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3114; -- Razormane Battleguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3115; -- Dustwind Harpy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3116; -- Dustwind Pillager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3117; -- Dustwind Savage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3118; -- Dustwind Storm Witch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3119; -- Kolkar Drudge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3120; -- Kolkar Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3121; -- Durotar Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3122; -- Bloodtalon Taillasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3123; -- Bloodtalon Scythemaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3124; -- Scorpid Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3125; -- Clattering Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3126; -- Armored Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3127; -- Venomtail Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3128; -- Kul Tiras Sailor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3129; -- Kul Tiras Marine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3130; -- Thunder Lizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3131; -- Lightning Hide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3133; -- Herble Baubbletump
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3134; -- Kzixx
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3135; -- Malissa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3136; -- Clarise Gnarltree
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3137; -- Matt Johnson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3138; -- Scott Carevin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3139; -- Gar'Thok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3140; -- Lar Prowltusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3141; -- Makrura Elder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3142; -- Orgnil Soulscar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3143; -- Gornek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3144; -- Eitrigg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3145; -- Zureetha Fargaze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3147; -- Furl Scornbrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3149; -- Nez'raz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3150; -- Hin Denburg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3153; -- Frang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3154; -- Jen'shan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3155; -- Rwag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3156; -- Nartok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3157; -- Shikrik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3158; -- Duokna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3159; -- Kzan Thornslash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3160; -- Huklah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3161; -- Rarc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3162; -- Burdrak Harglhelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3163; -- Uhgar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3164; -- Jark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3165; -- Ghrawt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3166; -- Cutac
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3167; -- Wuark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3168; -- Flakk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3169; -- Tarshaw Jaggedscar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3170; -- Kaplak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3171; -- Thotar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3172; -- Dhugru Gorelust
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3173; -- Swart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3174; -- Dwukk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3175; -- Krunn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3177; -- Turuk Amberstill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3178; -- Stuart Fleming
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3179; -- Harold Riggs
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3180; -- Dark Iron Entrepreneur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3181; -- Fremal Doohickey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3182; -- Junder Brokk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3183; -- Yarrog Baneshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3184; -- Miao'zan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3185; -- Mishiki
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3186; -- K'waii
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3187; -- Tai'tasi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3188; -- Master Gadrin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3189; -- Kor'ghan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3190; -- Rhinag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3191; -- Cook Torka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3192; -- Lieutenant Benedict
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3193; -- Misha Tor'kren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3194; -- Vel'rin Fang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3195; -- Burning Blade Thug
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3196; -- Burning Blade Neophyte
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3197; -- Burning Blade Fanatic
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3198; -- Burning Blade Apprentice
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3199; -- Burning Blade Cultist
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3203; -- Fizzle Darkstorm
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3204; -- Gazz'uz
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3205; -- Zalazane
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3206; -- Voodoo Troll
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3207; -- Hexed Troll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3208; -- Margoz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3209; -- Brave Windfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3210; -- Brave Proudsnout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3211; -- Brave Lightninghorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3212; -- Brave Ironhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3213; -- Brave Running Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3214; -- Brave Greathoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3215; -- Brave Strongbash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3216; -- Neeru Fireblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3217; -- Brave Dawneagle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3218; -- Brave Swiftwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3219; -- Brave Leaping Deer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3220; -- Brave Darksky
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3221; -- Brave Rockhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3222; -- Brave Wildrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3223; -- Brave Rainchaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3224; -- Brave Cloudmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3225; -- Corrupted Mottled Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3226; -- Corrupted Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3227; -- Corrupted Bloodtalon Scythemaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3228; -- Corrupted Surf Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3229; -- "Squealer" Thornmantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3231; -- Corrupted Dreadmaw Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3232; -- Bristleback Interloper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3233; -- Lorekeeper Raintotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3234; -- Lost Barrens Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3235; -- Greater Barrens Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3236; -- Barrens Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3237; -- Wooly Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3238; -- Stormhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3239; -- Thunderhead
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3240; -- Stormsnout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3241; -- Savannah Patriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3242; -- Zhevra Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3243; -- Savannah Highmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3244; -- Greater Plainstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3245; -- Ornery Plainstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3246; -- Fleeting Plainstrider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3247; -- Thunderhawk Hatchling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3248; -- Barrens Giraffe
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3249; -- Greater Thunderhawk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3250; -- Silithid Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3251; -- Silithid Grub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3252; -- Silithid Swarmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3254; -- Sunscale Lashtail
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3255; -- Sunscale Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3256; -- Sunscale Scytheclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3257; -- Ishamuhale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3258; -- Bristleback Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3260; -- Bristleback Water Seeker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3261; -- Bristleback Thornweaver
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3263; -- Bristleback Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3265; -- Razormane Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3266; -- Razormane Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3267; -- Razormane Water Seeker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3268; -- Razormane Thornweaver
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3269; -- Razormane Geomancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3270; -- Elder Mystic Razorsnout
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3271; -- Razormane Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3272; -- Kolkar Wrangler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3273; -- Kolkar Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3274; -- Kolkar Pack Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3275; -- Kolkar Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3276; -- Witchwing Harpy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3277; -- Witchwing Roguefeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3278; -- Witchwing Slayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3279; -- Witchwing Ambusher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3280; -- Witchwing Windcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3281; -- Sarkoth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3282; -- Venture Co. Mercenary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3283; -- Venture Co. Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3284; -- Venture Co. Drudger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3285; -- Venture Co. Peon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3286; -- Venture Co. Overseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3287; -- Hana'zua
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3290; -- Deek Fizzlebizz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3291; -- Greishan Ironstove
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3292; -- Brewmaster Drohn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3293; -- Rezlak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3294; -- Ophek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3296; -- Orgrimmar Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3297; -- Sen'jin Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3298; -- Gabrielle Chase
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3300; -- Adder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3304; -- Master Vornal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3305; -- Grisha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3306; -- Keldas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3309; -- Karus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3310; -- Doras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3312; -- Olvia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3313; -- Trak'gen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3314; -- Urtharo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3315; -- Tor'phan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3316; -- Handor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3317; -- Ollanus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3318; -- Koma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3319; -- Sana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3320; -- Soran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3321; -- Morgum
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3322; -- Kaja
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3323; -- Horthus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3324; -- Grol'dar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3325; -- Mirket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3326; -- Zevrost
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3327; -- Gest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3328; -- Ormok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3329; -- Kor'jus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3330; -- Muragus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3331; -- Kareth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3332; -- Lumak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3333; -- Shankys
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3334; -- Rekkul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3335; -- Hagrus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3336; -- Takrin Pathseeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3337; -- Kargal Battlescar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3338; -- Sergra Darkthorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3339; -- Captain Thalo'thas Brightsun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3341; -- Gann Stonespire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3342; -- Shan'ti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3344; -- Kardris Dreamseeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3345; -- Godan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3346; -- Kithas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3347; -- Yelmak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3348; -- Kor'geld
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3349; -- Ukra'nor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3350; -- Asoran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3351; -- Magenius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3352; -- Ormak Grimshot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3353; -- Grezz Ragefist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3354; -- Sorek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3355; -- Saru Steelfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3356; -- Sumi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3357; -- Makaru
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3358; -- Gorina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3359; -- Kiro
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3360; -- Koru
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3361; -- Shoma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3362; -- Ogunaro Wolfrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3363; -- Magar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3364; -- Borya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3365; -- Karolek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3366; -- Tamar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3367; -- Felika
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3368; -- Borstan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3369; -- Gotri
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3370; -- Urtrun Clanbringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3371; -- Tamaro
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3372; -- Sarlek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3373; -- Arnok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3374; -- Bael'dun Excavator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3375; -- Bael'dun Foreman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3376; -- Bael'dun Soldier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3377; -- Bael'dun Rifleman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3378; -- Bael'dun Officer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3379; -- Burning Blade Bruiser
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3380; -- Burning Blade Acolyte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3381; -- Southsea Brigand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3382; -- Southsea Cannoneer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3383; -- Southsea Cutthroat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3384; -- Southsea Privateer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3385; -- Theramore Marine
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3386; -- Theramore Preserver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3387; -- Jorn Skyseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3388; -- Mahren Skyseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3389; -- Regthar Deathgate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3390; -- Apothecary Helbrim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3391; -- Gazlowe
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3392; -- Prospector Khazgorm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3393; -- Captain Fairmount
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3394; -- Barak Kodobane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3396; -- Hezrul Bloodmark
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3397; -- Kolkar Bloodcharger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3398; -- Gesharahan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3399; -- Zamja
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3400; -- Xen'to
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3401; -- Shenthul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3402; -- Zando'zan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3403; -- Sian'tsu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3404; -- Jandi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3405; -- Zeal'aya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3406; -- Xor'juul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3407; -- Sian'dur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3408; -- Zel'mak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3409; -- Zendo'jian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3410; -- Jin'sora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3411; -- Denni'ka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3412; -- Nogg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3413; -- Sovik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3415; -- Savannah Huntress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3416; -- Savannah Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3418; -- Kirge Sternhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3419; -- Apothecary Zamah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3421; -- Feegly the Exiled
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3424; -- Thunderhawk Cloudscraper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3425; -- Savannah Prowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3426; -- Zhevra Charger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3428; -- Korran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3429; -- Thork
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3430; -- Mangletooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3431; -- Grenthar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3432; -- Mankrik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3433; -- Tatternack Steelforge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3434; -- Nak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3435; -- Lok Orcbane
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3436; -- Kuz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3438; -- Kreenig Snarlsnout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3439; -- Wizzlecrank's Shredder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3441; -- Melor Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3442; -- Sputtervalve
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3443; -- Grub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3444; -- Dig Rat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3445; -- Supervisor Lugwizzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3446; -- Mebok Mizzyrix
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3447; -- Pawe Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3448; -- Tonga Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3449; -- Darsok Swiftdagger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3450; -- Defias Companion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3452; -- Serena Bloodfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3453; -- Wharfmaster Dizzywig
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3456; -- Razormane Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3457; -- Razormane Stalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3458; -- Razormane Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3459; -- Razormane Warfrenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3461; -- Oasis Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3463; -- Wandering Barrens Giraffe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3464; -- Gazrog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3465; -- Gilthares Firebough
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3466; -- Zhevra Courser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3467; -- Baron Longshore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3468; -- Ancient of Lore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3469; -- Ancient of War
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3470; -- Rathorian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3471; -- Tinkerer Sniggles
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3472; -- Washte Pawne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3473; -- Owatanka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3474; -- Lakota'mani
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3475; -- Echeyakee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3476; -- Isha Awak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3477; -- Hraq
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3478; -- Traugh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3479; -- Nargal Deatheye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3480; -- Moorane Hearthgrain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3481; -- Barg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3482; -- Tari'qa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3483; -- Jahan Hawkwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3484; -- Kil'hala
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3485; -- Wrahk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3486; -- Halija Whitestrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3487; -- Kalyimah Stormcloud
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3488; -- Uthrok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3489; -- Zargh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3490; -- Hula'mahi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3491; -- Ironzar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3492; -- Vexspindle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3493; -- Grazlix
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3494; -- Tinkerwiz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3495; -- Gagsprocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3496; -- Fuzruckle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3497; -- Kilxx
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3498; -- Jazzik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3499; -- Ranik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3500; -- Tarhus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3501; -- Horde Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3502; -- Ratchet Bruiser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3503; -- Silithid Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3505; -- Pat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3507; -- Andi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3508; -- Mikey
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3510; -- Twain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3511; -- Steven
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3512; -- Jimmy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3513; -- Miss Danna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3514; -- Tenaron Stormgrip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3515; -- Corithras Moonrage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3516; -- Arch Druid Fandral Staghelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3517; -- Rellian Greenspyre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3518; -- Thomas Miller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3519; -- Sentinel Arynia Cloudsbreak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3520; -- Ol' Emma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3521; -- Ak'Zeloth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3522; -- Constance Brisboise
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3523; -- Bowen Brisboise
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3524; -- Spirit Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3528; -- Pyrewood Armorer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3530; -- Pyrewood Tailor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3532; -- Pyrewood Leatherworker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3534; -- Wallace the Blind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3535; -- Blackmoss the Fetid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3536; -- Kris Legace
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3537; -- Zixil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3538; -- Overwatch Mark I
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3539; -- Ott
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3540; -- Hal McAllister
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3541; -- Sarah Raycroft
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3542; -- Jaysin Lanyda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3543; -- Robert Aebischer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3544; -- Jason Lemieux
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3545; -- Claude Erksine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3546; -- Bernie Heisten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3547; -- Hamlin Atkins
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3548; -- Selina Weston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3549; -- Shelene Rhobart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3550; -- Martine Tramblay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3551; -- Patrice Dwyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3552; -- Alexandre Lefevre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3553; -- Sebastian Meloche
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3554; -- Andrea Boynton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3555; -- Johan Focht
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3556; -- Andrew Hilbert
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3557; -- Guillaume Sorouy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3561; -- Kyrai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3562; -- Alaindia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3566; -- Flatland Prowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3567; -- Tallonkai Swiftroot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3568; -- Mist
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3569; -- Bogling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3571; -- Teldrassil Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3572; -- Zizzek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3577; -- Dalaran Brewmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3578; -- Dalaran Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3583; -- Barithras Moonshade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3584; -- Therylune
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3585; -- Therysil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3587; -- Lyrai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3588; -- Khardan Proudblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3589; -- Keina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3590; -- Janna Brightmoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3591; -- Freja Nightwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3592; -- Andiss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3593; -- Alyissia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3594; -- Frahun Shadewhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3595; -- Shanda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3596; -- Ayanna Everstride
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3597; -- Mardant Strongoak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3598; -- Kyra Windblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3599; -- Jannok Breezesong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3600; -- Laurna Morninglight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3601; -- Dazalar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3602; -- Kal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3603; -- Cyndra Kindwhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3604; -- Malorne Bladeleaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3605; -- Nadyia Maneweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3606; -- Alanna Raveneye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3607; -- Androl Oakhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3608; -- Aldia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3609; -- Shalomon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3610; -- Jeena Featherbow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3611; -- Brannol Eaglemoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3612; -- Sinda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3613; -- Meri Ironweave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3614; -- Narret Shadowgrove
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3615; -- Devrak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3616; -- Onu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3620; -- Harruk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3621; -- Kurll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3622; -- Grokor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3624; -- Zudd
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3626; -- Jenn Langston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3629; -- David Langston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3630; -- Deviate Coiler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3631; -- Deviate Stinglash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3632; -- Deviate Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3633; -- Deviate Slayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3634; -- Deviate Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3636; -- Deviate Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3637; -- Deviate Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3638; -- Devouring Ectoplasm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3639; -- Sentinel Tysha Moonblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3640; -- Evolving Ectoplasm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3641; -- Deviate Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3644; -- Cerellean Whiteclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3649; -- Thundris Windweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3650; -- Asterion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3653; -- Kresh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3655; -- Mad Magglish
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3657; -- Sentinel Elissa Starbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3658; -- Lizzarik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3659; -- Jorb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3660; -- Athrikus Narassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3661; -- Balthule Shadowstrike
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3662; -- Delmanis the Hated
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3663; -- Delgren the Purifier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3664; -- Ilkrud Magthrull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3665; -- Crane Operator Bigglefuzz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3666; -- Wizbang Cranktoggle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3667; -- Anaya Dawnrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3669; -- Lord Cobrahn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3670; -- Lord Pythas
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3671; -- Lady Anacondra
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3672; -- Boahn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3673; -- Lord Serpentis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3674; -- Skum
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3678; -- Disciple of Naralex
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3681; -- Wisp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3682; -- Vrang Wildgore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3683; -- Kiknikle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3684; -- Pizznukle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3685; -- Harb Clawhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3688; -- Reban Freerunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3689; -- Laer Stepperunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3690; -- Kar Stormsinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3691; -- Raene Wolfrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3692; -- Volcor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3693; -- Terenthis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3695; -- Grimclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3696; -- Ran Bloodtooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3698; -- Bolyun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3700; -- Jadenvis Seawatcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3701; -- Tharnariun Treetender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3702; -- Alanndarian Nightsong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3703; -- Krulmoo Fullmoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3704; -- Mahani
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3705; -- Gahroot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3706; -- Tai'jin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3707; -- Ken'jai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3708; -- Gruna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3711; -- Wrathtail Myrmidon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3712; -- Wrathtail Razortail
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3713; -- Wrathtail Wave Rider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3715; -- Wrathtail Sea Witch
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3717; -- Wrathtail Sorceress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3721; -- Mystlash Hydra
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3725; -- Dark Strand Cultist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3727; -- Dark Strand Enforcer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3728; -- Dark Strand Adept
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3730; -- Dark Strand Excavator
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3732; -- Forsaken Seeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3733; -- Forsaken Herbalist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3734; -- Forsaken Thug
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3735; -- Apothecary Falthis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3736; -- Darkslayer Mordenthal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3737; -- Saltspittle Puddlejumper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3739; -- Saltspittle Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3740; -- Saltspittle Muckdweller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3742; -- Saltspittle Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3743; -- Foulweald Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3745; -- Foulweald Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3746; -- Foulweald Den Watcher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3748; -- Foulweald Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3749; -- Foulweald Ursa
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3750; -- Foulweald Totemic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3752; -- Xavian Rogue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3754; -- Xavian Betrayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3755; -- Xavian Felsworn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3757; -- Xavian Hellcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3758; -- Felmusk Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3759; -- Felmusk Rogue
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3762; -- Felmusk Felsworn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3763; -- Felmusk Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3765; -- Bleakheart Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3767; -- Bleakheart Trickster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3770; -- Bleakheart Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3771; -- Bleakheart Hellcaller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3772; -- Lesser Felguard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3773; -- Akkrilus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3774; -- Felslayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3779; -- Syurana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3780; -- Shadethicket Moss Eater
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3781; -- Shadethicket Wood Shaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3782; -- Shadethicket Stone Mover
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3783; -- Shadethicket Raincaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3784; -- Shadethicket Bark Ripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3789; -- Terrowulf Fleshripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3791; -- Terrowulf Shadow Weaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3797; -- Cenarion Protector
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3801; -- Severed Sleeper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3802; -- Severed Dreamer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3803; -- Severed Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3804; -- Forsaken Intruder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3806; -- Forsaken Infiltrator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3807; -- Forsaken Assassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3808; -- Forsaken Dark Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3809; -- Ashenvale Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3810; -- Elder Ashenvale Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3811; -- Giant Ashenvale Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3812; -- Clattering Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3814; -- Spined Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3815; -- Blink Dragon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3816; -- Wild Buck
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3817; -- Shadowhorn Stag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3818; -- Elder Shadowhorn Stag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3819; -- Wildthorn Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3820; -- Wildthorn Venomspitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3821; -- Wildthorn Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3823; -- Ghostpaw Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3824; -- Ghostpaw Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3825; -- Ghostpaw Alpha
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3833; -- Cenarion Vindicator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3834; -- Crazed Ancient
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3835; -- Biletoad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3836; -- Mountaineer Pebblebitty
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3838; -- Vesprystus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3840; -- Druid of the Fang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3841; -- Caylais Moonfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3842; -- Brombar Higgleby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3845; -- Shindrell Swiftfire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3846; -- Talen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3847; -- Orendil Broadleaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3848; -- Kayneth Stillwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3849; -- Deathstalker Adamant
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3850; -- Sorcerer Ashcrombe
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3851; -- Shadowfang Whitescalp
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3853; -- Shadowfang Moonwalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3855; -- Shadowfang Darksoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3857; -- Shadowfang Glutton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3859; -- Shadowfang Ragetooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3861; -- Bleak Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3862; -- Slavering Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3863; -- Lupine Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3864; -- Fel Steed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3866; -- Vile Bat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3868; -- Blood Seeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3873; -- Tormented Officer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3875; -- Haunted Servitor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3877; -- Wailing Guardsman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3880; -- Sentinel Melyria Frostshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3881; -- Grimtak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3882; -- Zlagk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3883; -- Moodan Sungrain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3884; -- Jhawna Oatwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3885; -- Sentinel Velene Starstrike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3886; -- Razorclaw the Butcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3887; -- Baron Silverlaine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3888; -- Korra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3890; -- Brakgul Deathbringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3891; -- Teronis' Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3892; -- Relara Whitemoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3894; -- Pelturas Whitemoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3897; -- Krolg
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3899; -- Balizar the Umbrage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3900; -- Caedakar the Vicious
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3901; -- Illiyana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3914; -- Rethilgore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3915; -- Dagri
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3916; -- Shael'dryn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3917; -- Befouled Water Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3919; -- Withered Ancient
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3920; -- Anilia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3921; -- Thistlefur Ursa
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3922; -- Thistlefur Totemic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3923; -- Thistlefur Den Watcher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3924; -- Thistlefur Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3925; -- Thistlefur Avenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3926; -- Thistlefur Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3927; -- Wolf Master Nandos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3928; -- Rotting Slime
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3931; -- Shadethicket Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3932; -- Bloodtooth Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3933; -- Hai'zan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3934; -- Innkeeper Boorand Plainswind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3935; -- Toddrick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3936; -- Shandris Feathermoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3937; -- Kira Songshine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3939; -- Razormane Wolf
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3940; -- Taneel Darkwood
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3941; -- Uthil Mooncall
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3942; -- Mavoris Cloudsbreak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3943; -- Ruuzel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3944; -- Wrathtail Priestess
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3945; -- Caravaneer Ruzzgot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3947; -- Goblin Shipbuilder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3948; -- Honni Goldenoat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3951; -- Bhaldaran Ravenshade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3952; -- Aeolynn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3953; -- Tandaan Lightmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3954; -- Dalria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3955; -- Shandrina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3956; -- Harklan Moongrove
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3958; -- Lardan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3959; -- Nantar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3960; -- Ulthaan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3961; -- Maliynn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3962; -- Haljan Oakheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3963; -- Danlaar Nightstride
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3964; -- Kylanna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3965; -- Cylania Rootstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3967; -- Aayndia Floralwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3969; -- Fahran Silentblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3970; -- Llana
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3974; -- Houndmaster Loksey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3975; -- Herod
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3976; -- Scarlet Commander Mograine
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3977; -- High Inquisitor Whitemane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3978; -- Sage Truthseeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3979; -- Librarian Mae Paledust
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3980; -- Raleigh the Devout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3981; -- Vorrel Sengutz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3982; -- Monika Sengutz
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 3983; -- Interrogator Vishas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3984; -- Nancy Vishas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3985; -- Grandpa Vishas
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3986; -- Sarilus Foulborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3987; -- Dal Bloodclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3988; -- Venture Co. Operator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3989; -- Venture Co. Logger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 3991; -- Venture Co. Deforester
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3992; -- Venture Co. Engineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3993; -- Venture Co. Machine Smith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3994; -- Keeper Albagorm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3995; -- Witch Doctor Jin'Zil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3996; -- Faldreas Goeth'Shael
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 3999; -- Windshear Digger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4003; -- Windshear Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4004; -- Windshear Overlord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4005; -- Deepmoss Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4006; -- Deepmoss Webspinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4007; -- Deepmoss Venomspitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4008; -- Cliff Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4009; -- Raging Cliff Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4011; -- Young Pridewing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4012; -- Pridewing Wyvern
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4013; -- Pridewing Skyhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4014; -- Pridewing Consort
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4015; -- Pridewing Patriarch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4016; -- Fey Dragon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4017; -- Wily Fey Dragon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4018; -- Antlered Courser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4019; -- Great Courser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4020; -- Sap Beast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4021; -- Corrosive Sap Beast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4022; -- Bloodfury Harpy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4023; -- Bloodfury Roguefeather
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4024; -- Bloodfury Slayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4025; -- Bloodfury Ambusher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4026; -- Bloodfury Windcaller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4027; -- Bloodfury Storm Witch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4028; -- Charred Ancient
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4029; -- Blackened Ancient
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4031; -- Fledgling Chimaera
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4032; -- Young Chimaera
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4034; -- Enraged Stone Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4035; -- Furious Stone Spirit
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4036; -- Rogue Flame Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4037; -- Burning Ravager
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4038; -- Burning Destroyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4040; -- Cave Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4041; -- Scorched Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4042; -- Singed Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4043; -- Galthuk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4044; -- Blackened Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4046; -- Magatha Grimtotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4047; -- Zor Lonetree
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4048; -- Falfindel Waywarder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4050; -- Cenarion Caretaker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4051; -- Cenarion Botanist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4052; -- Cenarion Druid
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4053; -- Daughter of Cenarius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4054; -- Laughing Sister
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4056; -- Mirkfallon Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4057; -- Son of Cenarius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4061; -- Mirkfallon Dryad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4062; -- Dark Iron Bombardier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4063; -- Feeboz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4064; -- Blackrock Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4065; -- Blackrock Sentry
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4066; -- Nal'taszar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4067; -- Twilight Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4070; -- Venture Co. Builder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4072; -- Prisoner of Jin'Zil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4073; -- XT:4
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4074; -- XT:9
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4075; -- Rat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4076; -- Roach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4077; -- Gaxim Rustfizzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4078; -- Collin Mauren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4079; -- Sentinel Thenysil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4080; -- Kaela Shadowspear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4081; -- Lomac Gearstrip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4082; -- Grawnal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4083; -- Jeeda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4084; -- Chylina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4085; -- Nizzik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4086; -- Veenix
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4087; -- Arias'ta Bladesinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4088; -- Elanaria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4089; -- Sildanair
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4090; -- Astarii Starseeker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4091; -- Jandria
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4092; -- Lariia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4093; -- Galak Wrangler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4094; -- Galak Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4095; -- Galak Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4096; -- Galak Windchaser
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4097; -- Galak Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4099; -- Galak Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4100; -- Screeching Harpy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4101; -- Screeching Roguefeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4104; -- Screeching Windcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4107; -- Highperch Wyvern
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4109; -- Highperch Consort
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4110; -- Highperch Patriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4111; -- Gravelsnout Kobold
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4112; -- Gravelsnout Vermin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4114; -- Gravelsnout Forager
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4116; -- Gravelsnout Surveyor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4117; -- Cloud Serpent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4118; -- Venomous Cloud Serpent
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4119; -- Elder Cloud Serpent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4120; -- Thundering Boulderkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4124; -- Needles Cougar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4126; -- Crag Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4127; -- Hecklefang Hyena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4128; -- Hecklefang Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4129; -- Hecklefang Snarler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4130; -- Silithid Searcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4131; -- Silithid Invader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4132; -- Silithid Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4133; -- Silithid Hive Drone
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4138; -- Jeen'ra Nightrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4139; -- Scorpid Terror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4140; -- Scorpid Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4142; -- Sparkleshell Tortoise
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4143; -- Sparkleshell Snapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4144; -- Sparkleshell Borer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4146; -- Jocaste
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4147; -- Saltstone Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4150; -- Saltstone Gazer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4151; -- Saltstone Crystalhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4154; -- Salt Flats Scavenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4155; -- Idriana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4156; -- Astaia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4158; -- Salt Flats Vulture
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4159; -- Me'lynn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4160; -- Ainethil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4161; -- Lysheana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4163; -- Syurna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4164; -- Cylania
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4165; -- Elissa Dumas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4166; -- Gazelle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4167; -- Dendrythis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4168; -- Elynna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4169; -- Jaeana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4170; -- Ellandrieth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4171; -- Merelyssa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4172; -- Anadyia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4173; -- Landria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4175; -- Vinasia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4177; -- Melea
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4180; -- Ealyshia Dewwhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4181; -- Fyrenna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4182; -- Dalmond
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4183; -- Naram Longclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4184; -- Geenia Sunshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4185; -- Shaldyn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4186; -- Mavralyn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4187; -- Harlon Thornguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4188; -- Illyanie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4189; -- Valdaron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4190; -- Kyndri
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4191; -- Allyndia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4192; -- Taldan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4193; -- Grondal Moonbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4194; -- Ullanna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4195; -- Tiyani
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4196; -- Silithid Swarm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4197; -- Ken'zigla
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4198; -- Braelyn Firehand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4200; -- Laird
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4201; -- Ziz Fizziks
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4202; -- Gerenzo Wrenchwhistle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4203; -- Ariyell Skyshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4204; -- Firodren Mooncaller
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4205; -- Dorion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4208; -- Lairn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4209; -- Garryeth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4210; -- Alegorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4211; -- Dannelor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4212; -- Telonis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4213; -- Taladan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4214; -- Erion Shadewhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4215; -- Anishar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4216; -- Chardryn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4217; -- Mathrengyl Bearwalker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4218; -- Denatharion
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4219; -- Fylerian Nightwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4220; -- Cyroen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4221; -- Talaelar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4222; -- Voloren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4223; -- Fyldan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4225; -- Saenorion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4226; -- Ulthir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4228; -- Vaean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4229; -- Mythrin'dir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4230; -- Yldan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4231; -- Kieran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4232; -- Glorandiir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4233; -- Mythidan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4234; -- Andrus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4235; -- Turian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4236; -- Cyridan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4240; -- Caynrus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4241; -- Mydrannul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4242; -- Frostsaber Companion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4243; -- Nightshade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4244; -- Shadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4248; -- Pesterhide Hyena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4249; -- Pesterhide Snarler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4250; -- Galak Packhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4251; -- Goblin Racer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4252; -- Gnome Racer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4253; -- Bear Form (Night Elf Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4254; -- Geofram Bouldertoe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4256; -- Golnir Bouldertoe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4258; -- Bengus Deepforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4259; -- Thurgrum Deepforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4260; -- Venture Co. Shredder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4261; -- Bear Form (Tauren Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4262; -- Darnassus Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4265; -- Nyoma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4266; -- Danlyia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4267; -- Daelyshia
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4273; -- Keeper Ordanus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4274; -- Fenrus the Devourer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4275; -- Archmage Arugal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4276; -- Piznik
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4278; -- Commander Springvale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4279; -- Odo the Blindwatcher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4280; -- Scarlet Preserver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4281; -- Scarlet Scout
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4282; -- Scarlet Magician
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4283; -- Scarlet Sentry
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4284; -- Scarlet Augur
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4285; -- Scarlet Disciple
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4286; -- Scarlet Soldier
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4287; -- Scarlet Gallant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4288; -- Scarlet Beastmaster
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4289; -- Scarlet Evoker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4290; -- Scarlet Guardsman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4291; -- Scarlet Diviner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4292; -- Scarlet Protector
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4293; -- Scarlet Scryer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4294; -- Scarlet Sorcerer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4295; -- Scarlet Myrmidon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4296; -- Scarlet Adept
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4297; -- Scarlet Conjuror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4298; -- Scarlet Defender
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4299; -- Scarlet Chaplain
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4300; -- Scarlet Wizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4301; -- Scarlet Centurion
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4302; -- Scarlet Champion
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4303; -- Scarlet Abbot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4304; -- Scarlet Tracking Hound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4305; -- Kriggon Talsone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4306; -- Scarlet Torturer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4307; -- Heldan Galesong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4308; -- Unfettered Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4309; -- Gorm Grimtotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4310; -- Cor Grimtotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4311; -- Holgar Stormaxe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4312; -- Tharm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4314; -- Gorkas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4316; -- Kolkar Packhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4317; -- Nyse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4319; -- Thyssiana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4320; -- Caelyb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4321; -- Baldruc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4323; -- Searing Hatchling
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4324; -- Searing Whelp
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4328; -- Firemane Scalebane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4329; -- Firemane Scout
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4331; -- Firemane Ash Tail
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4334; -- Firemane Flamecaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4339; -- Brimgore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4341; -- Drywallow Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4343; -- Drywallow Snapper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4344; -- Mottled Drywallow Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4345; -- Drywallow Daggermaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4346; -- Noxious Flayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4347; -- Noxious Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4348; -- Noxious Shredder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4351; -- Bloodfen Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4352; -- Bloodfen Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4356; -- Bloodfen Razormaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4357; -- Bloodfen Lashtail
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4359; -- Mirefin Murloc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4361; -- Mirefin Muckdweller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4362; -- Mirefin Coastrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4363; -- Mirefin Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4364; -- Strashaz Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4366; -- Strashaz Serpent Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4368; -- Strashaz Myrmidon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4370; -- Strashaz Sorceress
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4371; -- Strashaz Siren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4374; -- Strashaz Hydra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4376; -- Darkmist Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4378; -- Darkmist Recluse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4379; -- Darkmist Silkspinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4380; -- Darkmist Widow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4382; -- Withervine Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4385; -- Withervine Rager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4387; -- Withervine Mire Beast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4388; -- Young Murk Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4389; -- Murk Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4390; -- Elder Murk Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4393; -- Acidic Swamp Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4394; -- Bubbling Swamp Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4397; -- Mudrock Spikeshell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4401; -- Muckshell Clacker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4403; -- Muckshell Pincer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4404; -- Muckshell Scrabbler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4407; -- Teloren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4408; -- Aquatic Form (Night Elf Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4409; -- Gatekeeper Kordurus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4410; -- Aquatic Form (Tauren Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4412; -- Darkfang Creeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4414; -- Darkfang Venomspitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4415; -- Giant Darkfang Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4416; -- Defias Strip Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4417; -- Defias Taskmaster
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4418; -- Defias Wizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4419; -- Race Master Kronkrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4420; -- Overlord Ramtusk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4421; -- Charlga Razorflank
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4422; -- Agathelos the Raging
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4423; -- Darnassian Protector
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4424; -- Aggem Thorncurse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4425; -- Blind Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4427; -- Ward Guardian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4428; -- Death Speaker Jargba
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4429; -- Goblin Pit Crewman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4430; -- Gnome Pit Crewman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4435; -- Razorfen Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4436; -- Razorfen Quilguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4437; -- Razorfen Warden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4438; -- Razorfen Spearhide
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4440; -- Razorfen Totemic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4442; -- Razorfen Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4444; -- Deathstalker Vincent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4451; -- Auld Stonespire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4452; -- Kravel Koalbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4453; -- Wizzle Brassbolts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4454; -- Fizzle Brassbolts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4455; -- Red Jack Flint
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4456; -- Fiora Longears
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4457; -- Murkgill Forager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4458; -- Murkgill Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4459; -- Murkgill Oracle
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4460; -- Murkgill Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4461; -- Murkgill Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4462; -- Blackrock Hunter
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4463; -- Blackrock Summoner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4464; -- Blackrock Gladiator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4465; -- Vilebranch Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4466; -- Vilebranch Scalper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4467; -- Vilebranch Soothsayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4468; -- Jade Sludge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4469; -- Emerald Ooze
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4472; -- Haunting Vision
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4474; -- Rotting Cadaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4475; -- Blighted Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4479; -- Fardel Dabyrie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4480; -- Kenata Dabyrie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4481; -- Marcel Dabyrie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4483; -- Moktar Krin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4484; -- Feero Ironhand
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4485; -- Belgrom Rockmaul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4486; -- Genavie Callow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4488; -- Parqual Fintallas
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4489; -- Braug Dimspirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4493; -- Scarlet Avenger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4494; -- Scarlet Spellbinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4495; -- Gnome Pit Boss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4496; -- Goblin Pit Boss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4498; -- Maurin Bonesplitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4499; -- Rok'Alim the Pounder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4500; -- Overlord Mok'Morokk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4501; -- Draz'Zilb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4502; -- Tharg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4503; -- Mudcrush Durtfeet
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4505; -- Bloodsail Deckhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4506; -- Bloodsail Swabby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4507; -- Daisy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4508; -- Willix the Importer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4510; -- Heralath Fallowbrook
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4511; -- Agam'ar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4512; -- Rotting Agam'ar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4514; -- Raging Agam'ar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4515; -- Death's Head Acolyte
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4516; -- Death's Head Adept
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4517; -- Death's Head Priest
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4518; -- Death's Head Sage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4519; -- Death's Head Seer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4520; -- Razorfen Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4521; -- Treshala Fallowbrook
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4522; -- Razorfen Dustweaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4523; -- Razorfen Groundshaker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4525; -- Razorfen Earthbreaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4526; -- Wind Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4528; -- Stone Rumbler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4530; -- Razorfen Handler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4531; -- Razorfen Beast Trainer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4532; -- Razorfen Beastmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4534; -- Tamed Hyena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4535; -- Tamed Battleboar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4538; -- Kraul Bat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4539; -- Greater Kraul Bat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4540; -- Scarlet Monk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4541; -- Blood of Agamaggan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4542; -- High Inquisitor Fairbanks
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4543; -- Bloodmage Thalnos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4544; -- Krueg Skullsplitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4545; -- Nag'zehn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4546; -- Bor'zehn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4547; -- Tarkreu Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4548; -- Steelsnap
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4549; -- William Montague
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4550; -- Ophelia Montague
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4551; -- Michael Garrett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4552; -- Eunice Burch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4553; -- Ronald Burch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4554; -- Tawny Grisette
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4555; -- Eleanor Rusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4556; -- Gordon Wendham
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4557; -- Louis Warren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4558; -- Lauren Newcomb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4559; -- Timothy Weldon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4560; -- Walter Ellingson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4561; -- Daniel Bartlett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4562; -- Thomas Mordan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4563; -- Kaal Soulreaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4564; -- Luther Pickman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4565; -- Richard Kerwin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4566; -- Kaelystia Hatebringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4567; -- Pierce Shackleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4568; -- Anastasia Hartwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4569; -- Charles Seaton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4570; -- Sydney Upton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4571; -- Morley Bates
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4572; -- Silas Zimmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4573; -- Armand Cromwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4574; -- Lizbeth Cromwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4575; -- Hannah Akeley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4576; -- Josef Gregorian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4577; -- Millie Gregorian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4578; -- Josephine Lister
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4580; -- Lucille Castleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4581; -- Salazar Bloch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4582; -- Carolyn Ward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4583; -- Miles Dexter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4584; -- Gregory Charles
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4585; -- Ezekiel Graves
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4586; -- Graham Van Talen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4587; -- Elizabeth Van Talen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4588; -- Arthur Moore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4589; -- Joseph Moore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4590; -- Jonathan Chambers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4591; -- Mary Edras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4592; -- Nathaniel Steenwick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4593; -- Christoph Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4594; -- Angela Curthas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4595; -- Baltus Fowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4596; -- James Van Brunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4597; -- Samuel Van Brunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4598; -- Brom Killian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4599; -- Sarah Killian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4600; -- Geoffrey Hartwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4601; -- Francis Eliot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4602; -- Benijah Fenner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4603; -- Nicholas Atwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4604; -- Abigail Sawyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4605; -- Basil Frye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4606; -- Aelthalyste
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4607; -- Father Lankester
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4608; -- Father Lazarus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4609; -- Doctor Marsh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4610; -- Algernon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4611; -- Doctor Herbert Halsey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4612; -- Boyle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4613; -- Christopher Drakul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4614; -- Martha Alliestar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4615; -- Katrina Alliestar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4616; -- Lavinia Crowe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4617; -- Thaddeus Webb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4618; -- Martek the Exiled
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4619; -- Geltharis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4620; -- Fobeed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4623; -- Quilguard Champion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4624; -- Booty Bay Bruiser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4625; -- Death's Head Ward Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4629; -- Trackmaster Zherin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4630; -- Pozzik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4631; -- Wharfmaster Lozgil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4632; -- Kolkar Centaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4633; -- Kolkar Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4634; -- Kolkar Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4635; -- Kolkar Windchaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4636; -- Kolkar Battle Lord
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4637; -- Kolkar Destroyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4638; -- Magram Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4639; -- Magram Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4640; -- Magram Wrangler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4641; -- Magram Windchaser
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4642; -- Magram Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4643; -- Magram Pack Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4644; -- Magram Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4645; -- Magram Mauler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4646; -- Gelkis Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4647; -- Gelkis Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4648; -- Gelkis Stamper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4649; -- Gelkis Windchaser
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4651; -- Gelkis Earthcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4652; -- Gelkis Mauler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4653; -- Gelkis Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4654; -- Maraudine Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4655; -- Maraudine Wrangler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4656; -- Maraudine Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4657; -- Maraudine Windchaser
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4658; -- Maraudine Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4659; -- Maraudine Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4661; -- Gelkis Rumbler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4662; -- Magram Bonepaw
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4663; -- Burning Blade Augur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4664; -- Burning Blade Reaver
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4665; -- Burning Blade Adept
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4666; -- Burning Blade Felsworn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4667; -- Burning Blade Shadowmage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4668; -- Burning Blade Summoner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4670; -- Hatefury Rogue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4671; -- Hatefury Trickster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4672; -- Hatefury Felsworn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4673; -- Hatefury Betrayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4674; -- Hatefury Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4675; -- Hatefury Hellcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4676; -- Lesser Infernal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4677; -- Doomwarder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4678; -- Mana Eater
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4679; -- Nether Maiden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4680; -- Doomwarder Captain
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4681; -- Mage Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4682; -- Nether Sister
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4684; -- Nether Sorceress
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4685; -- Ley Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4686; -- Deepstrider Giant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4687; -- Deepstrider Searcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4688; -- Bonepaw Hyena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4689; -- Starving Bonepaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4690; -- Rabid Bonepaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4692; -- Dread Swoop
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4693; -- Dread Flyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4694; -- Dread Ripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4695; -- Carrion Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4696; -- Scorpashi Snapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4697; -- Scorpashi Lasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4699; -- Scorpashi Venomlash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4700; -- Aged Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4701; -- Dying Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4702; -- Ancient Kodo
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4705; -- Burning Blade Invoker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4706; -- Razzeric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4707; -- Zuzubee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4708; -- Shreev
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4709; -- Zamek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4711; -- Slitherblade Naga
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4712; -- Slitherblade Sorceress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4713; -- Slitherblade Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4714; -- Slitherblade Myrmidon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4715; -- Slitherblade Razortail
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4716; -- Slitherblade Tidehunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4718; -- Slitherblade Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4719; -- Slitherblade Sea Witch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4720; -- Rizzle Brassbolts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4721; -- Zangen Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4722; -- Rau Cliffrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4723; -- Foreman Cozzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4726; -- Raging Thunder Lizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4727; -- Elder Thunder Lizard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4728; -- Gritjaw Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4729; -- Hulking Gritjaw Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4730; -- Lelanai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4731; -- Zachariah Post
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4732; -- Randal Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4752; -- Kildar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4753; -- Jartsam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4772; -- Ultham Ironhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4773; -- Velma Warnam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4775; -- Felicia Doan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4779; -- Brown Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4782; -- Truk Wildbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4783; -- Dawnwatcher Selgorm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4784; -- Argent Guard Manados
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4786; -- Dawnwatcher Shaedlass
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4787; -- Argent Guard Thaelrid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4788; -- Fallenroot Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4789; -- Fallenroot Rogue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4791; -- Nazeer Bloodpike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4792; -- "Swamp Eye" Jarl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4794; -- Morgan Stern
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4798; -- Fallenroot Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4799; -- Fallenroot Hellcaller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4802; -- Blackfathom Tide Priestess
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4803; -- Blackfathom Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4805; -- Blackfathom Sea Witch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4807; -- Blackfathom Myrmidon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4809; -- Twilight Acolyte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4810; -- Twilight Reaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4811; -- Twilight Aquamancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4812; -- Twilight Loreseeker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4813; -- Twilight Shadowmage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4814; -- Twilight Elementalist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4815; -- Murkshallow Snapclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4818; -- Blindlight Murloc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4819; -- Blindlight Muckdweller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4820; -- Blindlight Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4821; -- Skittering Crustacean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4822; -- Snapping Crustacean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4823; -- Barbed Crustacean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4824; -- Aku'mai Fisher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4825; -- Aku'mai Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4827; -- Deep Pool Threshfin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4829; -- Aku'mai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4830; -- Old Serra'kis
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4831; -- Lady Sarevess
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4832; -- Twilight Lord Kelris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4834; -- Theramore Infiltrator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4841; -- Deadmire
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4842; -- Earthcaller Halmgar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4844; -- Shadowforge Surveyor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4845; -- Shadowforge Ruffian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4846; -- Shadowforge Digger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4847; -- Shadowforge Relic Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4848; -- Shadowforge Darkcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4849; -- Shadowforge Archaeologist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4850; -- Stonevault Cave Lurker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4851; -- Stonevault Rockchewer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4852; -- Stonevault Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4853; -- Stonevault Geomancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4854; -- Grimlok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4855; -- Stonevault Brawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4856; -- Stonevault Cave Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4857; -- Stone Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4860; -- Stone Steward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4861; -- Shrike Bat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4863; -- Jadespine Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4872; -- Obsidian Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4875; -- Turhaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4876; -- Jawn Highmesa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4877; -- Jandia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4878; -- Montarr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4879; -- Ogg'marr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4880; -- "Stinky" Ignatz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4883; -- Krak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4884; -- Zulrg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4885; -- Gregor MacVince
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4886; -- Hans Weston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4887; -- Ghamoo-ra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4888; -- Marie Holdston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4889; -- Torq Ironblast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4890; -- Piter Verance
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4891; -- Dwane Wertle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4892; -- Jensen Farran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4893; -- Bartender Lillian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4894; -- Craig Nollward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4895; -- Smiling Jim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4896; -- Charity Mipsy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4897; -- Helenia Olden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4898; -- Brant Jasperbloom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4899; -- Uma Bartulm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4900; -- Alchemist Narett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4901; -- Sara Pierce
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4902; -- Mikal Pierce
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4921; -- Guard Byron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4922; -- Guard Edward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4923; -- Guard Jarad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4924; -- Combat Master Criton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4926; -- Krog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4941; -- Caz Twosprocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4943; -- Mosarn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4944; -- Captain Garran Vimes
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4945; -- Goblin Drag Car
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4946; -- Gnome Drag Car
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4948; -- Adjutant Tesoran
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4949; -- Thrall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4950; -- Spot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4951; -- Theramore Practicing Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4952; -- Theramore Combat Dummy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4953; -- Moccasin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4954; -- Uttnar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4959; -- Jorgen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4961; -- Dashel Stonefist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4962; -- Tapoke "Slim" Jahn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4963; -- Mikhail
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4964; -- Commander Samaul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4965; -- Pained
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4966; -- Private Hendel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4967; -- Archmage Tervosh
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 4968; -- Lady Jaina Proudmoore
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4971; -- Slim's Friend
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4973; -- Guard Lasiter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4974; -- Aldwin Laughlin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4978; -- Aku'mai Servant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4979; -- Theramore Guard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4980; -- Paval Reethe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4981; -- Ben Trias
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 4983; -- Ogron
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 4996; -- Injured Stockade Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5047; -- Ellaercia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5048; -- Deviate Adder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5049; -- Lyesa Steelbrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5052; -- Edward Remington
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5053; -- Deviate Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5054; -- Krumn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5055; -- Deviate Lasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5056; -- Deviate Dreadfang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5057; -- Theramore Deserter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5058; -- Wolfguard Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5082; -- Vincent Hyal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5083; -- Clerk Lendry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5085; -- Sentry Point Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5086; -- Captain Wymor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5087; -- Do'gol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5089; -- Balos Jacken
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5090; -- Combat Master Szigeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5091; -- Guard Kahil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5092; -- Guard Lana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5093; -- Guard Narrisha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5094; -- Guard Tark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5095; -- Captain Andrews
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5096; -- Captain Thomas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5099; -- Soleil Stonemantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5100; -- Fillius Fizzlespinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5101; -- Bryllia Ironbrand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5102; -- Dolman Steelfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5103; -- Grenil Steelfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5106; -- Bromiir Ormsen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5107; -- Mangorn Flinthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5108; -- Raena Flinthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5109; -- Myra Tyrngaarde
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5110; -- Barim Jurgenstaad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5111; -- Innkeeper Firebrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5112; -- Gwenna Firebrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5113; -- Kelv Sternhammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5114; -- Bilban Tosslespanner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5115; -- Daera Brightspear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5116; -- Olmin Burningbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5117; -- Regnus Thundergranite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5118; -- Brogun Stoneshield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5119; -- Hegnar Swiftaxe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5120; -- Brenwyn Wintersteel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5121; -- Kelomir Ironhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5122; -- Skolmin Goldfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5123; -- Bretta Goldfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5124; -- Sognar Cliffbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5125; -- Dolkin Craghelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5126; -- Olthran Craghelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5127; -- Fimble Finespindle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5128; -- Bombus Finespindle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5129; -- Lissyphus Finespindle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5130; -- Jondor Steelbrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5132; -- Pithwick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5133; -- Harick Boulderdrum
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5137; -- Reyna Stonebranch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5138; -- Gwina Stonebranch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5140; -- Edris Barleybeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5141; -- Theodrus Frostbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5142; -- Braenna Flintcrag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5143; -- Toldren Deepiron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5144; -- Bink
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5145; -- Juli Stormkettle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5146; -- Nittlebur Sparkfizzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5147; -- Valgar Highforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5148; -- Beldruk Doombrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5149; -- Brandur Ironhammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5150; -- Nissa Firestone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5151; -- Ginny Longberry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5152; -- Bingus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5153; -- Jormund Stonebrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5154; -- Poranna Snowbraid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5155; -- Ingrys Stonebrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5156; -- Maeva Snowbraid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5157; -- Gimble Thistlefuzz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5158; -- Tilli Thistlefuzz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5159; -- Daryl Riknussun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5160; -- Emrul Riknussun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5161; -- Grimnur Stonebrand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5162; -- Tansy Puddlefizz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5163; -- Burbik Gearspanner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5164; -- Grumnus Steelshaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5165; -- Hulfdan Blackbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5166; -- Ormyr Flinteye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5167; -- Fenthwick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5169; -- Tynnus Venomsprout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5170; -- Hjoldir Stoneblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5171; -- Thistleheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5172; -- Briarthorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5173; -- Alexander Calder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5174; -- Springspindle Fizzlegear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5175; -- Gearcutter Cogspinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5177; -- Tally Berryfizz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5178; -- Soolie Berryfizz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5184; -- Theramore Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5188; -- Garyl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5189; -- Thrumn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5190; -- Merill Pleasance
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5191; -- Shalumon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5193; -- Rebecca Laughlin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5195; -- Brown Riding Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5198; -- Arctic Riding Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5199; -- Medic Tamberlyn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5200; -- Medic Helaina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5202; -- Archery Target
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5204; -- Apothecary Zinge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5224; -- Murk Slitherer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5225; -- Murk Spitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5229; -- Gordunni Ogre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5232; -- Gordunni Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5234; -- Gordunni Mauler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5235; -- Fungal Ooze
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5236; -- Gordunni Shaman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5237; -- Gordunni Ogre Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5238; -- Gordunni Battlemaster
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5239; -- Gordunni Mage-Lord
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5240; -- Gordunni Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5241; -- Gordunni Warlord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5243; -- Cursed Atal'ai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5244; -- Zukk'ash Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5245; -- Zukk'ash Wasp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5246; -- Zukk'ash Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5247; -- Zukk'ash Tunneler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5249; -- Woodpaw Mongrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5251; -- Woodpaw Trapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5253; -- Woodpaw Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5254; -- Woodpaw Mystic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5255; -- Woodpaw Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5258; -- Woodpaw Alpha
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5259; -- Atal'ai Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5260; -- Groddoc Ape
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5261; -- Enthralled Atal'ai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5262; -- Groddoc Thunderer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5263; -- Mummified Atal'ai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5268; -- Ironfur Bear
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5269; -- Atal'ai Priest
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5271; -- Atal'ai Deathwalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5272; -- Grizzled Ironfur Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5274; -- Ironfur Patriarch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5276; -- Sprite Dragon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5278; -- Sprite Darter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5280; -- Nightmare Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5286; -- Longtooth Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5287; -- Longtooth Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5288; -- Rabid Longtooth
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5291; -- Hakkari Frostwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5292; -- Feral Scar Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5293; -- Hulking Feral Scar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5295; -- Enraged Feral Scar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5296; -- Rage Scar Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5297; -- Elder Rage Scar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5299; -- Ferocious Rage Scar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5300; -- Frayfeather Hippogryph
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5304; -- Frayfeather Stagwing
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5305; -- Frayfeather Skystormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5306; -- Frayfeather Patriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5307; -- Vale Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5308; -- Rogue Vale Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5312; -- Lethlas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5314; -- Phantim
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5317; -- Jademir Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5319; -- Jademir Tree Warder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5320; -- Jademir Boughguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5327; -- Coast Crawl Snapclaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5328; -- Coast Crawl Deepseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5331; -- Hatecrest Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5332; -- Hatecrest Wave Rider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5333; -- Hatecrest Serpent Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5334; -- Hatecrest Myrmidon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5335; -- Hatecrest Screamer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5336; -- Hatecrest Sorceress
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5337; -- Hatecrest Siren
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5343; -- Lady Szallah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5350; -- Qirot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5353; -- Itharius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5356; -- Snarler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5357; -- Land Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5358; -- Cliff Giant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5359; -- Shore Strider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5360; -- Deep Strider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5361; -- Wave Strider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5362; -- Northspring Harpy
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5363; -- Northspring Roguefeather
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5364; -- Northspring Slayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5366; -- Northspring Windcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5385; -- Watcher Mahar Ba
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5387; -- High Explorer Magellas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5388; -- Ingo Woolybush
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5389; -- Prospector Gunstan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5390; -- Sage Palerunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5391; -- Galen Goodward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5392; -- Yarr Hammerstone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5393; -- Quartermaster Lungertz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5394; -- Neeka Bloodscar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5395; -- Felgur Twocuts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5396; -- Captain Pentigast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5397; -- Uthek the Wise
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5398; -- Warug
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5401; -- Kazkaz the Unholy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5403; -- Riding White Stallion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5404; -- Black Stallion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5405; -- Pinto
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5406; -- Palomino
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5407; -- Nightmare
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5411; -- Krinkle Goodsteel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5412; -- Gurda Wildmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5414; -- Apothecary Faustin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5416; -- Infiltrator Marksen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5418; -- Deathstalker Zraedus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5419; -- Glasshide Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5420; -- Glasshide Gazer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5421; -- Glasshide Petrifier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5422; -- Scorpid Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5423; -- Scorpid Tail Lasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5424; -- Scorpid Dunestalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5425; -- Starving Blisterpaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5426; -- Blisterpaw Hyena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5427; -- Rabid Blisterpaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5428; -- Roc
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5429; -- Fire Roc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5430; -- Searing Roc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5431; -- Surf Glider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5441; -- Hazzali Wasp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5450; -- Hazzali Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5451; -- Hazzali Swarmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5452; -- Hazzali Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5453; -- Hazzali Tunneler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5454; -- Hazzali Sandreaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5455; -- Centipaar Wasp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5456; -- Centipaar Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5457; -- Centipaar Swarmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5458; -- Centipaar Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5459; -- Centipaar Tunneler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5460; -- Centipaar Sandreaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5461; -- Sea Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5462; -- Sea Spray
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5464; -- Watchmaster Sorigal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5465; -- Land Rager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5466; -- Coast Strider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5467; -- Deep Dweller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5469; -- Dune Smasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5471; -- Dunemaul Ogre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5472; -- Dunemaul Enforcer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5473; -- Dunemaul Ogre Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5474; -- Dunemaul Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5475; -- Dunemaul Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5476; -- Watcher Biggs
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5477; -- Noboru the Cudgel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5479; -- Wu Shen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5480; -- Ilsa Corbin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5481; -- Thistleshrub Dew Collector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5482; -- Stephen Ryback
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5483; -- Erika Tate
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5485; -- Thistleshrub Rootshaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5490; -- Gnarled Thistleshrub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5493; -- Arnold Leland
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5494; -- Catherine Leland
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5499; -- Lilyssia Nightbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5500; -- Tel'Athir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5501; -- Kaerbrus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5503; -- Eldraeith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5508; -- Strumner Flintheel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5523; -- War Party Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5543; -- Clarice Foster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5546; -- Grunt Zuul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5547; -- Grunt Tharlak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5564; -- Simon Tanner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5565; -- Jillian Tanner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5566; -- Tannysa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5568; -- Captured Leper Gnome
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5570; -- Bruuk Barleybeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5591; -- Dar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5592; -- Tok'Kar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5593; -- Katar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5594; -- Alchemist Pestlezugg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5595; -- Ironforge Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5597; -- Grunt Komak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5598; -- Atal'ai Exile
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5599; -- Kon Yelloweyes
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5600; -- Khan Dez'hepah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5601; -- Khan Jehn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5602; -- Khan Shaka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5603; -- Grunt Mojka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5605; -- Tisa Martine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5606; -- Goma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5607; -- Roger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5608; -- Jamin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5609; -- Zazo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5610; -- Kozish
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5611; -- Barkeep Morag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5612; -- Gimrizz Shadowcog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5613; -- Doyo'da
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5614; -- Sarok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5615; -- Wastewander Rogue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5616; -- Wastewander Thief
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5617; -- Wastewander Shadow Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5618; -- Wastewander Bandit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5620; -- Bartender Wental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5622; -- Ongeku
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5623; -- Wastewander Assassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5624; -- Undercity Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5634; -- Rhapsody Shindigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5635; -- Falstad Wildhammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5636; -- Gryphon Master Talonaxe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5637; -- Roetten Stonehammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5638; -- Kreldig Ungor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5639; -- Craven Drok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5640; -- Keldran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5641; -- Takata Steelblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5642; -- Vahlarriel Demonslayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5643; -- Tyranis Malem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5644; -- Dalinda Malem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5645; -- Sandfury Hideskinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5646; -- Sandfury Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5647; -- Sandfury Firecaller
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5648; -- Sandfury Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5649; -- Sandfury Blood Drinker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5650; -- Sandfury Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5651; -- Patrick Garrett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5652; -- Undercity Practice Dummy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5653; -- Tyler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5654; -- Edward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5655; -- Robert Gossom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5656; -- Richard Van Brunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5657; -- Marla Fowler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5658; -- Chloe Curthas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5659; -- Andrew Hartwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5660; -- Riley Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5661; -- Brother Malach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5662; -- Sergeant Houser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5663; -- Travist Bosk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5664; -- Eldin Partridge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5665; -- Alyssa Blaye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5667; -- Venya Marthand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5668; -- Mattie Alred
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5669; -- Helena Atwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5670; -- Edrick Killian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5674; -- Practice Target
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5675; -- Carendin Halgar
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5679; -- Lysta Bancroft
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5680; -- Male Human Captive
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5681; -- Female Human Captive
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5682; -- Dalin Forgewright
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5683; -- Comar Villard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5685; -- Captive Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5686; -- Captive Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5687; -- Captive Abomination
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5688; -- Innkeeper Renee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5690; -- Clyde Kellen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5693; -- Godrick Farsan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5695; -- Vance Undergloom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5696; -- Gerard Abernathy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5697; -- Theresa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5698; -- Joanna Whitehall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5699; -- Leona Tharpe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5700; -- Samantha Shackleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5701; -- Selina Pickman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5702; -- Jezelle Pruitt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5703; -- Winifred Kerwin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5704; -- Adrian Bartlett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5705; -- Victor Bartholomew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5706; -- Davitt Hickson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5707; -- Reginald Grimsford
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5710; -- Jammal'an the Prophet
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5711; -- Ogom the Wretched
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5712; -- Zolo
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5715; -- Hukku
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5717; -- Mijan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5718; -- Rothos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5724; -- Ageron Kargal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5725; -- Deathguard Lundmark
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5726; -- Jezelle's Felhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5729; -- Jezelle's Voidwalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5730; -- Jezelle's Imp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5731; -- Apothecary Vallia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5732; -- Apothecary Katrina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5733; -- Apothecary Lycanus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5734; -- Apothecary Keever
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5735; -- Caged Human Female
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5736; -- Caged Human Male
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5738; -- Caged Dwarf Male
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5739; -- Caged Squirrel
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5744; -- Cedric Stumpel
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5747; -- Hepzibah Sedgewick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5748; -- Killian Sanatha
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5749; -- Kayla Smithe
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5750; -- Gina Lang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5752; -- Corporal Melkins
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5753; -- Martha Strain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5754; -- Zane Bradford
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5755; -- Deviate Viper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5756; -- Deviate Venomwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5757; -- Lilly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5758; -- Leo Sarn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5759; -- Nurse Neela
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5760; -- Lord Azrethoc
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5761; -- Deviate Shambler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5765; -- Ruzan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5766; -- Savannah Cub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5767; -- Nalpak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5768; -- Ebru
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5769; -- Arch Druid Hamuul Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5770; -- Nara Wildmane
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5771; -- Jugkar Grim'rod
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5774; -- Riding Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5775; -- Verdan the Everliving
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5782; -- Crildor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5783; -- Kalldan Felmoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5784; -- Waldor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5785; -- Sister Hatelash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5786; -- Snagglespear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5787; -- Enforcer Emilgund
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5792; -- Drag Master Miglen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5797; -- Aean Swiftriver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5798; -- Thora Feathermoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5799; -- Hannah Bladeleaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5800; -- Marcus Bel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5806; -- Treant Ally
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5807; -- The Rake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5808; -- Warlord Kolkanis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5810; -- Uzzek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5811; -- Kamari
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5812; -- Tumi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5814; -- Innkeeper Thulbek
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5815; -- Kurgul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5816; -- Katis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5817; -- Shimra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5819; -- Mirelle Tremayne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5820; -- Gillian Moore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5821; -- Sheldon Von Croy
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5822; -- Felweaver Scornn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5823; -- Death Flayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5824; -- Captain Flat Tusk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5826; -- Geolord Mottle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5828; -- Humar the Pridelord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5829; -- Snort the Heckler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5830; -- Sister Rathtalon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5831; -- Swiftmane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5833; -- Margol the Rager
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5834; -- Azzere the Skyblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5836; -- Engineer Whirleygig
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5837; -- Stonearm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5838; -- Brokespear
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5839; -- Dark Iron Geologist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5840; -- Dark Iron Steamsmith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5841; -- Rocklance
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5842; -- Takk the Leaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5843; -- Slave Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5844; -- Dark Iron Slaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5846; -- Dark Iron Taskmaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5849; -- Digger Flameforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5850; -- Blazing Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5852; -- Inferno Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5853; -- Tempered War Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5854; -- Heavy War Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5855; -- Magma Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5856; -- Glassweb Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5857; -- Searing Lava Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5858; -- Greater Lava Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5859; -- Hagg Taurenbane
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5860; -- Twilight Dark Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5861; -- Twilight Fire Guard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5862; -- Twilight Geomancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5863; -- Geopriest Gukk'rok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5870; -- Krond
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5871; -- Larhka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5875; -- Gan'rul Bloodeye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5878; -- Thun'grim Firegaze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5880; -- Un'Thuwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5881; -- Cursed Sycamore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5882; -- Pephredo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5883; -- Enyo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5884; -- Mai'ah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5885; -- Deino
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5886; -- Gwyn Farrow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5887; -- Canaga Earthcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5888; -- Seer Ravenfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5890; -- Redrock Earth Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5891; -- Minor Manifestation of Earth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5892; -- Searn Firewarder
UPDATE `creature_template` SET `UnitClass` = 2, `ArmorMultiplier` = 1 WHERE `Entry` = 5893; -- Minor Manifestation of Fire
UPDATE `creature_template` SET `UnitClass` = 2, `ArmorMultiplier` = 1 WHERE `Entry` = 5894; -- Corrupt Minor Manifestation of Water
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5897; -- Corrupt Water Spirit
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5899; -- Brine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5900; -- Telf Joolam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5901; -- Islen Waterseer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5902; -- Minor Manifestation of Air
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5905; -- Prate Cloudseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5906; -- Xanis Flameweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5907; -- Kranal Fiss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5908; -- Grunt Dogran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5909; -- Cazul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5910; -- Zankaja
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5911; -- Grunt Logmar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5915; -- Brother Ravenoak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5917; -- Clara Charles
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5928; -- Sorrow Wing
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5930; -- Sister Riven
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5931; -- Foreman Rigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5932; -- Taskmaster Whipfang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5933; -- Achellios the Banished
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5938; -- Uthan Stillwater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5939; -- Vira Younghoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5940; -- Harn Longcast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5941; -- Lau'Tiki
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5942; -- Zansoa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5943; -- Rawrk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5944; -- Yonada
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5951; -- Hare
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5952; -- Den Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5953; -- Razor Hill Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5955; -- Tooga
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5957; -- Birgitte Cranston
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5958; -- Thuul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5974; -- Dreadmaul Ogre
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5975; -- Dreadmaul Ogre Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5976; -- Dreadmaul Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5977; -- Dreadmaul Mauler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 5978; -- Dreadmaul Warlock
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 5979; -- Wretched Lost One
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5982; -- Black Slayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5983; -- Bonepicker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5984; -- Starving Snickerfang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5985; -- Snickerfang Hyena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5988; -- Scorpok Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5990; -- Redstone Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5991; -- Redstone Crystalhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5992; -- Ashmane Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5993; -- Helboar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5994; -- Zayus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5996; -- Nethergarde Miner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5997; -- Nethergarde Engineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5998; -- Nethergarde Foreman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 5999; -- Nethergarde Soldier
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6000; -- Nethergarde Cleric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6001; -- Nethergarde Analyst
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6002; -- Nethergarde Riftwatcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6003; -- Nethergarde Officer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6004; -- Shadowsworn Cultist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6005; -- Shadowsworn Thug
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6006; -- Shadowsworn Adept
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6007; -- Shadowsworn Enforcer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6008; -- Shadowsworn Warlock
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6009; -- Shadowsworn Dreadweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6010; -- Felhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6011; -- Felguard Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6014; -- X'yera
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6015; -- Torta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6018; -- Ur'kyo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6019; -- Hornizz Brimbuzzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6020; -- Slimeshell Makrura
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6026; -- Breyk
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6027; -- Kitha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6028; -- Burkrum
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6030; -- Thorvald Deepforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6031; -- Tormus Deepforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6033; -- Lake Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6034; -- Lotherias
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6035; -- Razorfen Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6068; -- Warug's Bodyguard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6070; -- Maraudine Khan Advisor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6072; -- Diathorus the Seeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6073; -- Searing Infernal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6086; -- Auberdine Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6087; -- Astranaar Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6089; -- Harry Burlguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6090; -- Bartleby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6091; -- Dellylah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6093; -- Dead-Tooth Jack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6094; -- Byancie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6114; -- Muren Stormpike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6115; -- Roaming Felguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6116; -- Highborne Apparition
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6117; -- Highborne Lichling
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6119; -- Tog Rustsprocket
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6120; -- Lago Blackwrench
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6121; -- Remen Marcot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6123; -- Dark Iron Spy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6124; -- Captain Beld
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6125; -- Haldarr Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6126; -- Haldarr Trickster
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6127; -- Haldarr Felsworn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6128; -- Vorlus Vilehoof
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6129; -- Draconic Magelord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6130; -- Blue Scalebane
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6131; -- Draconic Mageweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6132; -- Razorfen Servitor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6134; -- Lord Arkkoroc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6135; -- Arkkoran Clacker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6136; -- Arkkoran Muckdweller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6137; -- Arkkoran Pincer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6138; -- Arkkoran Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6139; -- Highperch Soarer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6140; -- Hetaera
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6141; -- Pridewing Soarer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6142; -- Mathiel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6143; -- Servant of Arkkoroc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6144; -- Son of Arkkoroc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6145; -- School of Fish
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6146; -- Cliff Breaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6147; -- Cliff Thunderer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6148; -- Cliff Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6166; -- Yorus Barleybrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6167; -- Chimaera Matriarch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6168; -- Roogug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6169; -- Klockmort Spannerspan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6170; -- Gutspill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6174; -- Stephanie Turner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6175; -- John Turner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6176; -- Bath'rah the Windwatcher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6178; -- Muiredon Battleforge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6179; -- Tiza Battleforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6181; -- Jordan Stilwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6182; -- Daphne Stilwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6184; -- Timbermaw Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6185; -- Timbermaw Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6186; -- Timbermaw Totemic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6187; -- Timbermaw Den Watcher
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6188; -- Timbermaw Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6189; -- Timbermaw Ursa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6190; -- Spitelash Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6193; -- Spitelash Screamer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6194; -- Spitelash Serpent Guard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6195; -- Spitelash Siren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6196; -- Spitelash Myrmidon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6198; -- Blood Elf Surveyor
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6199; -- Blood Elf Reclaimer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6200; -- Legashi Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6201; -- Legashi Rogue
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6202; -- Legashi Hellcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6206; -- Caverndeep Burrower
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6207; -- Caverndeep Ambusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6211; -- Caverndeep Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6212; -- Dark Iron Agent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6218; -- Irradiated Slime
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6219; -- Corrosive Lurker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6220; -- Irradiated Horror
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6221; -- Addled Leper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6222; -- Leprous Technician
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6223; -- Leprous Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6224; -- Leprous Machinesmith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6225; -- Mechano-Tank
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6226; -- Mechano-Flamewalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6227; -- Mechano-Frostwalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6228; -- Dark Iron Ambassador
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6229; -- Crowd Pummeler 9-60
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6230; -- Peacekeeper Security Suit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6232; -- Arcane Nullifier X-21
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6233; -- Mechanized Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6234; -- Mechanized Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6235; -- Electrocutioner 6000
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6236; -- Klannoc Macleod
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6241; -- Bailor Stonehand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6243; -- Gelihast
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6244; -- Takar the Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6248; -- Twiggy Flathead
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6249; -- Affray Spectator
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6251; -- Strahad Farsan
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6252; -- Acolyte Magaz
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6253; -- Acolyte Fenrick
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6254; -- Acolyte Wytula
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6266; -- Menara Voidrender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6271; -- Mouse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6272; -- Innkeeper Janene
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6286; -- Zarrin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6287; -- Radnaal Maneweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6288; -- Jayla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6289; -- Rand Rhobart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6290; -- Yonn Deepcut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6291; -- Balthus Stoneflayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6292; -- Eladriel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6293; -- Jorah Annison
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6294; -- Krom Stoutarm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6295; -- Wilma Ranthal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6297; -- Kurdram Stonehammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6298; -- Thelgrum Stonehammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6299; -- Delfrum Flintbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6300; -- Elisa Steelhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6301; -- Gorbold Steelhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6306; -- Helene Peltskinner
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6328; -- Dannie Fizzwizzle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6329; -- Irradiated Pillager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6347; -- Young Wavethrasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6348; -- Wavethrasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6349; -- Great Wavethrasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6350; -- Makrinni Razorclaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6351; -- Storm Bay Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6352; -- Coralshell Lurker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6366; -- Kurzen Mindslave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6367; -- Donni Anthania
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6368; -- Cat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6369; -- Coralshell Tortoise
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6370; -- Makrinni Scrabbler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6371; -- Storm Bay Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6372; -- Makrinni Snapclaw
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6373; -- Dane Winslow
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6374; -- Cylina Darkheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6375; -- Thunderhead Hippogryph
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6376; -- Wren Darkspring
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6377; -- Thunderhead Stagwing
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6378; -- Thunderhead Skystormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6379; -- Thunderhead Patriarch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6380; -- Thunderhead Consort
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6382; -- Jubahl Corpseseeker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6387; -- Dranh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6389; -- Deathguard Podrig
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6391; -- Holdout Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6392; -- Holdout Medic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6393; -- Henen Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6394; -- Ruga Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6395; -- Sergeant Rutger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6407; -- Holdout Technician
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6408; -- Ula'elek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6410; -- Orm Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6411; -- Velora Nitely
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6426; -- Anguished Dead
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6427; -- Haunting Phantasm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6446; -- Therzok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6466; -- Gamon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6467; -- Mennet Carkad
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6487; -- Arcanist Doan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6488; -- Fallen Champion
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6490; -- Azshir the Sleepless
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6491; -- Spirit Healer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6494; -- Tazan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6495; -- Riznek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6496; -- Brivelthwerp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6497; -- Astor Hadren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6498; -- Devilsaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6499; -- Ironhide Devilsaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6500; -- Tyrant Devilsaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6501; -- Stegodon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6502; -- Plated Stegodon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6503; -- Spiked Stegodon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6504; -- Thunderstomp Stegodon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6505; -- Ravasaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6506; -- Ravasaur Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6507; -- Ravasaur Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6508; -- Venomhide Ravasaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6509; -- Bloodpetal Lasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6510; -- Bloodpetal Flayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6511; -- Bloodpetal Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6512; -- Bloodpetal Trapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6513; -- Un'Goro Stomper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6514; -- Un'Goro Gorilla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6516; -- Un'Goro Thunderer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6517; -- Tar Beast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6518; -- Tar Lurker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6519; -- Tar Lord
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6520; -- Scorching Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6521; -- Living Blaze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6522; -- Andron Gant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6523; -- Dark Iron Rifleman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6527; -- Tar Creeper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6546; -- Tabetha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6547; -- Suffering Victim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6548; -- Magus Tirth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6551; -- Gorishi Wasp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6552; -- Gorishi Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6553; -- Gorishi Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6554; -- Gorishi Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6555; -- Gorishi Tunneler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6556; -- Muculent Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6557; -- Primal Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6559; -- Glutinous Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6560; -- Stone Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6566; -- Estelle Gendry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6567; -- Ghok'kah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6568; -- Vizzklick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6569; -- Gnoarn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6570; -- Fenwick Thatros
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6571; -- Cat Form (Night Elf Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6572; -- Cat Form (Tauren Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6573; -- Travel Form (Druid)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6574; -- Jun'ha
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6575; -- Scarlet Trainee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6576; -- Brienna Starglow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6577; -- Bingles Blastenheimer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6581; -- Ravasaur Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6582; -- Clutchmother Zavas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6583; -- Gruff
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6584; -- King Mosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6585; -- Uhk'loc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6586; -- Rokar Bladeshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6606; -- Overseer Glibby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6607; -- Harroc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6626; -- "Plucky" Johnson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6651; -- Gatekeeper Rageroar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6653; -- Huge Toad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6666; -- "Plucky" Johnson's Human Form
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6667; -- Gelkak Gyromast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6668; -- Lord Cyrik Blackforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6669; -- The Threshwackonator 4100
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6670; -- Westfall Woodworker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6706; -- Baritanas Skyriver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6707; -- Fahrad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6726; -- Thalon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6727; -- Innkeeper Brianna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6728; -- Narnie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6730; -- Jinky Twizzlefixxit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6731; -- Harlown Darkweave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6732; -- Amie Pierce
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6733; -- Stonevault Basher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6734; -- Innkeeper Hearthstove
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6735; -- Innkeeper Saelienne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6736; -- Innkeeper Keldamyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6737; -- Innkeeper Shaussiy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6738; -- Innkeeper Kimlya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6739; -- Innkeeper Bates
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6740; -- Innkeeper Allison
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6741; -- Innkeeper Norman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6746; -- Innkeeper Pala
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6747; -- Innkeeper Kauth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6749; -- Erma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6766; -- Ravenholdt Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6768; -- Lord Jorach Ravenholdt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6771; -- Ravenholdt Assassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6774; -- Falkhaan Isenstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6775; -- Antur Fallow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6776; -- Magrin Rivermane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6777; -- Zan Shivsproket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6778; -- Melika Isenstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6779; -- Smudge Thunderwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6780; -- Porthannius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6781; -- Melarith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6782; -- Hands Springsprocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6784; -- Calvin Montague
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6785; -- Ratslin Maime
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6786; -- Ukor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6787; -- Yelnagi Blackarm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6788; -- Den Mother
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6789; -- Thistle Cub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6790; -- Innkeeper Trelayne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6791; -- Innkeeper Wiley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6806; -- Tannok Frosthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6807; -- Innkeeper Skindle
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6826; -- Talvash del Kissel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6846; -- Defias Dockmaster
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 6868; -- Jarkal Mossmeld
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6886; -- Onin MacHammar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6887; -- Yalda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6906; -- Baelog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6907; -- Eric "The Swift"
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6908; -- Olaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6909; -- Sethir the Ancient
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6910; -- Revelosh
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 6912; -- Remains of a Paladin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6927; -- Defias Dockworker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6928; -- Innkeeper Grosk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6929; -- Innkeeper Gryshka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6930; -- Innkeeper Karakul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6946; -- Renzik "The Shiv"
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6966; -- Lucius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6986; -- Dran Droffers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 6987; -- Malton Droffers
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7007; -- Tiev Mordune
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7009; -- Arantir
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7010; -- Zilzibin Drumlore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7011; -- Earthen Rocksmasher
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7012; -- Earthen Sculptor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7016; -- Lady Vespira
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7017; -- Lord Sinslayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7022; -- Venomlash Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7023; -- Obsidian Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7024; -- Agent Kearnen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7025; -- Blackrock Soldier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7026; -- Blackrock Sorcerer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7027; -- Blackrock Slayer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7028; -- Blackrock Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7029; -- Blackrock Battlemaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7030; -- Shadowforge Geologist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7031; -- Obsidian Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7032; -- Greater Obsidian Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7033; -- Firegut Ogre
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7034; -- Firegut Ogre Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7035; -- Firegut Brute
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7036; -- Thaurissan Spy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7037; -- Thaurissan Firewalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7038; -- Thaurissan Agent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7039; -- War Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7040; -- Black Dragonspawn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7041; -- Black Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7042; -- Flamescale Dragonspawn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7043; -- Flamescale Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7044; -- Black Drake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7045; -- Scalding Drake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7046; -- Searscale Drake
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7047; -- Black Broodling
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7048; -- Scalding Broodling
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7049; -- Flamescale Broodling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7050; -- Defias Drone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7051; -- Malformed Defias Drone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7052; -- Defias Tower Patroller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7053; -- Klaven Mortwake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7055; -- Blackrock Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7056; -- Defias Tower Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7057; -- Digmaster Shovelphlange
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7067; -- Venture Co. Drone
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7068; -- Condemned Acolyte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7069; -- Condemned Monk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7070; -- Condemned Cleric
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7071; -- Cursed Paladin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7072; -- Cursed Justicar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7075; -- Writhing Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7076; -- Earthen Guardian
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7077; -- Earthen Hallshaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7078; -- Cleft Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7079; -- Viscous Fallout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7086; -- Cursed Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7087; -- Killian Hagey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7088; -- Thuwd
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7089; -- Mooranta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7092; -- Tainted Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7093; -- Vile Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7097; -- Ironbeak Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7098; -- Ironbeak Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7099; -- Ironbeak Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7100; -- Warpwood Moss Flayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7101; -- Warpwood Shredder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7104; -- Dessecus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7105; -- Jadefire Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7106; -- Jadefire Rogue
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7107; -- Jadefire Trickster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7108; -- Jadefire Betrayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7109; -- Jadefire Felsworn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7110; -- Jadefire Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7111; -- Jadefire Hellcaller
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7112; -- Jaedenar Cultist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7113; -- Jaedenar Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7114; -- Jaedenar Enforcer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7115; -- Jaedenar Adept
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7118; -- Jaedenar Darkweaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7120; -- Jaedenar Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7125; -- Jaedenar Hound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7126; -- Jaedenar Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7132; -- Toxic Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7136; -- Infernal Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7137; -- Immolatus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7138; -- Irontree Wanderer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7139; -- Irontree Stomper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7149; -- Withered Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7153; -- Deadwood Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7154; -- Deadwood Gardener
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7155; -- Deadwood Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7156; -- Deadwood Den Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7157; -- Deadwood Avenger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7158; -- Deadwood Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7161; -- Wrenix the Wretched
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7166; -- Wrenix's Gizmotronic Apparatus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7170; -- Thragomm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7175; -- Stonevault Ambusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7206; -- Ancient Stone Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7207; -- Doc Mixilpixil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7208; -- Noarm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7230; -- Shayis Steelfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7231; -- Kelgruk Bloodaxe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7233; -- Taskmaster Fizzule
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7234; -- Ferocitas the Dream Eater
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7235; -- Gnarlpine Mystic
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7246; -- Sandfury Shadowhunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7247; -- Sandfury Soul Eater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7269; -- Scarab
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7271; -- Witch Doctor Zum'rah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7272; -- Theka the Martyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7274; -- Sandfury Executioner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7287; -- Foreman Silixiz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7288; -- Grand Foreman Puzik Gallywix
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7290; -- Shadowforge Sharpshooter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7291; -- Galgann Firehammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7292; -- Dinita Stonemantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7294; -- Shim'la
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7296; -- Corand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7297; -- Gothard Winslow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7298; -- Demnul Farmountain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7307; -- Venture Co. Lookout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7308; -- Venture Co. Patroller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7309; -- Earthen Custodian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7310; -- Mutated Venture Co. Drone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7311; -- Uthel'nay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7312; -- Dink
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7313; -- Priestess A'moora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7315; -- Darnath Bladesinger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7316; -- Sister Aquinne
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7317; -- Oben Rageclaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7318; -- Rageclaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7319; -- Lady Sathrah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7320; -- Stonevault Mauler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7321; -- Stonevault Flameweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7323; -- Winstone Wolfe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7324; -- Simone Cantrell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7325; -- Master Kang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7327; -- Withered Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7328; -- Withered Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7329; -- Withered Quilguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7332; -- Withered Spearhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7333; -- Withered Battle Boar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7334; -- Battle Boar Horror
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7335; -- Death's Head Geomancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7337; -- Death's Head Necromancer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7341; -- Skeletal Frostweaver
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7342; -- Skeletal Summoner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7343; -- Splinterbone Skeleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7344; -- Splinterbone Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7345; -- Splinterbone Captain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7346; -- Splinterbone Centurion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7347; -- Boneflayer Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7348; -- Thorn Eater Ghoul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7352; -- Frozen Soul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7353; -- Freezing Spirit
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7357; -- Mordresh Fire Eye
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7358; -- Amnennar the Coldbringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7363; -- Kum'isha the Collector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7369; -- Deadwind Brute
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7370; -- Restless Shade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7371; -- Deadwind Mauler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7372; -- Deadwind Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7376; -- Sky Shadow
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7379; -- Deadwind Ogre Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7381; -- Silver Tabby Cat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7382; -- Orange Tabby Cat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7384; -- Cornish Rex Cat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7385; -- Bombay Cat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7389; -- Senegal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7390; -- Cockatiel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7395; -- Cockroach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7396; -- Earthen Stonebreaker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7397; -- Earthen Stonecarver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7404; -- Galak Flame Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7405; -- Deadly Cleft Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7406; -- Oglethorpe Obnoticus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7407; -- Chief Engineer Bilgewhizzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7408; -- Spigot Operator Luglunket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7427; -- Taim Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7428; -- Frostmaul Giant
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7429; -- Frostmaul Preserver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7430; -- Frostsaber Cub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7431; -- Frostsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7432; -- Frostsaber Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7433; -- Frostsaber Huntress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7434; -- Frostsaber Pride Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7435; -- Cobalt Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7436; -- Cobalt Scalebane
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7437; -- Cobalt Mageweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7438; -- Winterfall Ursa
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7439; -- Winterfall Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7440; -- Winterfall Den Watcher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7441; -- Winterfall Totemic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7442; -- Winterfall Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7443; -- Shardtooth Mauler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7444; -- Shardtooth Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7445; -- Elder Shardtooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7446; -- Rabid Shardtooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7447; -- Fledgling Chillwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7448; -- Chillwind Chimaera
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7449; -- Chillwind Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7450; -- Ragged Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7451; -- Raging Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7452; -- Crazed Owlbeast
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7453; -- Moontouched Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7454; -- Berserk Owlbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7455; -- Winterspring Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7456; -- Winterspring Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7457; -- Rogue Ice Thistle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7458; -- Ice Thistle Yeti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7459; -- Ice Thistle Matriarch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7460; -- Ice Thistle Patriarch
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7461; -- Hederine Initiate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7462; -- Hederine Manastalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7463; -- Hederine Slayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7485; -- Nargatt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7489; -- Silverpine Deathguard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7505; -- Bloodmage Drazial
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7506; -- Bloodmage Lynnore
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7523; -- Suffering Highborne
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7524; -- Anguished Highborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7546; -- Bronze Whelpling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7547; -- Azure Whelpling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7548; -- Faeling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7551; -- Dart Frog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7553; -- Great Horned Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7554; -- Snowy Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7555; -- Hawk Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7556; -- Eagle Owl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7558; -- Cottontail Rabbit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7559; -- Spotted Rabbit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7561; -- Albino Snake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7562; -- Brown Snake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7564; -- Marin Noggenfogger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7565; -- Black Kingsnake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7567; -- Crimson Snake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7570; -- Elven Wisp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7572; -- Fallen Hero of the Horde
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7583; -- Sprinkle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7584; -- Wandering Forest Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7603; -- Leprous Assistant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7604; -- Sergeant Bly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7605; -- Raven
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7606; -- Oro Eyegouge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7607; -- Weegli Blastfuse
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7608; -- Murta Grimgut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7623; -- Dispatch Commander Ruag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7643; -- Bengor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7665; -- Grol the Destroyer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7666; -- Archmage Allistarj
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7667; -- Lady Sevine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7668; -- Servant of Razelikh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7669; -- Servant of Grol
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7670; -- Servant of Allistarj
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7671; -- Servant of Sevine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7683; -- Alessandro Luca
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7714; -- Innkeeper Byula
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7724; -- Senior Surveyor Fizzledowser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7725; -- Grimtotem Raider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7726; -- Grimtotem Naturalist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7727; -- Grimtotem Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7728; -- Kirith the Damned
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7730; -- Stonetalon Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7731; -- Innkeeper Jayka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7733; -- Innkeeper Fizzgrimble
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7734; -- Ilifar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7735; -- Felcular
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7736; -- Innkeeper Shyria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7737; -- Innkeeper Greul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7740; -- Gracina Spiritmight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7744; -- Innkeeper Thulfram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7763; -- Curgle Cranklehop
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7764; -- Troyas Moonbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7765; -- Rockbiter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7770; -- Winkey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7771; -- Marvon Rivetseeker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7773; -- Marli Wishrunner
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7774; -- Shay Leafrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7775; -- Gregan Brewspewer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7776; -- Talo Thornhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7777; -- Rok Orhan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7778; -- Doran Steelwing
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7779; -- Priestess Tyriona
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7780; -- Rin'ji
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7783; -- Loramus Thalipedes
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7784; -- Homing Robot OOX-17/TN
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7790; -- Orokk Omosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7791; -- Theka the Martyr Shapeshift
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7792; -- Aturk the Anvil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7793; -- Ox
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7794; -- McGavan
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7795; -- Hydromancer Velratha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7799; -- Gimblethorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7800; -- Mekgineer Thermaplugg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7801; -- Gilveradin Sunchaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7802; -- Galvan the Ancient
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7804; -- Trenton Lighthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7806; -- Homing Robot OOX-09/HL
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7807; -- Homing Robot OOX-22/FE
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7823; -- Bera Stonehammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7824; -- Bulkrek Ragefist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7825; -- Oran Snakewrithe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7826; -- Ambassador Ardalan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7843; -- Gnomeregan Evacuee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7847; -- Caliph Scorpidsting
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7849; -- Mobile Alert System
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7850; -- Kernobee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7851; -- Nethergarde Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7852; -- Pratt McGrubben
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7853; -- Scooty
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7854; -- Jangdor Swiftstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7855; -- Southsea Pirate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7856; -- Southsea Freebooter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7857; -- Southsea Dock Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7858; -- Southsea Swashbuckler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7864; -- Lingering Highborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7865; -- Wildhammer Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7866; -- Peter Galen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7867; -- Thorkaf Dragoneye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7868; -- Sarah Tanner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7869; -- Brumn Winterhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7870; -- Caryssia Moonhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7871; -- Se'Jib
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7872; -- Death's Head Cultist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7873; -- Razorfen Battleguard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7874; -- Razorfen Thornweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7875; -- Hadoken Swiftstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7876; -- Tran'rek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7877; -- Latronicus Moonspear
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7878; -- Vestia Moonspear
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7879; -- Quintis Jonespyre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7880; -- Ginro Hearthkindle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7881; -- Stoley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7882; -- Security Chief Bilgewhizzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7883; -- Andre Firebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7884; -- Fraggar Thundermantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7885; -- Spitelash Battlemaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7886; -- Spitelash Enchantress
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7895; -- Ambassador Bloodrage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7897; -- Alarm-a-bomb 2600
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7898; -- Pirate treasure trigger mob
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7900; -- Angelas Moonbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7903; -- Jewel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7904; -- Jacob
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7907; -- Daryn Lightwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7916; -- Erelas Ambersky
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7936; -- Lyon Mountainheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7937; -- High Tinker Mekkatorque
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7939; -- Feathermoon Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7940; -- Darnall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7941; -- Mardrack Greenwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7942; -- Faralorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7943; -- Harklane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7944; -- Tinkmaster Overspark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7945; -- Savanne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7946; -- Brannock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7947; -- Vivianna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7948; -- Kylanna Windwhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7949; -- Xylinnia Starshine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7950; -- Master Mechanic Castpipe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7951; -- Zas'Tysh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7952; -- Zjolnir
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7953; -- Xar'Ti
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7954; -- Binjy Featherwhistle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7955; -- Milli Featherwhistle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7956; -- Kindal Moonweaver
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7957; -- Jer'kai Moonweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7975; -- Mulgore Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7976; -- Thalgus Thunderfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7977; -- Gammerita
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7978; -- Bimble Longberry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7980; -- Deathguard Elite
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7995; -- Vile Priestess Hexx
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 7996; -- Qiaga the Keeper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7997; -- Captured Sprite Darter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 7998; -- Blastmaster Emi Shortfuse
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 7999; -- Tyrande Whisperwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8015; -- Ashenvale Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8016; -- Barrens Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8018; -- Guthrum Thunderfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8019; -- Fyldren Moonfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8020; -- Shyn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8021; -- Orwin Gizzmick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8022; -- Thadius Grimshade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8023; -- Sharpbeak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8026; -- Thyn'tel Bladeweaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8055; -- Thelsamar Mountaineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8095; -- Sul'lithuz Sandcrawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8096; -- Protector of the People
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8115; -- Witch Doctor Uzer'i
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8119; -- Zikkel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8120; -- Sul'lithuz Abomination
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8123; -- Rickle Goldgrubber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8124; -- Qizzik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8125; -- Dirge Quikcleave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8126; -- Nixx Sprocketspring
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8127; -- Antu'sul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8128; -- Pikkle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8129; -- Wrinkle Goodsteel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8130; -- Sul'lithuz Hatchling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8131; -- Blizrik Buckshot
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8136; -- Lord Shalzaru
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8137; -- Gikkix
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8139; -- Jabbey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8140; -- Brother Karman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8141; -- Captain Evencane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8142; -- Jannos Lighthoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8143; -- Loorana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8144; -- Kulleg Stonehorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8145; -- Sheendra Tallgrass
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8146; -- Ruw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8147; -- Camp Mojache Brave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8150; -- Janet Hommers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8151; -- Nijel's Point Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8152; -- Harnor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8153; -- Narv Hidecrafter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8154; -- Ghost Walker Brave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8155; -- Kargath Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8157; -- Logannas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8158; -- Bronk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8159; -- Worb Strongstitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8160; -- Nioma
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8161; -- Harggan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8176; -- Gharash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8177; -- Rartar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8178; -- Nina Lightbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8196; -- Occulus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8197; -- Chronalis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8198; -- Tick
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8200; -- Jin'Zallah the Sandbringer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8202; -- Cyclok the Mad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8210; -- Razortalon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8216; -- Retherokk the Berserker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8217; -- Mith'rethis the Enchanter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8236; -- Muck Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8256; -- Curator Thorius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8276; -- Soaring Razorbeak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8277; -- Rekk'tilac
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8278; -- Smoldar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8282; -- Highlord Mastrogonde
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8284; -- Dorius Stonetender
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8296; -- Mojo the Twisted
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8298; -- Akubar the Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8304; -- Dreadscorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8305; -- Kixxle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8306; -- Duhng
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8307; -- Tarban Hearthgrain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8308; -- Alenndaar Lapidaar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8309; -- Carlo Aurelius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8310; -- Watcher Wollpert
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8336; -- Hakkari Sapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8356; -- Chesmu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8357; -- Atepa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8358; -- Hewa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8359; -- Ahanu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8360; -- Elki
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8361; -- Chepi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8362; -- Kuruk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8363; -- Shadi Mistrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8364; -- Pakwa
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8378; -- Alexandra Blazen
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8379; -- Archmage Xylem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8380; -- Captain Vanessa Beltis
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8381; -- Lindros
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8382; -- Patrick Mills
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8383; -- Master Wood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8385; -- Mura Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8386; -- Horizon Scout Crewman
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8390; -- Chemist Cuely
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8393; -- Thersa Windsong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8395; -- Sanath Lim-yo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8396; -- Sentinel Dalia Sunblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8397; -- Sentinel Keldara Sunblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8398; -- Ohanko
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8399; -- Nyrill
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8400; -- Obsidion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8401; -- Halpa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8402; -- Enslaved Archaeologist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8403; -- Jeremiah Payson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8404; -- Xan'tish
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8405; -- Ogtinc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8408; -- Warlord Krellian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8409; -- Caravan Master Tset
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8416; -- Felix Whindlebolt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8417; -- Dying Archaeologist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8418; -- Falla Sagewind
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8419; -- Twilight Idolater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8420; -- Kim'jael
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8436; -- Zamael Lunthistle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8438; -- Hakkari Bloodkeeper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8439; -- Nilith Lokrav
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8440; -- Shade of Hakkar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8441; -- Raze
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8442; -- Shadowsilk Poacher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8444; -- Trade Master Kovic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8447; -- Clunk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8477; -- Skeletal Servant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8479; -- Kalaran Windblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8496; -- Liv Rizzlefix
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8497; -- Nightmare Suppressor
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8503; -- Gibblewilt
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8507; -- Tymor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8508; -- Gretta Ganter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8509; -- Squire Maltrake
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8516; -- Belnistrasz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8517; -- Xiggs Fuselighter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8518; -- Rynthariel the Keymaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8519; -- Blighted Surge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8520; -- Plague Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8521; -- Blighted Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8522; -- Plague Monstrosity
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8523; -- Scourge Soldier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8524; -- Cursed Mage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8525; -- Scourge Warder
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8526; -- Dark Caster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8527; -- Scourge Guard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8528; -- Dread Weaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8529; -- Scourge Champion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8530; -- Cannibal Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8531; -- Gibbering Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8532; -- Diseased Flayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8534; -- Putrid Gargoyle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8535; -- Putrid Shrieker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8538; -- Unseen Servant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8539; -- Eyeless Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8540; -- Torn Screamer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8541; -- Hate Shrieker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8542; -- Death Singer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8543; -- Stitched Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8544; -- Gangled Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8545; -- Stitched Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8546; -- Dark Adept
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8547; -- Death Cultist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8548; -- Vile Tutor
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8550; -- Shadowmage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8551; -- Dark Summoner
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8553; -- Necromancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8554; -- Chief Sharptusk Thornmantle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8555; -- Crypt Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8556; -- Crypt Walker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8557; -- Crypt Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8558; -- Crypt Slayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8560; -- Mossflayer Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8561; -- Mossflayer Shadowhunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8562; -- Mossflayer Cannibal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8563; -- Woodsman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8564; -- Ranger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8565; -- Pathstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8566; -- Dark Iron Lookout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8567; -- Glutton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8576; -- Ag'tor Bloodfist
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8578; -- Magus Rimtori
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8579; -- Yeh'kinya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8582; -- Kadrak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8583; -- Dirania Silvershine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8584; -- Iverron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8586; -- Haggrum Bloodfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8587; -- Jediga
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8588; -- Umbranse the Spiritspeaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8596; -- Plaguehound Runt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8597; -- Plaguehound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8598; -- Frenzied Plaguehound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8600; -- Plaguebat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8601; -- Noxious Plaguebat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8602; -- Monstrous Plaguebat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8603; -- Carrion Grub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8605; -- Carrion Devourer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8606; -- Living Decay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8607; -- Rotting Sludge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8609; -- Alexandra Constantine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8610; -- Kroum
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8617; -- Zalashji
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8636; -- Morta'gya the Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8637; -- Dark Iron Watchman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8656; -- Hukku's Voidwalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8657; -- Hukku's Succubus
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8658; -- Hukku's Imp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8659; -- Jes'rimon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8660; -- The Evalcharr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8661; -- Auctioneer Beardo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8662; -- Idol Oven Fire Target
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8664; -- Saern Priderunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8665; -- Shylenai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8667; -- Gusting Vortex
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8669; -- Auctioneer Tolon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8670; -- Auctioneer Chilton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8671; -- Auctioneer Buckler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8672; -- Auctioneer Leeka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8673; -- Auctioneer Thathung
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8674; -- Auctioneer Stampi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8675; -- Felbeast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8678; -- Jubie Gadgetspring
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8681; -- Outfitter Eric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8696; -- Henry Stern
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8716; -- Dreadlord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8717; -- Felguard Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8718; -- Manahound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8719; -- Auctioneer Fitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8720; -- Auctioneer Redmuse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8721; -- Auctioneer Epitwee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8722; -- Auctioneer Gullem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8723; -- Auctioneer Golothas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8724; -- Auctioneer Wabang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8736; -- Buzzek Bracketswing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8737; -- Linken
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8738; -- Vazario Linkgrease
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8756; -- Raytaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8757; -- Shahiar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8758; -- Zaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8759; -- Mosshoof Runner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8760; -- Mosshoof Stag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8761; -- Mosshoof Courser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8762; -- Timberweb Recluse
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8763; -- Mistwing Rogue
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8764; -- Mistwing Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8766; -- Forest Ooze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8767; -- Sah'rhee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8816; -- Deathly Usher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8837; -- Muck Splash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8878; -- Muuran
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8879; -- Royal Historian Archesonus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8881; -- Riding Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8882; -- Riding Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8883; -- Riding Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8884; -- Skeletal Mount
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8885; -- Riding Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8886; -- Deviate Python
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8887; -- A tormented voice
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8889; -- Anvilrage Overseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8890; -- Anvilrage Warden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8891; -- Anvilrage Guardsman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8892; -- Anvilrage Footman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8893; -- Anvilrage Soldier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8894; -- Anvilrage Medic
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8895; -- Anvilrage Officer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8896; -- Shadowforge Peasant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8897; -- Doomforge Craftsman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8898; -- Anvilrage Marshal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8899; -- Doomforge Dragoon
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8900; -- Doomforge Arcanasmith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8901; -- Anvilrage Reservist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8902; -- Shadowforge Citizen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8903; -- Anvilrage Captain
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8904; -- Shadowforge Senator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8905; -- Warbringer Construct
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8906; -- Ragereaver Golem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8907; -- Wrath Hammer Construct
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8908; -- Molten War Golem
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8909; -- Fireguard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8910; -- Blazing Fireguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8911; -- Fireguard Destroyer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8912; -- Twilight's Hammer Torturer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 8913; -- Twilight Emissary
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8914; -- Twilight Bodyguard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8915; -- Twilight's Hammer Ambassador
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8916; -- Arena Spectator
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8917; -- Quarry Slave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8920; -- Weapon Technician
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8921; -- Bloodhound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8922; -- Bloodhound Mastiff
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8923; -- Panzor the Invincible
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8924; -- The Behemoth
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8929; -- Princess Moira Bronzebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8931; -- Innkeeper Heather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8934; -- Christopher Hewen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8956; -- Angerclaw Bear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8957; -- Angerclaw Grizzly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8958; -- Angerclaw Mauler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8959; -- Felpaw Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8960; -- Felpaw Scavenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8961; -- Felpaw Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8962; -- Hilary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8963; -- Effsee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8964; -- Blackrock Drake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8965; -- Shawn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8977; -- Krom'Grul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8980; -- Firegut Captain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8982; -- Ironhand Guardian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 8983; -- Golem Lord Argelmach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 8997; -- Gershala Nightwhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9016; -- Bael'Gar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9017; -- Lord Incendius
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9018; -- High Interrogator Gerstahn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9019; -- Emperor Dagran Thaurissan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9020; -- Commander Gor'shak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9021; -- Kharan Mighthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9022; -- Dughal Stormwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9023; -- Marshal Windsor
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9024; -- Pyromancer Loregrain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9025; -- Lord Roccor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9026; -- Overmaster Pyron
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9029; -- Eviscerator
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9030; -- Ok'thor the Breaker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9031; -- Anub'shiah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9033; -- General Angerforge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9034; -- Hate'rel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9035; -- Anger'rel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9036; -- Vile'rel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9037; -- Gloom'rel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9038; -- Seeth'rel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9039; -- Doom'rel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9040; -- Dope'rel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9041; -- Warder Stilgiss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9042; -- Verek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9043; -- Scarshield Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9044; -- Scarshield Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9046; -- Scarshield Quartermaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9047; -- Jenal
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9056; -- Fineous Darkvire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9076; -- Ghede
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9077; -- Warlord Goretooth
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9078; -- Shadowmage Vivian Lagrave
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9079; -- Hierophant Theodora Mulvadania
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9080; -- Lexlort
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9081; -- Galamav the Marksman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9082; -- Thal'trak Proudtusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9083; -- Razal'blade
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9084; -- Thunderheart
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9085; -- Initiate Amakkar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9086; -- Grunt Gargal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9087; -- Bashana Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9099; -- Sraaz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9116; -- Eridan Bluewind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9117; -- J.D. Collie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9118; -- Larion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9119; -- Muigin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9156; -- Ambassador Flamelash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9157; -- Bloodpetal Pest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9162; -- Young Diemetradon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9163; -- Diemetradon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9164; -- Elder Diemetradon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9165; -- Fledgling Pterrordax
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9166; -- Pterrordax
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9167; -- Frenzied Pterrordax
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9176; -- Gor'tesh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9177; -- Oralius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9179; -- Jazzrik
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9197; -- Spirestone Battle Mage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9198; -- Spirestone Mystic
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9201; -- Spirestone Ogre Magus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9217; -- Spirestone Lord Magus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9236; -- Shadow Hunter Vosh'gajin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9238; -- Quentin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9239; -- Smolderthorn Mystic
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9240; -- Smolderthorn Shadow Priest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9256; -- Farm Chicken
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9264; -- Firebrand Pyromancer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9265; -- Smolderthorn Shadow Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9266; -- Smolderthorn Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9269; -- Smolderthorn Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9270; -- Williden Marshal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9271; -- Hol'anyee Marshal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9272; -- Spark Nilminer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9273; -- Petra Grossen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9274; -- Dadanga
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9296; -- Milly Osworth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9298; -- Donova Snowden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9299; -- Gaeriyan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9316; -- Wenikee Boltbucket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9317; -- Rilli Greasygob
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9318; -- Incendosaur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9319; -- Houndmaster Grebmar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9336; -- Boss Copperplug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9356; -- Innkeeper Shul'kar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9376; -- Blazerunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9377; -- Swirling Vortex
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9397; -- Living Storm
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9437; -- Dark Keeper Vorfalk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9438; -- Dark Keeper Bethek
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9439; -- Dark Keeper Uggel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9441; -- Dark Keeper Zimrel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9442; -- Dark Keeper Ofgut
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9443; -- Dark Keeper Pelver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9447; -- Scarlet Warder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9448; -- Scarlet Praetorian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9449; -- Scarlet Cleric
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9450; -- Scarlet Curate
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9451; -- Scarlet Archmage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9452; -- Scarlet Enchanter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9454; -- Xavathras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9459; -- Cyrus Therepentous
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9460; -- Gadgetzan Bruiser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9462; -- Chieftain Bloodmaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9464; -- Overlord Ror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9465; -- Golhine the Hooded
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9467; -- Miblon Snarltooth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9496; -- Gorishi Egg
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9499; -- Plugger Spazzring
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9500; -- Mistress Nagmara
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9501; -- Innkeeper Adegwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9502; -- Phalanx
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9503; -- Private Rocknot
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9516; -- Lord Banehollow
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9517; -- Shadow Lord Fel'dan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9518; -- Rakaiah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9520; -- Grark Lorkrub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9525; -- Freewind Brave
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9528; -- Arathandris Silversky
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9529; -- Maybess Riverbreeze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9536; -- Maxwort Uberglint
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9540; -- Enohar Thunderbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9542; -- Franclorn's Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9543; -- Ribbly Screwspigot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9544; -- Yuka Screwspigot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9545; -- Grim Patron
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9547; -- Guzzling Patron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9548; -- Cawind Trueaim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9549; -- Borand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9550; -- Furmund
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9551; -- Starn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9552; -- Zanara
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9553; -- Nadia Vernon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9554; -- Hammered Patron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9555; -- Mu'uta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9558; -- Grimble
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9559; -- Grizzlowe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9560; -- Marshal Maxwell
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9561; -- Jalinda Sprig
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9562; -- Helendis Riverhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9563; -- Ragged John
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9564; -- Frezza
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9565; -- Mayara Brightwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9566; -- Zapetta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9599; -- Arei Transformed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9600; -- Parrot
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9604; -- Gorgon'och
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9616; -- Laris Geardawdle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9618; -- Karna Remtravel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9619; -- Torwa Pathfinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9620; -- Dreka'Sur
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9622; -- U'cha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9623; -- A-Me 01
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9636; -- Kireena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9660; -- Agnar Beastamer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9676; -- Tink Sprocketwhistle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9677; -- Ograbisi
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9678; -- Shill Dinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9679; -- Tobias Seecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9680; -- Crest Killer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9681; -- Jaz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9690; -- Ember Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9691; -- Venomtip Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9694; -- Slavering Ember Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9695; -- Deathlash Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9696; -- Bloodaxe Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9697; -- Giant Ember Worg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9698; -- Firetail Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9699; -- Fire Beetle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9700; -- Lava Crab
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9705; -- Illusionary Dreamwatcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9706; -- Yorba Screwspigot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9776; -- Flamekin Spitter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9777; -- Flamekin Sprite
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9778; -- Flamekin Torcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9779; -- Flamekin Rager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9796; -- Galgar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9816; -- Pyroguard Emberseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9836; -- Mathredis Firestar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9856; -- Auctioneer Grimful
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9857; -- Auctioneer Grizzlin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9858; -- Auctioneer Kresky
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9859; -- Auctioneer Lympkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9860; -- Salia
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9861; -- Moora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9862; -- Jaedenar Legionnaire
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 9877; -- Prince Xavalis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9878; -- Entropic Beast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9879; -- Entropic Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9916; -- Jarquia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9936; -- Corrupted Kitten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9938; -- Magmus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9956; -- Shadowforge Flame Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9976; -- Tharlidun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9978; -- Wesley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9979; -- Sarah Goode
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9980; -- Shelby Stoneflint
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9981; -- Sikwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9982; -- Penny
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9983; -- Kelsuwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9984; -- Ulbrek Firehand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9985; -- Laziphus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9986; -- Shyrka Wolfrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9987; -- Shoja'my
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9988; -- Xon'cha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9989; -- Lina Hearthstove
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9990; -- Lanti'gah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9996; -- Winna Hazzard
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 9997; -- Spraggle Frock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9998; -- Shizzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 9999; -- Ringo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10016; -- Tainted Rat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10017; -- Tainted Cockroach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10036; -- Brackenwall Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10037; -- Lakeshire Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10038; -- Night Watch Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10043; -- Ribbly's Crony
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10045; -- Kirk Maxwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10046; -- Bethaine Flinthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10047; -- Michael
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10048; -- Gereck
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10049; -- Hekkru
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10050; -- Seikwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10051; -- Seriadne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10052; -- Maluressian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10053; -- Anya Maulray
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10054; -- Bulrug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10055; -- Morganus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10056; -- Alassin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10057; -- Theodore Mont Claire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10058; -- Greth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10059; -- Antarius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10060; -- Grimestack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10061; -- Killium Bouldertoe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10062; -- Steven Black
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10063; -- Reggifuz
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10076; -- High Priestess of Thaurissan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10077; -- Deathmaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10078; -- Terrorspark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10079; -- Brave Moonhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10085; -- Jaelysia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10086; -- Hesuwa Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10088; -- Xao'tsu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10089; -- Silvaria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10090; -- Belia Thundergranite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10116; -- Slave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10117; -- Tortured Slave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10118; -- Nessa Shadowsong
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10119; -- Volchan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10120; -- Vault Warder
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10136; -- Chemist Fuely
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10157; -- Moonkin Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10158; -- Moonkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10159; -- Young Moonkin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10160; -- Raging Moonkin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10162; -- Lord Victor Nefarius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10176; -- Kaltunk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10181; -- Lady Sylvanas Windrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10182; -- Rexxar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10197; -- Mezzir the Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10198; -- Kashoch the Reaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10199; -- Grizzle Snowpaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10200; -- Rak'shiri
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10201; -- Lady Hederine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10216; -- Gubber Blump
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10219; -- Gwennyth Bly'Leggonde
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10260; -- Kibler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10262; -- Opus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10266; -- Ug'thok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10267; -- Tinkee Steamboil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10276; -- Rotgath Stonebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10277; -- Groum Stonebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10278; -- Thrag Stonehoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10293; -- Dulciea Frostmoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10300; -- Ranshalla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10301; -- Jaron Stoneshaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10302; -- Krakle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10303; -- Storm Shadowhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10304; -- Aurora Skycaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10305; -- Umi Rumplesnicker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10306; -- Trull Failbane
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10307; -- Witch Doctor Mau'ari
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10316; -- Blackhand Incarcerator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10321; -- Emberstrife
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10356; -- Bayne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10357; -- Ressan the Needler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10358; -- Fellicent's Shade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10360; -- Kergul Bloodaxe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10361; -- Gruul Darkblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10369; -- Trayexir
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10373; -- Xabraxxis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10377; -- Elu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10378; -- Omusa Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10379; -- Altsoba Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10380; -- Sanuye Runetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10381; -- Ravaged Cadaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10382; -- Mangled Cadaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10384; -- Spectral Citizen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10385; -- Ghostly Citizen
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10389; -- Wrath Phantom
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10390; -- Skeletal Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10391; -- Skeletal Berserker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10393; -- Skul
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10398; -- Thuzadin Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10399; -- Thuzadin Acolyte
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10400; -- Thuzadin Necromancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10405; -- Plague Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10406; -- Ghoul Ravener
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10407; -- Fleshflayer Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10408; -- Rockwing Gargoyle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10409; -- Rockwing Screecher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10412; -- Crypt Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10413; -- Crypt Beast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10414; -- Patchwork Horror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10415; -- Ash'ari Crystal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10416; -- Bile Spewer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10417; -- Venom Belcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10418; -- Crimson Guardsman
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10419; -- Crimson Conjuror
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10420; -- Crimson Initiate
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10421; -- Crimson Defender
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10422; -- Crimson Sorcerer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10423; -- Crimson Priest
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10424; -- Crimson Gallant
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10425; -- Crimson Battle Mage
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10426; -- Crimson Inquisitor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10427; -- Pao'ka Swiftmountain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10428; -- Motega Firemane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10431; -- Gregor Greystone
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10432; -- Vectus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10433; -- Marduk Blackpool
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10435; -- Magistrate Barthilas
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10436; -- Baroness Anastari
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10437; -- Nerub'enkan
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10438; -- Maleki the Pallid
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10440; -- Baron Rivendare
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10442; -- Chromatic Whelp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10445; -- Selina Dourman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10455; -- Binny Springblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10456; -- Prynne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10459; -- Rend on Drake Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10460; -- Prospector Ironboot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10463; -- Shrieking Banshee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10464; -- Wailing Banshee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10468; -- Felnok Steelspring
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10469; -- Scholomance Adept
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10470; -- Scholomance Neophyte
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10471; -- Scholomance Acolyte
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10472; -- Scholomance Occultist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10475; -- Scholomance Student
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10476; -- Scholomance Necrolyte
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10477; -- Scholomance Necromancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10478; -- Splintered Skeleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10480; -- Unstable Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10481; -- Reanimated Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10482; -- Risen Lackey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10485; -- Risen Aberration
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10486; -- Risen Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10487; -- Risen Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10488; -- Risen Construct
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10489; -- Risen Guard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10491; -- Risen Bonewarder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10495; -- Diseased Ghoul
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10498; -- Spectral Tutor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10499; -- Spectral Researcher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10500; -- Spectral Teacher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10502; -- Lady Illucia Barov
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10503; -- Jandice Barov
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10504; -- Lord Alexei Barov
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10505; -- Instructor Malicia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10507; -- The Ravenian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10508; -- Ras Frostwhisper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10537; -- Cliffwatcher Longhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10539; -- Hagar Lightninghoof
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10540; -- Vol'jin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10541; -- Krakle's Thermometer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10556; -- Lazy Peon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10558; -- Hearthsinger Forresten
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10559; -- Lady Vespia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10578; -- Bom'bay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10580; -- Fetid Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10582; -- Dog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10583; -- Gryfe
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10584; -- Urok Doomhowl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10599; -- Hulfnar Stonetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10600; -- Thontek Rumblehoof
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10602; -- Urok Ogre Magus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10604; -- Huntress Nhemai
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10605; -- Scarlet Medic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10606; -- Huntress Yaeliura
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10608; -- Scarlet Priest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10610; -- Angus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10611; -- Shorty
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10612; -- Guard Wachabe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10616; -- Supervisor Raelen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10617; -- Galak Messenger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10618; -- Rivern Frostwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10619; -- Glacier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10636; -- Pack Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10637; -- Malyfous Darkhammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10638; -- Kanati Greycloud
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10639; -- Rorgish Jowl
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10640; -- Oakpaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10642; -- Eck'alom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10644; -- Mist Howler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10645; -- Thalia Amberhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10646; -- Lakota Windsong
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10647; -- Prince Raze
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10648; -- Xavaric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10658; -- Winna's Kitten
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10659; -- Cobalt Whelp
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10660; -- Cobalt Broodling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10661; -- Spell Eater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10662; -- Spellmaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10663; -- Manaclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10664; -- Scryer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10665; -- Junior Apothecary Holland
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10666; -- Gordo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10667; -- Chromie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10668; -- Beaten Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10676; -- Raider Jhash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10678; -- Plagued Hatchling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10682; -- Raider Kerr
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10684; -- Remorseful Highborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10685; -- Swine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10696; -- Refuge Pointe Defender
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10698; -- Summoned Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10721; -- Novice Warrior
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10738; -- High Chief Winterfall
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10739; -- Mulgris Deepriver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10756; -- Scalding Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10757; -- Boiling Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10758; -- Grimtotem Bandit
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10759; -- Grimtotem Stomper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10760; -- Grimtotem Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10761; -- Grimtotem Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10778; -- Janice Felstone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10779; -- Infected Squirrel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10780; -- Infected Deer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10781; -- Royal Overseer Bauhaus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10782; -- Royal Factor Bathrilor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10783; -- Orb of Deception (Orc WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10784; -- Orb of Deception (Orc WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10785; -- Orb of Deception (Tauren WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10786; -- Orb of Deception (Tauren WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10787; -- Orb of Deception (Troll WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10788; -- Orb of Deception (Troll WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10789; -- Orb of Deception (Undead WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10790; -- Orb of Deception (Undead WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10791; -- Orb of Deception (Dwarf WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10792; -- Orb of Deception (Dwarf WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10793; -- Orb of Deception (Gnome WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10794; -- Orb of Deception (Gnome WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10795; -- Orb of Deception (Human WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10796; -- Orb of Deception (Human WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10797; -- Orb of Deception (NightElf WHERE `Entry` = Male)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10798; -- Orb of Deception (Nightelf WHERE `Entry` = Female)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10801; -- Jabbering Ghoul
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10802; -- Hitah'ya the Keeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10803; -- Rifleman Wheeler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10804; -- Rifleman Middlecamp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10805; -- Spotter Klemmy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10806; -- Ursius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10807; -- Brumeran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10809; -- Stonespine
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10811; -- Archivist Galford
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10812; -- Grand Crusader Dathrohan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10816; -- Wandering Skeleton
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10823; -- Zul'Brin Warpbranch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10824; -- Ranger Lord Hawkspear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10826; -- Lord Darkscythe
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10827; -- Deathspeaker Selendre
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10828; -- High General Abbendis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10837; -- High Executor Derrington
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10838; -- Commander Ashlam Valorfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10839; -- Argent Officer Garush
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10840; -- Argent Officer Pureheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10856; -- Argent Quartermaster Hasana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10857; -- Argent Quartermaster Lightspark
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 10876; -- Undead Scarab
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10877; -- Courier Hammerfall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10878; -- Herald Moonstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10879; -- Harbinger Balthazad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10880; -- Warcaller Gorlach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10881; -- Bluff Runner Windstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10896; -- Arnak Grimtotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10897; -- Sindrayl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10901; -- Lorekeeper Polkelt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10902; -- Andorhal Tower One
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10903; -- Andorhal Tower Two
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10904; -- Andorhal Tower Three
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10905; -- Andorhal Tower Four
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10916; -- Winterfall Runner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10917; -- Aurius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10918; -- Lorax
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10920; -- Kelek Skykeeper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10921; -- Taronn Redfeather
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10922; -- Greta Mosshoof
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10923; -- Tenell Leafrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10924; -- Ivy Leafrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10926; -- Pamela Redpath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10927; -- Marlene Redpath
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 10929; -- Haleh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10930; -- Dargh Trueaim
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10940; -- Ghost of the Past
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10941; -- Wizlo Bearingshiner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10976; -- Jeziba
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10977; -- Quixxil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10978; -- Legacki
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10979; -- Scarlet Hound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10992; -- Enraged Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10993; -- Twizwick Sprocketgrind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 10997; -- Cannon Master Willey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11016; -- Captured Arko'narin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11017; -- Roxxik
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11019; -- Jessir Moonbow
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11020; -- Remains of Trey Lightforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11022; -- Alexi Barov
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11023; -- Weldon Barov
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11024; -- Della
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11025; -- Mukdrak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11028; -- Jemma Quikswitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11029; -- Trixie Quikswitch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11031; -- Franklin Lloyd
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11032; -- Malor the Zealous
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11033; -- Smokey LaRue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11034; -- Lord Maxwell Tyrosus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11035; -- Betina Bigglezink
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11036; -- Leonid Barthalomew the Revered
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11037; -- Jenna Lemkenilli
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11038; -- Caretaker Alen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11039; -- Duke Nicholas Zverenhoff
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11040; -- Watcher Brownell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11041; -- Milla Fairancora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11042; -- Sylvanna Forestmoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11043; -- Crimson Monk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11044; -- Doctor Martin Felben
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11046; -- Whuut
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11047; -- Kray
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11048; -- Victor Ward
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11049; -- Rhiannon Davis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11050; -- Trianna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11051; -- Vhan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11052; -- Timothy Worthington
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11053; -- High Priestess MacDonnell
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11055; -- Shadow Priestess Vandis
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11056; -- Alchemist Arbington
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11057; -- Apothecary Dithers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11063; -- Carlin Redpath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11065; -- Thonys Pillarstone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11066; -- Jhag
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11067; -- Malcomb Wynn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11068; -- Betty Quin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11070; -- Lalina Summermoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11071; -- Mot Dawnstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11072; -- Kitta Firewind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11073; -- Annora
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11074; -- Hgarth
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11076; -- Cauldron Lord Razarch
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11077; -- Cauldron Lord Malvinious
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11079; -- Wynd Nightchaser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11081; -- Faldron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11082; -- Stratholme Courier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11083; -- Darianna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11084; -- Tarn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11096; -- Randal Worth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11097; -- Drakk Stonehand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11098; -- Hahrana Ironhide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11102; -- Argent Rider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11103; -- Innkeeper Lyshaerya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11104; -- Shelgrayn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11105; -- Aboda
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11106; -- Innkeeper Sikewa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11116; -- Innkeeper Abeqwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11117; -- Awenasa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11118; -- Innkeeper Vizzie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11119; -- Azzleby
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11137; -- Xai'ander
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11138; -- Maethrya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11139; -- Yugrek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11140; -- Egan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11143; -- Postmaster Malown
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11145; -- Myolor Sunderfury
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11146; -- Ironus Coldsteel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11151; -- Riding MechaStrider (Yellow/Green)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11152; -- The Scourge Cauldron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11156; -- Green Skeletal Warhorse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11176; -- Krathok Moltenfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11177; -- Okothos Ironrager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11178; -- Borgosh Corebender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11179; -- Crystal Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11180; -- Bloodvenom Post Brave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11181; -- Shi'alune
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11182; -- Nixxrak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11183; -- Blixxrak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11184; -- Wixxrak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11185; -- Xizzer Fizzbolt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11186; -- Lunnix Sprocketslip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11187; -- Himmik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11188; -- Evie Whirlbrew
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11189; -- Qia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11190; -- Everlook Bruiser
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11191; -- Lilith the Lithe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11192; -- Kilram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11193; -- Seril Scourgebane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11194; -- Argent Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11198; -- Broken Exile
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11216; -- Eva Sarkhoff
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11217; -- Lucien Sarkhoff
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11218; -- Kerlonian Evershade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11219; -- Liladris Moonriver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11257; -- Scholomance Handler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11258; -- Frail Skeleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11259; -- Nataka Longhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11260; -- Northshire Peasant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11261; -- Doctor Theolen Krastinov
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11276; -- Azshara Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11288; -- Spectral Betrayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11289; -- Spectral Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11290; -- Mossflayer Zombie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11291; -- Unliving Mossflayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11317; -- Jinar'Zillen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11318; -- Ragefire Trogg
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11319; -- Ragefire Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11320; -- Earthborer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11321; -- Molten Elemental
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11322; -- Searing Blade Cultist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11323; -- Searing Blade Enforcer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11324; -- Searing Blade Warlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11328; -- Eastvale Peasant
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11338; -- Hakkari Shadowcaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11339; -- Hakkari Shadow Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11340; -- Hakkari Blood Priest
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11346; -- Hakkari Oracle
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11347; -- Zealot Lor'Khan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11348; -- Zealot Zath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11350; -- Gurubashi Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11351; -- Gurubashi Headhunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11352; -- Gurubashi Berserker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11353; -- Gurubashi Blood Drinker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11355; -- Gurubashi Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11356; -- Gurubashi Champion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11357; -- Son of Hakkar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11359; -- Soulflayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11360; -- Zulian Cub
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11361; -- Zulian Tiger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11365; -- Zulian Panther
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11368; -- Bloodseeker Bat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11370; -- Razzashi Broodwidow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11371; -- Razzashi Serpent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11372; -- Razzashi Adder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11373; -- Razzashi Cobra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11374; -- Hooktooth Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11378; -- Foreman Thazz'ril
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11380; -- Jin'do the Hexxer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11382; -- Bloodlord Mandokir
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11383; -- High Priestess Hai'watna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11387; -- Sandfury Speaker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11388; -- Witherbark Speaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11389; -- Bloodscalp Speaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11390; -- Skullsplitter Speaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11391; -- Vilebranch Speaker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11401; -- Priestess Alathea
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11406; -- High Priest Rohan
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11407; -- Var'jun
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11437; -- Minor Infernal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11438; -- Bibbly F'utzbuckle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11440; -- Gordok Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11442; -- Gordok Mauler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11443; -- Gordok Ogre-Mage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11444; -- Gordok Mage-Lord
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11445; -- Gordok Captain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11494; -- Alzinn Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11496; -- Immol'thar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11497; -- The Razza
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11502; -- Ragnaros
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11516; -- Timbermaw Warder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11517; -- Oggleflint
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11518; -- Jergosh the Invoker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11519; -- Bazzalan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11520; -- Taragaman the Hungerer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11536; -- Quartermaster Miranda Breechlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11546; -- Jack Sterling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11547; -- Skeletal Scholomance Student
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11548; -- Loh'atu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11551; -- Necrofiend
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11553; -- Timbermaw Woodbender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11554; -- Grazle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11555; -- Gorn One Eye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11556; -- Salfa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11557; -- Meilosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11558; -- Kernda
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11559; -- Outcast Necromancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11561; -- Undead Ravager
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11562; -- Drysnap Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11563; -- Drysnap Pincer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11564; -- Gizelton Caravan Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11576; -- Whirlwind Ripper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11577; -- Whirlwind Stormwalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11578; -- Whirlwind Shredder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11582; -- Scholomance Dark Summoner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11596; -- Smeed Scrabblescrew
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11608; -- Bardu Sharpeye
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11609; -- Alexia Ironknife
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11610; -- Kirsta Deepshadow
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11611; -- Cavalier Durgen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11613; -- Huntsman Radley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11614; -- Bloodshot
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11615; -- Mickey Levine
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11616; -- Nathaniel Dumah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11620; -- Spectral Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11621; -- Spectral Corpse
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11622; -- Rattlegore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11624; -- Taiga Wisemane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11625; -- Cork Gizelton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11626; -- Rigger Gizelton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11628; -- Decaying Corpse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11629; -- Jessica Redpath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11656; -- Warsong Peon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11658; -- Molten Giant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11659; -- Molten Destroyer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11661; -- Flamewaker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11662; -- Flamewaker Priest
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11663; -- Flamewaker Healer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11664; -- Flamewaker Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11665; -- Lava Annihilator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11666; -- Firewalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11667; -- Flameguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11668; -- Firelord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11669; -- Flame Imp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11671; -- Core Hound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11672; -- Core Rager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11673; -- Ancient Core Hound
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11680; -- Horde Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11681; -- Horde Deforester
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11682; -- Warsong Grunt
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11683; -- Warsong Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11684; -- Warsong Shredder
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11685; -- Maraudine Priest
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11686; -- Ghostly Raider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11687; -- Ghostly Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11696; -- Chal Fairwind
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11697; -- Mannoroc Lasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11698; -- Hive'Ashi Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11700; -- Sarin Starlight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11703; -- Graw Cornerstone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11704; -- Kriss Goldenlight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11705; -- Rayan Dawnrisen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11706; -- Adon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11707; -- Joy Ar'nareth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11708; -- Coral Moongale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11709; -- Jareth Wildwoods
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11710; -- Mirador
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11711; -- Sentinel Aynasha
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11712; -- Lilyn Darkriver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11713; -- Blackwood Tracker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11714; -- Marosh the Devious
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11715; -- Talendria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11716; -- Celes Earthborne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11717; -- Bethan Bluewater
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11718; -- Sar Browneye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11720; -- Loruk Foreststrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11721; -- Hive'Ashi Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11722; -- Hive'Ashi Defender
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11723; -- Hive'Ashi Sandstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11724; -- Hive'Ashi Swarmer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11725; -- Hive'Zora Waywatcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11726; -- Hive'Zora Tunneler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11727; -- Hive'Zora Wasp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11728; -- Hive'Zora Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11729; -- Hive'Zora Hive Sister
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11730; -- Hive'Regal Ambusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11731; -- Hive'Regal Burrower
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11732; -- Hive'Regal Spitfire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11733; -- Hive'Regal Slavemaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11734; -- Hive'Regal Hive Lord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11735; -- Stonelash Scorpid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11736; -- Stonelash Pincer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11737; -- Stonelash Flayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11738; -- Sand Skitterer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11739; -- Rock Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11740; -- Dredge Striker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11741; -- Dredge Crusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11744; -- Dust Stormer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11745; -- Cyclone Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11746; -- Desert Rumbler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11747; -- Desert Rager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11748; -- Samantha Swifthoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11749; -- Feran Strongwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11750; -- Ganoosh
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11751; -- Rilan Howard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11752; -- Blaise Montgomery
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11753; -- Gogo
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11754; -- Meggi Peppinrocker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11755; -- Harlo Wigglesworth
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11756; -- Quinn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11757; -- Umaron Stragarelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11758; -- Andi Lynn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11776; -- Salome
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11777; -- Shadowshard Rumbler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11778; -- Shadowshard Smasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11781; -- Ambershard Crusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11782; -- Ambershard Destroyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11783; -- Theradrim Shardling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11784; -- Theradrim Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11785; -- Ambereye Basilisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11786; -- Ambereye Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11787; -- Rock Borer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11788; -- Rock Worm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11789; -- Deep Borer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11790; -- Putridus Satyr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11791; -- Putridus Trickster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11792; -- Putridus Shadowstalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11793; -- Celebrian Dryad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11794; -- Sister of Celebrian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11795; -- Mylentha Riverbend
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11796; -- Bessany Plainswind
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11797; -- Moren Riverbend
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11798; -- Bunthen Plainswind
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11799; -- Tajarri
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11800; -- Silva Fil'naveth
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11801; -- Rabine Saturna
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11802; -- Dendrite Starblaze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11803; -- Twilight Keeper Exeter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11804; -- Twilight Keeper Havunth
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11805; -- Jarund Stoutstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11806; -- Sentinel Onaeya
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11807; -- Tristane Shadowstone
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11808; -- Grum Redbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11810; -- Howin Kindfeather
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11811; -- Narain Soothfancy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11812; -- Claira Kindfeather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11813; -- Kerr Ironsight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11814; -- Kali Remik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11818; -- Orik'ando
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11820; -- Locke Okarr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11821; -- Darn Talongrip
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11822; -- Moonglade Warden
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11823; -- Vark Battlescar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11824; -- Erik Felixe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11825; -- Paige Felixe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11826; -- Kristy Grant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11829; -- Fahrak
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11830; -- Hakkari Priest
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11831; -- Hakkari Witch Doctor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11832; -- Keeper Remulos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11833; -- Rahauro
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11834; -- Maur Grimtotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11835; -- Theodore Griffs
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11856; -- Kaya Flathoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11858; -- Grundig Darkcloud
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11860; -- Maggran Earthbinder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11861; -- Mor'rogal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11862; -- Tsunaman
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11863; -- Azore Aldamort
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11864; -- Tammra Windfield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11865; -- Buliwyf Stonehand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11866; -- Ilyenia Moonfire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11867; -- Woo Ping
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11868; -- Sayoc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11869; -- Ansekhwa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11870; -- Archibald
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11871; -- Grinning Dog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11872; -- Myranda the Hag
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11873; -- Spectral Attendant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11874; -- Masat T'andr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11877; -- Roon Wildmane
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11878; -- Nathanos Blightcaller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11880; -- Twilight Avenger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11881; -- Twilight Geolord
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11882; -- Twilight Stonecaller
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11883; -- Twilight Master
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11885; -- Blighthound
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11896; -- Borelgore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11897; -- Duskwing
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11898; -- Crusader Lord Valdelmar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11899; -- Shardi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11900; -- Brakkar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11901; -- Andruk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11910; -- Grimtotem Ruffian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11911; -- Grimtotem Mercenary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11912; -- Grimtotem Brute
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11913; -- Grimtotem Sorcerer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11914; -- Gorehoof the Black
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 11915; -- Gogger Rock Keeper
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 11917; -- Gogger Geomancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11918; -- Gogger Stonepounder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11921; -- Besseleth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11936; -- Artist Renfray
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11939; -- Umber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11940; -- Merissa Stilwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11941; -- Yori Crackhelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11942; -- Orenthil Whisperwind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11943; -- Magga
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11944; -- Vorn Skyseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11945; -- Claire Willower
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11956; -- Great Bear Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11957; -- Great Cat Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11979; -- Kim Bridenbecker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11981; -- Flamegor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11982; -- Magmadar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11983; -- Firemaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11988; -- Golemagg the Incinerator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11994; -- Rob Bridenbecker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 11996; -- Ashley Bridenbecker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12017; -- Broodlord Lashlayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12018; -- Majordomo Executus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12019; -- Dargon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12021; -- Daeolyn Summerleaf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12022; -- Lorelae Wintersong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12023; -- Kharedon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12024; -- Meliri
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12025; -- Malvor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12026; -- My'lanna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12027; -- Tukk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12028; -- Lah'Mawhani
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12029; -- Narianna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12030; -- Malux
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12031; -- Mai'Lahii
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12032; -- Lui'Mala
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12033; -- Wulan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12034; -- Koiter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12042; -- Loganaar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12043; -- Kulwia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12045; -- Hae'Wilani
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12046; -- Gor'marok the Ravager
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12056; -- Baron Geddon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12057; -- Garr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12076; -- Lava Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12098; -- Sulfuron Harbinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12099; -- Firesworn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12100; -- Lava Reaver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12101; -- Lava Surger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12118; -- Lucifron
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12119; -- Flamewaker Protector
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12128; -- Crimson Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12136; -- Snurk Bucksquick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12137; -- Squibby Overspeck
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12140; -- Guardian of Elune
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12145; -- Riding Kodo (Black)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12146; -- Riding Kodo (Olive)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12147; -- Riding Kodo (White)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12150; -- Riding Kodo (Purple)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12160; -- Shadowglen Sentinel
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12178; -- Tortured Druid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12179; -- Tortured Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12196; -- Innkeeper Kaylisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12197; -- Glordrum Steelbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12198; -- Martin Lindsey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12199; -- Shade of Ambermoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12201; -- Princess Theradras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12202; -- Human Skull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12203; -- Landslide
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12206; -- Primordial Behemoth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12207; -- Thessala Hydra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12216; -- Poison Sprite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12217; -- Corruptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12218; -- Vile Larva
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12219; -- Barbed Lasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12220; -- Constrictor Vine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12221; -- Noxious Slime
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12222; -- Creeping Sludge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12223; -- Cavern Lurker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12224; -- Cavern Shambler
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12225; -- Celebras the Cursed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12236; -- Lord Vyletongue
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12239; -- Spirit of Gelk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12240; -- Spirit of Kolk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12241; -- Spirit of Magra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12242; -- Spirit of Maraudos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12243; -- Spirit of Veng
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12244; -- Mark of Detonation (NW)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12245; -- Vendor-Tron 1000
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12246; -- Super-Seller 680
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12247; -- Scourge Structure
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12248; -- Infiltrator Hameya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12249; -- Mark of Detonation (SW)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12250; -- Zaeldarr the Outcast
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12251; -- Mark of Detonation (CLS)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12252; -- Mark of Detonation (CRS)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12253; -- Mark of Detonation (CSH)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12254; -- Mark of Detonation (NESH)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12255; -- Mark of Detonation (NE)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12256; -- Mark of Detonation (SE)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12258; -- Razorlash
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12259; -- Gehennas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12260; -- Onyxian Drake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12262; -- Ziggurat Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12263; -- Slaughterhouse Protector
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12264; -- Shazzrah
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12277; -- Melizza Brimbuzzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12296; -- Sickly Gazelle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12298; -- Sickly Deer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 12319; -- Burning Blade Toxicologist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12321; -- Stormscale Toxicologist
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12322; -- Quel'Lithien Protector
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12337; -- Crimson Courier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12338; -- Shadowprey Guardian
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 12339; -- Demetria
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12340; -- Drulzegar Skraghook
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12341; -- Blue Skeletal Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12342; -- Brown Skeletal Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12343; -- Red Skeletal Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12345; -- Mottled Crimson Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12346; -- Emerald Riding Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12347; -- Enraged Reef Crawler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12349; -- Turquoise Riding Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12350; -- Violet Riding Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12351; -- Dire Riding Wolf
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12352; -- Scarlet Trooper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12353; -- Timber Riding Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12354; -- Brown Riding Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12355; -- Gray Riding Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12356; -- Green Riding Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12357; -- Teal Riding Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12358; -- Riding Striped Frostsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12359; -- Riding Spotted Frostsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12360; -- Riding Striped Nightsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12362; -- Riding Frostsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12363; -- Blue Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12365; -- Red Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12366; -- Unpainted Mechanostrider X
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12367; -- Green Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12368; -- White Mechanostrider Mod A
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12370; -- Black Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12371; -- Frost Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12372; -- Brown Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12373; -- Gray Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12374; -- White Riding Ram Mount
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12375; -- Chestnut Mare
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12376; -- Brown Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12377; -- Wailing Spectre
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 12378; -- Damned Soul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12379; -- Unliving Caretaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12380; -- Unliving Resident
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12383; -- Nibbles
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12384; -- Augustus the Touched
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12387; -- Large Vile Slime
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12396; -- Doomguard Commander
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12418; -- Gordok Hyena
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12420; -- Blackwing Mage
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12423; -- Guard Roberts
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12425; -- Flint Shadowmore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12427; -- Mountaineer Dolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12428; -- Deathguard Kel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12429; -- Sentinel Shaya
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12430; -- Grunt Kor'ja
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12431; -- Gorefang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12432; -- Old Vicejaw
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12433; -- Krethis Shadowspinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12434; -- Monster Generator (Blackwing)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12435; -- Razorgore the Untamed
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12457; -- Blackwing Spellbinder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12458; -- Blackwing Taskmaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12459; -- Blackwing Warlock
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12465; -- Death Talon Wyrmkin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12468; -- Death Talon Hatcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12474; -- Emeraldon Boughguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12475; -- Emeraldon Tree Warder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12476; -- Emeraldon Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12477; -- Verdantine Boughguard
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12478; -- Verdantine Oracle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12479; -- Verdantine Tree Warder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12480; -- Melris Malagan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12481; -- Justine Demalier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12496; -- Dreamtracker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12497; -- Dreamroarer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12498; -- Dreamstalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12557; -- Grethok the Controller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12576; -- Grish Longrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12577; -- Jarrodenus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12578; -- Mishellena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12579; -- Bloodfury Ripper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12596; -- Bibilfaz Featherwhistle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12616; -- Vhulgra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12617; -- Khaelyn Steelwing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12636; -- Georgia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12656; -- Thamarian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12657; -- Don Pompa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12658; -- Adam Lind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12676; -- Sharptalon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12677; -- Shadumbra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12678; -- Ursangous
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12696; -- Senani Thunderheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12716; -- Decedra Willham
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12717; -- Muglash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12718; -- Gurda Ragescar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12719; -- Marukai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12720; -- Framnali
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12721; -- Mitsuwa
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 12722; -- Vera Nightshade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12723; -- Har'alen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12724; -- Pixel
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 12736; -- Je'neu Sancrea
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12737; -- Mastok Wrilehiss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12738; -- Nori Pridedrift
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12740; -- Faustron
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12757; -- Karang Amakkar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12758; -- Onyxia Trigger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12759; -- Tideress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12776; -- Hraug
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12777; -- Captain Dirgehammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12778; -- Lieutenant Rachel Vaccar
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 12779; -- Archmage Gaiman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12780; -- Sergeant Major Skyshadow
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12781; -- Master Sergeant Biggins
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12782; -- Captain O'Neal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12783; -- Lieutenant Karter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12784; -- Lieutenant Jackspring
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12785; -- Sergeant Major Clate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12786; -- Guard Quine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12787; -- Guard Hammon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12792; -- Lady Palanseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12800; -- Chimaerok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12801; -- Arcane Chimaerok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12802; -- Chimaerok Devourer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12803; -- Lord Lakmaeran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12807; -- Greshka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12816; -- Xen'Zilla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12818; -- Ruul Snowhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12836; -- Wandering Protector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12837; -- Yama Snowhoof
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12856; -- Ashenvale Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12858; -- Torek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12859; -- Splintertree Raider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12862; -- Warsong Scout
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12863; -- Warsong Runner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12865; -- Ambassador Malcin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12866; -- Myriam Moonsinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12867; -- Kuray'bin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12876; -- Baron Aquanis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12877; -- Ertog Ragetusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12896; -- Silverwing Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12897; -- Silverwing Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12899; -- Axtroz
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 12902; -- Lorgus Jett
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12903; -- Splintertree Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12919; -- Nat Pagle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12920; -- Doctor Gregory Victor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12939; -- Doctor Gustaf VanHowzen
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12941; -- Jase Farlane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12942; -- Leonard Porter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12943; -- Werg Thickblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12944; -- Lokhtos Darkbargainer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12956; -- Zannok Hidepiercer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12957; -- Blimo Gadgetspring
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12958; -- Gigget Zipcoil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12959; -- Nergal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12960; -- Christi Galvanis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12961; -- Kil'Hiwana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 12962; -- Wik'Tar
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 13019; -- Burning Blade Seer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13020; -- Vaelastrasz the Corrupt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13076; -- Dun Morogh Mountaineer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13084; -- Bixi Wobblebonk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13085; -- Myrokos Silentform
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13118; -- Crimson Bodyguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13141; -- Deeprot Stomper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13142; -- Deeprot Tangler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13148; -- Flame of Ragnaros
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13157; -- Makasgar
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13158; -- Lieutenant Sanders
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13159; -- James Clark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13177; -- Vahgruk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13217; -- Thanthaldis Snowgleam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13219; -- Jekyll Flandring
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13220; -- Layo Starstrike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13277; -- Dahne Pierce
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13278; -- Duke Hydraxis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13282; -- Noxxion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13283; -- Lord Tony Romano
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13321; -- Frog
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13322; -- Hydraxian Honor Guard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13323; -- Subterranean Diemetradon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13417; -- Sagorne Creststrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13418; -- Kaymard Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13420; -- Penney Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13429; -- Nardstrum Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13430; -- Jaycrue Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13433; -- Wulmort Jinglepocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13434; -- Macey Jinglepocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13444; -- Greatfather Winter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13445; -- Great-father Winter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13476; -- Balai Lok'Wein
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13477; -- Noxxion Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13516; -- Frostwolf Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13517; -- Seasoned Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13518; -- Veteran Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13519; -- Champion Outrunner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13520; -- Stormpike Ranger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13521; -- Seasoned Ranger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13522; -- Veteran Ranger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13523; -- Champion Ranger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13533; -- Spewed Larva
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13596; -- Rotgrip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13599; -- Stolid Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13601; -- Tinkerer Gizlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13602; -- The Abominable Greench
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13619; -- Gizlock's Dummy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13620; -- Gizlock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13636; -- Strange Snowman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13656; -- Willow
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13697; -- Cavindra
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13698; -- Keeper Marandis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13699; -- Selendra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13717; -- Centaur Pariah
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13718; -- The Nameless Prophet
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 13737; -- Marandis' Sister
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13743; -- Corrupt Force of Nature
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13776; -- Corporal Teeka Bloodsnarl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13777; -- Sergeant Durgen Stormpike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13816; -- Prospector Stonehewer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13817; -- Voggah Deathgrip
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13836; -- Burning Blade Nightmare
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13837; -- Captured Stallion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13839; -- Royal Dreadguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13840; -- Warmaster Laggrond
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13841; -- Lieutenant Haggerdin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13842; -- Frostwolf Ambassador Rokhstrom
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13843; -- Lieutenant Rotimer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13876; -- Mekgineer Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13896; -- Scalebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13917; -- Izzy Coppergrab
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13936; -- Ravenholdt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13976; -- Tortured Drake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 13996; -- Blackwing Technician
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14020; -- Chromaggus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14123; -- Steeljaw Snapper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14182; -- Bounty Hunter Kolark
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14183; -- Artilleryman Sheldonore
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14222; -- Araga
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14230; -- Burgle Eye
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14234; -- Hayoc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14266; -- Shanda the Spinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14267; -- Emogg the Crusher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14268; -- Lord Condar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14270; -- Squiddic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14271; -- Ribchaser
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 14272; -- Snarlflare
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14273; -- Boulderheart
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14274; -- Winterax Tracker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14276; -- Scargil
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 14277; -- Lady Zephris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14278; -- Ro'Bark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14280; -- Big Samras
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14284; -- Stormpike Battleguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14285; -- Frostwolf Battleguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14301; -- Brinna Valanaar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14304; -- Kor'kron Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14306; -- Eskhandar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14307; -- Black Drakonid Spawner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14309; -- Red Drakonid Spawner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14310; -- Green Drakonid Spawner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14311; -- Bronze Drakonid Spawner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14312; -- Blue Drakonid Spawner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14324; -- Cho'Rush the Observer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14339; -- Death Howl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14347; -- Highlord Demitrian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14348; -- Earthcaller Franzahl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14355; -- Azj'Tordin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14356; -- Sawfin Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14357; -- Lake Thresher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14373; -- Sage Korolusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14374; -- Scholar Runethorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14375; -- Scout Stronghand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14376; -- Scout Manslayer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14377; -- Scout Tharr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14378; -- Huntress Skymane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14379; -- Huntress Ravenoak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14380; -- Huntress Leafrunner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14387; -- Lothos Riftwaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14392; -- Overlord Runthak
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14394; -- Major Mattingly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14395; -- Griniblix the Spectator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14402; -- Seeker Cromwell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14403; -- Seeker Nahr
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14404; -- Seeker Thompson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14422; -- BRD Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14425; -- Gnawbone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14426; -- Harb Foulmountain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14428; -- Uruson
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14430; -- Duskstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14431; -- Fury Shelda
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14432; -- Threggil
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14436; -- Mor'zul Bloodbringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14437; -- Gorzeeki Wildeyes
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14440; -- Hunter Sagewind
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14441; -- Hunter Ragetotem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14442; -- Hunter Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14443; -- Doomguard Tap Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14446; -- Fingat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14450; -- Orphan Matron Nightingale
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14451; -- Orphan Matron Battlewail
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14455; -- Whirling Invader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14458; -- Watery Invader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14460; -- Blazing Invader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14463; -- Daio the Decrepit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14467; -- Kroshius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14469; -- Niby the Almighty
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14470; -- Impsy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14472; -- Gretheer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14473; -- Lapress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14477; -- Grubthor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14478; -- Huricanian
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14479; -- Twilight Lord Everun
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 14487; -- Gluggle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14493; -- Priest Epic Event Caller
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14496; -- Stormwind Orphan
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 14497; -- Shellene
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14498; -- Tosamina
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14499; -- Horde Orphan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14501; -- Warlock Mount Ritual Mob Type 3 WHERE `Entry` = Infernal (DND)
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14506; -- Lord Hel'nurath
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14507; -- High Priest Venoxis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14508; -- Short John Mithril
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14509; -- High Priest Thekal
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14510; -- High Priestess Mar'li
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14511; -- Shadowed Spirit
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14515; -- High Priestess Arlokk
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14516; -- Death Knight Darkreaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14517; -- High Priestess Jeklik
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14518; -- Aspect of Banality
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14521; -- Aspect of Shadow
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14522; -- Ur'dan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14523; -- Ulathek
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14527; -- Simone the Inconspicuous
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14528; -- Precious
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14529; -- Franklin the Friendly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14531; -- Artorius the Amiable
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14532; -- Razzashi Venombrood
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14536; -- Nelson the Nice
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14539; -- Swift Timber Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14540; -- Swift Brown Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14541; -- Swift Gray Wolf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14542; -- Great White Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14543; -- Swift Olive Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14544; -- Swift Orange Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14545; -- Swift Blue Raptor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14546; -- Swift Brown Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14547; -- Swift White Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14548; -- Swift Gray Ram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14549; -- Great Brown Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14550; -- Great Gray Kodo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14551; -- Swift Yellow Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14552; -- Swift White Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14553; -- Swift Green Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14554; -- Swift Stripped Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14555; -- Swift Mistsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14556; -- Swift Frostsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14558; -- Purple Skeletal Warhorse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14559; -- Swift Palomino
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14560; -- Swift White Steed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14561; -- Swift Brown Steed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14562; -- Swift Blue Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14563; -- Swift Red Mechanostrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14567; -- Derotain Mudsipper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14601; -- Ebonroc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14602; -- Swift Stormsaber
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14606; -- Drakonid Corpse Trigger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14621; -- Overseer Maltorius
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14622; -- Thorium Brotherhood Lookout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14623; -- Warsong Gulch Battlemaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14624; -- Master Smith Burninate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14625; -- Overseer Oilfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14626; -- Taskmaster Scrange
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14627; -- Hansel Heavyhands
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14628; -- Evonice Sootsmoker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14629; -- Loggerhead Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14630; -- Leatherback Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14631; -- Olive Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14632; -- Hawksbill Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14633; -- Albino Snapjaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14634; -- Lookout Captain Lolo Longstriker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14635; -- Sleepy Dark Iron Worker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14636; -- Chambermaid Pillaclencher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14637; -- Zorbin Fandazzle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14646; -- Stratholme Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14661; -- Stinglasher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14681; -- Transporter Malfunction
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14682; -- Sever
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14686; -- Lady Falther'ess
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14690; -- Revanchion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14693; -- Scorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14715; -- Silverwing Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14717; -- Horde Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14718; -- Horde Laborer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14720; -- High Overlord Saurfang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14721; -- Field Marshal Afrasiabi
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14722; -- Clavicus Knavingham
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14723; -- Mistina Steelshield
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14724; -- Bubulo Acerbus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14725; -- Raedon Duskstriker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14726; -- Rashona Straglash
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14727; -- Vehena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14728; -- Rumstag Proudstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14729; -- Ralston Farnsley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14730; -- Revantusk Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14731; -- Lard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14733; -- Sentinel Farsong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14734; -- Revantusk Drummer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14736; -- Primal Torntusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14737; -- Smith Slagtree
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14738; -- Otho Moji'ko
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14739; -- Mystic Yayo'jin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14740; -- Katoom the Angler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14741; -- Huntsman Markhor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14742; -- Zap Farflinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14743; -- Jhordy Lapforge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14750; -- Gurubashi Bat Rider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14753; -- Illiyana Moonblaze
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14754; -- Kelm Hargunth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14757; -- Elder Torntusk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14758; -- Zul'Gurub Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14781; -- Captain Shatterskull
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14821; -- Razzashi Raptor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14822; -- Sayge
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14823; -- Silas Darkmoon
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14825; -- Withered Mistress
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14826; -- Sacrificed Troll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14827; -- Burth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14828; -- Gelvas Grimegate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14829; -- Yebb Neblegear
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14832; -- Kerri Hicks
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14834; -- Hakkar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14841; -- Rinling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14844; -- Sylannia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14845; -- Stamp Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14846; -- Lhara
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14847; -- Professor Thaddeus Paleo
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14849; -- Darkmoon Faire Carnie
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14850; -- Gruk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14857; -- Erk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14859; -- Guard Taruc
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14860; -- Flik
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14861; -- Blood Steward of Kirtonos
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14862; -- Emissary Roman'khan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14864; -- Khaz Modan Ram
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 14865; -- Felinni
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14866; -- Flik's Frog
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14868; -- Hornsley
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14869; -- Pygmy Cockatrice
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14871; -- Morja
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14872; -- Trok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14873; -- Okla
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14874; -- Karu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14875; -- Molthor
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14876; -- Zandalar Headshrinker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14877; -- High Priest Venoxis Transform Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14879; -- Arathi Basin Battlemaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14880; -- Razzashi Skitterer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14881; -- Spider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14882; -- Atal'ai Mistress
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14883; -- Voodoo Slave
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14887; -- Ysondre
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14889; -- Emeriss
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14890; -- Taerar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14892; -- Fang
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14893; -- Guard Kurall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14894; -- Swarm of bees
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14901; -- Peon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14902; -- Jin'rokh the Breaker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14903; -- Al'tabim the All-Seeing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14904; -- Maywiki of Zuldazar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14905; -- Falthir the Sightless
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14908; -- Mogg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14909; -- Pooka
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14910; -- Exzhal
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 14911; -- Zandalar Enforcer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14912; -- Captured Hakkari Zealot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14921; -- Rin'wosho the Trader
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14941; -- High Priestess Jeklik Transform Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14942; -- Kartra Bloodsnarl
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14961; -- Mirvyna Jinglepocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14962; -- Dillord Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14963; -- Gapp Jinglepocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14964; -- Hecht Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14966; -- High Priest Thekal Transform Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14967; -- High Priestess Mar'li Transform Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14968; -- High Priestess Arlokk Transform Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14982; -- Lylandris
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14983; -- Field Marshal Oslight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14984; -- Sergeant Maclear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14990; -- Defilers Emissary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14991; -- League of Arathor Emissary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 14994; -- Zandalarian Event Generator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15006; -- Deze Snowbane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15007; -- Sir Malory Wheeler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15011; -- Wagner Hammerstrike
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15012; -- Javnir Nashak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15021; -- Deathmaster Dwire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15022; -- Deathstalker Mortis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15042; -- Zanza the Restless
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15043; -- Zulian Crocolisk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15067; -- Zulian Stalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15070; -- Vinchaxa
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15076; -- Zandalarian Emissary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15080; -- Servant of the Hand
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15083; -- Hazza'rah
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15085; -- Wushoolay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15091; -- Zul'Gurub Panther Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15103; -- Stormpike Emissary
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15105; -- Warsong Emissary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15109; -- Primal Blessing Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15110; -- Gurubashi Prisoner
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15111; -- Mad Servant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15113; -- Honored Hero
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15115; -- Honored Ancestor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15124; -- Targot Jinglepocket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15125; -- Kosco Copperpinch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15126; -- Rutherford Twing
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15127; -- Samuel Hawke
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15128; -- Defiler Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15130; -- League of Arathor Elite
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15131; -- Qeeju
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15139; -- Gahz'ranka Herald
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15162; -- Scarlet Inquisitor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15164; -- Mulgore Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15165; -- Haughty Modiste
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15168; -- Vile Scarab
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15169; -- Ralo'shan the Eternal Watcher
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15170; -- Rutgar Glyphshaper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15171; -- Frankal Stonebridge
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15172; -- Glibb
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15174; -- Calandrath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15175; -- Khur Hornstriker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15176; -- Vargus
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15177; -- Cloud Skydancer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15178; -- Runk Windtamer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15179; -- Mishta
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15180; -- Baristolth of the Shifting Sands
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15181; -- Commander Mar'alith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15182; -- Vish Kozus
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15183; -- Geologist Larksbane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15184; -- Cenarion Hold Infantry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15185; -- Brood of Nozdormu
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15186; -- Murky
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15187; -- Cenarion Emissary Jademoon
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15188; -- Cenarion Emissary Blackhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15189; -- Beetix Ficklespragg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15190; -- Noggle Ficklespragg
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15191; -- Windcaller Proudhorn
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15192; -- Anachronos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15194; -- Hermit Ortell
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15196; -- Deathclasp
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15200; -- Twilight Keeper Mayna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15201; -- Twilight Flamereaver
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15202; -- Vyral the Vile
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15213; -- Twilight Overlord
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15214; -- Invisible Stalker
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15215; -- Mistress Natalia Mar'alith
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15216; -- Male Ghost
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15217; -- Female Ghost
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15221; -- Frankal Invisible Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15222; -- Rutgar Invisible Trigger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15250; -- Qiraji Slayer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15263; -- The Prophet Skeram
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15270; -- Huum Wildmane
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15276; -- Emperor Vek'lor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15282; -- Aurel Goldleaf
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15293; -- Aendel Windspear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15306; -- Bor Wildmane
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15308; -- Twilight Prophet
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15313; -- Moonkin (Druid - Night Elf)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15314; -- Moonkin (Druid - Tauren)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15315; -- Mylini Frostmoon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15318; -- Hive'Zara Drone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15319; -- Hive'Zara Collector
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15320; -- Hive'Zara Soldier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15323; -- Hive'Zara Sandstalker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15324; -- Qiraji Gladiator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15325; -- Hive'Zara Wasp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15327; -- Hive'Zara Stinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15328; -- Darkmoon Steam Tonk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15333; -- Silicate Feeder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15335; -- Flesh Hunter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15336; -- Hive'Zara Tail Lasher
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15338; -- Obsidian Destroyer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15339; -- Ossirian the Unscarred
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15340; -- Moam
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15341; -- General Rajaxx
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15343; -- Qiraji Swarmguard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15344; -- Swarmguard Needler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15348; -- Kurinnaxx
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15350; -- Horde Warbringer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15351; -- Alliance Brigadier General
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15355; -- Anubisath Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15364; -- RC Mortar Tank <PH>
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15369; -- Ayamiss the Hunter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15370; -- Buru the Gorger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15373; -- Halloween Pirate Captain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15374; -- Halloween Undead Pirate
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15375; -- Halloween Pirate Female
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15376; -- Halloween Male Ghost
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15377; -- Halloween Female Ghost
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15380; -- Arygos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15384; -- OLDWorld Trigger (DO NOT DELETE)
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15385; -- Colonel Zerran
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15386; -- Major Yeggeth
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15387; -- Qiraji Warrior
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15388; -- Major Pakkon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15389; -- Captain Drenn
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15390; -- Captain Xurrem
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15391; -- Captain Qeez
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15392; -- Captain Tuubid
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15394; -- Hero of the Horde
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15395; -- Nafien
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15410; -- Anachronos Dragon Form
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15411; -- Arygos Dragon Form
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15412; -- Caelestrasz Dragon Form
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15413; -- Merithra Dragon Form
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15419; -- Kania
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15425; -- Debug Point
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15426; -- Ahn'Qiraj Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15427; -- Merithra's Wake
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15436; -- Mortar Sergeant Stouthammer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15441; -- Ironforge Brigade Rifleman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15442; -- Ironforge Brigade Footman
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15443; -- Janela Stouthammer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15444; -- Arcanist Nozzlespring
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15449; -- Hive'Zora Abomination
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15454; -- Anachronos Quest Trigger Invisible
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15461; -- Shrieker Scarab
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15462; -- Spitting Scarab
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15476; -- Scorpion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15481; -- Spirit of Azuregos
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15498; -- Windcaller Yessendra
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15499; -- Warden Haro
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15500; -- Keyl Swiftclaw
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15505; -- Canal Frenzy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15507; -- Buru the Gorger Transform Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15514; -- Buru Egg
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15520; -- O'Reily
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15521; -- Hive'Zara Hatchling
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15527; -- Mana Fiend
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15540; -- Windcaller Kaldon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15541; -- Twilight Marauder Morna
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15542; -- Twilight Marauder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15545; -- Cenarion Outrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15546; -- Hive'Zara Swarmer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15549; -- Elder Morndeep
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15552; -- Doctor Weavil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15553; -- Doctor Weavil's Flying Machine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15555; -- Hive'Zara Larva
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15556; -- Elder Splitrock
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15557; -- Elder Rumblerock
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15558; -- Elder Silvervein
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15560; -- Elder Stonefort
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15562; -- Elder Hammershout
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15563; -- Elder Bellowrage
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15564; -- Elder Darkcore
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15565; -- Elder Stormbrow
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15566; -- Elder Snowcrown
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15568; -- Elder Graveborn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15569; -- Elder Goldwell
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15570; -- Elder Primestone
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15572; -- Elder Runetotem
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15573; -- Elder Ragetotem
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15574; -- Elder Stonespire
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15575; -- Elder Bloodhoof
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15576; -- Elder Winterhoof
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15577; -- Elder Skychaser
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15578; -- Elder Wildmane
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15579; -- Elder Darkhorn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15580; -- Elder Proudhorn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15581; -- Elder Grimtotem
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15582; -- Elder Windtotem
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15583; -- Elder Thunderhorn
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15584; -- Elder Skyseer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15585; -- Elder Dawnstrider
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15586; -- Elder Dreamseer
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15587; -- Elder Mistwalker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15588; -- Elder High Mountain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15590; -- Ossirian Crystal Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15591; -- Minion of Weavil
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15592; -- Elder Windrun
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15593; -- Elder Starsong
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15594; -- Elder Moonstrike
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15595; -- Elder Moonstrike
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15596; -- Elder Starglade
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15597; -- Elder Moonwarden
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15598; -- Elder Bladeswift
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15599; -- Elder Bladesing
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15600; -- Elder Skygleam
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15601; -- Elder Starweave
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15602; -- Elder Meadowrun
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15603; -- Elder Nightwind
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15604; -- Elder Morningdew
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15605; -- Elder Riversong
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15606; -- Elder Brightspear
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15609; -- Cenarion Scout Landion
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15610; -- Cenarion Scout Azenel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15611; -- Cenarion Scout Jalia
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15612; -- Krug Skullsplit
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15613; -- Merok Longstride
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15614; -- J.D. Shadesong
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15615; -- Shadow Priestess Shai
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15616; -- Orgrimmar Legion Grunt
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15617; -- Orgrimmar Legion Axe Thrower
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15620; -- Hive'Regal Hunter-Killer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15623; -- Xandivious
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15624; -- Forest Wisp
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15659; -- Auctioneer Jaxon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15660; -- Eranikus Transformed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15664; -- Metzen the Reindeer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15675; -- Auctioneer Stockton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15676; -- Auctioneer Yarly
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15677; -- Auctioneer Graves
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15678; -- Auctioneer Silva'las
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15679; -- Auctioneer Cazarez
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15681; -- Auctioneer O'reely
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15682; -- Auctioneer Cain
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15683; -- Auctioneer Naxxremis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15684; -- Auctioneer Tricket
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15685; -- Southsea Kidnapper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15686; -- Auctioneer Rhyker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15692; -- Dark Iron Kidnapper
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 15693; -- Jonathan the Revelator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15694; -- Stormwind Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15695; -- Vek Twins Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15705; -- Winter's Little Helper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15710; -- Tiny Snowman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15711; -- Black Qiraji Battle Tank
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15717; -- Ouro Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15719; -- Thunder Bluff Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15721; -- Mechanical Greench
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15722; -- Squire Leoren Mal'derath
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15732; -- Wonderform Operator
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15745; -- Greatfather Winter's Helper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15746; -- Great-father Winter's Helper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15760; -- Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15761; -- Officer Vu'Shalay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15762; -- Officer Lunalight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15763; -- Officer Porterhouse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15764; -- Officer Ironbeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15765; -- Officer Redblade
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15766; -- Officer Maloof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15767; -- Officer Thunderstrider
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15768; -- Officer Gothena
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15769; -- Resonating Crystal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15772; -- Christmas Darkmaster Gandling
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15773; -- Christmas Cannon Master Willey
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15774; -- Christmas Prince Tortheldrin
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15775; -- Christmas Emperor Dagran Thaurissan
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15776; -- Christmas Warchief Rend Blackhand
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15777; -- Christmas War Master Voone
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15778; -- Mouth Tentacle Mount Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15780; -- Human Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15781; -- Human Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15782; -- Dwarf Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15783; -- Dwarf Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15784; -- Night Elf Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15785; -- Troll Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15786; -- Orc Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15787; -- Goblin Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15788; -- Undead Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15789; -- Tauren Female Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15790; -- Undead Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15791; -- Orc Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15792; -- Troll Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15793; -- Tauren Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15794; -- Night Elf Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15795; -- Goblin Male Winter Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15796; -- Christmas Goraluk Anvilcrack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15800; -- Exit Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15801; -- GONG BOY DND DNR
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15805; -- Minor Resonating Crystal
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15809; -- C'Thun Transformation Visual
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15815; -- Qiraji Captain Ka'ark
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15832; -- Father Winter's Helper (BIG) rm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15838; -- Father Winter's Helper (BIG) gf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15863; -- Darkspear Shaman
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15864; -- Valadar Starsong
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15871; -- Elder Bronzebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15878; -- Warcaller Finster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15891; -- Lunar Festival Herald
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15892; -- Lunar Festival Emissary
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15893; -- Lunar Firework Credit Marker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15894; -- Lunar Cluster Credit Marker
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15895; -- Lunar Festival Harbinger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15897; -- Large Spotlight
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15898; -- Lunar Festival Vendor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15901; -- Vanquished Tentacle
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15902; -- Giant Spotlight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15903; -- Sergeant Carnes
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15905; -- Darnassus Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15906; -- Ironforge Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15907; -- Undercity Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15908; -- Orgrimmar Reveler
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15909; -- Fariel Starsong
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15917; -- Lunar Festival Reveler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15922; -- Viscidus Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15933; -- Poison Cloud
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15934; -- Hive'Zara Hornet
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15957; -- Ouro Spawner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15961; -- Lunar Festival Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15972; -- Alterac Valley Battlemaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 15973; -- Naxxramas Template
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15980; -- Naxxramas Cultist
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15981; -- Naxxramas Acolyte
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 15990; -- Kel'Thuzad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16001; -- Aldris Fourclouds
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16002; -- Colara Dean
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16003; -- Deathguard Tor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16004; -- Elenia Haydon
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16005; -- Lieutenant Jocryn Heldric
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16006; -- InCombat Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16007; -- Orok Deathbane
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16008; -- Temma of the Wells
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16009; -- Tormek Stoneriver
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16012; -- Mokvar
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16013; -- Deliana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16014; -- Mux Manascrambler
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16015; -- Vi'el
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16020; -- Mad Scientist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16027; -- Living Poison
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16030; -- Maggot
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16042; -- Lord Valthalak
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16043; -- Magma Lord Bokk
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16044; -- Mor Grayhoof Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16045; -- Isalien Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16046; -- Jarien and Sothos Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16047; -- Kormok Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16048; -- Lord Valthalak Trigger
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16051; -- Snokh Blackspine
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16054; -- Rezznik
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16055; -- Va'jashni
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16058; -- Volida
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16060; -- Gothik the Harvester
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16068; -- Larva
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16069; -- Gurky
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16070; -- Garel Redrock
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16072; -- Tidelord Rrurgaz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16076; -- Tharl Stonebleeder
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16079; -- Theldren Trigger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16080; -- Mor Grayhoof
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16082; -- Naxxramas Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16086; -- Flower Shower
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16090; -- Rousch
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16091; -- Dirk Thunderwood
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16092; -- Silithis Teleporter
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16094; -- Durik
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16096; -- Steamwheedle Bruiser
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16097; -- Isalien
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16100; -- Ysida's Trigger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16101; -- Jarien
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16102; -- Sothos
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16103; -- Spirit of Jarien
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16104; -- Spirit of Sothos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16105; -- Aristan Mottar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16108; -- Fenstad Argyle
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16109; -- Mara Rennick
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16110; -- Annalise Lerent
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16112; -- Korfax WHERE `Entry` = Champion of the Light
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16113; -- Father Inigo Montoy
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16114; -- Scarlet Commander Marjhan
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16115; -- Commander Eligor Dawnbringer
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16116; -- Archmage Angela Dosantos
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16117; -- Plagued Swine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16123; -- Gremnik Rizzlesprang
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16126; -- Unrelenting Rider
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16127; -- Spectral Trainee
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16129; -- Shadow Fissure
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16131; -- Rohan the Assassin
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16132; -- Huntsman Leopold
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16133; -- Mataus the Wrathcaster
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16134; -- Rimblat Earthshatter
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16135; -- Rayne
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16137; -- Naxxramas Military Sub-Boss Trigger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16163; -- Deathknight Cavalier
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16165; -- Necro Knight
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16166; -- Theldren Kill Credit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16184; -- Nerubian Overseer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16211; -- Naxxramas Combat Dummy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16212; -- Dispatch Commander Metz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16216; -- Unholy Swords
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16218; -- Tesla Coil
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16225; -- Pack Mule
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16227; -- Bragok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16228; -- Argent Dawn Infantry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16229; -- Injured Argent Dawn Infantry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16256; -- Jessica Chambers
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16281; -- Keeper of the Rolls
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16283; -- Packmaster Stonebruiser
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16284; -- Argent Medic
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16306; -- Scourge Invasion Minion, spawner, Ghost/Ghoul
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16336; -- Scourge Invasion Minion, spawner, Ghost/Skeleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16338; -- Scourge Invasion Minion, spawner, Ghoul/Skeleton
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16356; -- Scourge Invasion Minion, finder
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16368; -- Necropolis Acolyte
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16369; -- Polymorphed Chicken
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16373; -- Polymorphed Rat
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16374; -- Polymorphed Cockroach
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16376; -- Craftsman Wilhelm
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16378; -- Argent Sentry
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16382; -- Patchwork Terror
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16386; -- Necropolis Relay
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16392; -- Captain Armando Ossex
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16398; -- Necropolis Proxy
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16399; -- Bloodsail Traitor
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16400; -- Toxic Tunnel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16401; -- Necropolis
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16416; -- Bronn Fitzwrench
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16417; -- Rumsen Fizzlebrack
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16418; -- Mupsi Shacklefridd
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16419; -- Ghost of Naxxramas
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16420; -- Portal of Shadows
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16421; -- Necropolis health
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16422; -- Skeletal Soldier
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16423; -- Spectral Apparition
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16430; -- Ashbringer Trigger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16437; -- Spectral Spirit
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16438; -- Skeletal Trooper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16439; -- Fairbanks Transformed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16440; -- Highlord Mograine Transform
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16458; -- Innkeeper Faralia
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16506; -- Naxxramas Worshipper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16508; -- Argent Horse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16509; -- Argent Warhorse
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16510; -- Argent Charger
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16512; -- Argent Deathsteed
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16513; -- Argent Deathcharger
UPDATE `creature_template` SET `UnitClass` = 2 WHERE `Entry` = 16543; -- Garon Hutchins
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16592; -- Midsummer Bonfire
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16604; -- Blackwing Spell Marker
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16606; -- Midsummer Bonfire Despawner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16701; -- Spirit of Summer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16775; -- Spirit of Mograine
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16776; -- Spirit of Blaumeux
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16777; -- Spirit of Zeliek
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16778; -- Spirit of Korth'azz
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16781; -- Midsummer Celebrant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16788; -- Festival Flamekeeper
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16817; -- Festival Loremaster
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16818; -- Festival Talespinner
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16979; -- Midsummer Merchant
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16980; -- The Lich King
UPDATE `creature_template` SET `UnitClass` = 8 WHERE `Entry` = 16981; -- Plagued Guardian
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16985; -- Midsummer Merchant Horde Costume
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16986; -- Midsummer Merchant Alliance Costume
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16987; -- Festival Flamekeeper Costume: Tauren
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16988; -- Festival Flamekeeper Costume: Human
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16989; -- Festival Flamekeeper Costume: Troll
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16990; -- Festival Flamekeeper Costume: Dwarf
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 16995; -- Herald of the Lich King
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17003; -- Cinder Elemental
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17038; -- Stormwind Firebreather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17048; -- Ironforge Firebreather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17049; -- Darnassus Firebreather
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17066; -- Ribbon Pole Debug Target
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17068; -- Chief Expeditionary Requisitioner Enkles
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17069; -- Emissary Whitebeard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17070; -- Apothecary Quinard
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17072; -- Emissary Gormok
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17074; -- Cenarion Scout
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17079; -- General Kirika
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17080; -- Marshal Bluewall
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17081; -- Scout Bloodfist
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17082; -- Rifleman Torrig
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17090; -- Silithus Dust Turnin Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17209; -- William Kielar
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17249; -- Landro Longshot
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17598; -- Renn'az
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17688; -- Crown Guard Horde Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17689; -- <TXT>Crown Guard Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17690; -- <TXT>Eastwall Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17691; -- Eastwall Horde Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17696; -- <TXT>Northpass Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17697; -- Northpass Horde Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17698; -- <TXT>Plaguewood Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17699; -- Plaguewood Horde Capture Quest Doodad
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17765; -- Alliance Silithyst Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17766; -- Horde Silithyst Sentinel
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17795; -- Horde Tower Buffer
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 17804; -- Squire Rowe
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `Entry` = 18199; -- Silithus Dust Turnin Quest Doodad Horde

-- By default, we set UnitClass "warrior" for all creatures with undefined UnitClass and no mana
UPDATE `creature_template` SET `UnitClass` = 1 WHERE `UnitClass` = 0 AND `MinLevelMana` = 0 AND `MaxLevelMana` = 0;

-- Marked as fixed the creatures fixed by the previous query
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 100; -- Gruff Swiftbite
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1130; -- Bjarn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1981; -- Dark Iron Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2186; -- Carnivous the Breaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3454; -- Cannoneer Smythe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6173; -- Gazin Tenorm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6390; -- Ulag the Cleaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6412; -- Skeleton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6492; -- Rift Spawn
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11200; -- Summoned Skeleton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14041; -- Haggle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14755; -- Tiny Green Dragon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14756; -- Tiny Red Dragon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15467; -- Omen
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15526; -- Meridith the Mermaiden
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16056; -- Diseased Maggot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16057; -- Rotting Maggot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16095; -- Gnashjaw
