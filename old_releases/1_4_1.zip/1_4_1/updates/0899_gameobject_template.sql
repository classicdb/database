


-- -------------------------

UPDATE `gameobject_template` SET `size`='3' WHERE `entry`='179512';
