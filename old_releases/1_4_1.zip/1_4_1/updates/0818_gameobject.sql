-- Improved quest 308 (Distracting Jarven)
-- Thanks Patman for pointing. This closes #137
UPDATE `gameobject` SET `position_x` = -5607.24, `position_y` = -547.934, `position_z` = 392.985, `orientation` = 0.471239, `rotation2` = 0.69985, `rotation3` = -0.71429 WHERE `id` = 270;
