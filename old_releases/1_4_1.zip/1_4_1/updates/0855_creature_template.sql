
SET @MIZZLE := '14353';

-- -----------------------

UPDATE `creature_template` SET `ModelId1`='14406' WHERE `Entry`=@MIZZLE;
