
-- ----------------------------------

INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes1`, `b2_0_sheath`, `b2_1_flags`, `emote`, `moveflags`, `auras`) VALUES
('11673', '0', '0', '1', '16', '0', '0', '18950');
