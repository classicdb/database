-- Set 4 creatures as usable by new template system since the UnitClass update
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2191; -- Licillin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6866; -- Defias Bodyguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10161; -- Rookery Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12138; -- Lunaclaw
