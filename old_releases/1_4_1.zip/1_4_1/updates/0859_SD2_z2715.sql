-- Complete script for Viscidus - AQ40 
UPDATE creature_template SET ScriptName='npc_glob_of_viscidus' WHERE entry=15667;
