


-- -------------------------------------

UPDATE `creature` SET `position_x`='-3440.111', `position_y`='-4138.4560', `position_z`='11.16662', `orientation`='0.88256250', `spawndist`='1', `MovementType`='1' WHERE `guid`='30812';
UPDATE `creature` SET `position_x`='-3464.859', `position_y`='-4126.0560', `position_z`='17.05344', `orientation`='1.96763800', `spawndist`='1', `MovementType`='1' WHERE `guid`='31137';
UPDATE `creature` SET `position_x`='-3475.719', `position_y`='-4115.6700', `position_z`='17.05912', `orientation`='3.08986400', `spawndist`='1', `MovementType`='1' WHERE `guid`='23512';
UPDATE `creature` SET `position_x`='-3471.299', `position_y`='-4107.6460', `position_z`='17.05888', `orientation`='4.03171100', `spawndist`='1', `MovementType`='1' WHERE `guid`='08457';
UPDATE `creature` SET `position_x`='-3468.549', `position_y`='-4112.4550', `position_z`='17.05681', `orientation`='1.08874800', `spawndist`='1', `MovementType`='1' WHERE `guid`='08458';
