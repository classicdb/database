
-- ----------------

UPDATE `gameobject` SET `position_x`='808.3697', `position_y`='482.1281', `position_z`='37.31820', `orientation`='0', `rotation2`='-0.9996567', `rotation3`='0.02620165' WHERE `guid`='35834';
UPDATE `gameobject` SET `position_x`='380.6145', `position_y`='260.0570', `position_z`='11.43955', `orientation`='0', `rotation2`='-0.4848089', `rotation3`='0.87462010' WHERE `guid`='35832';
