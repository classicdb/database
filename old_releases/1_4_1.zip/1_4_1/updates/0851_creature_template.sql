


-- -----------------------

UPDATE `creature_template` SET `FactionAlliance`='190', `FactionHorde`='190' WHERE `Entry`='2914'; -- Snake
UPDATE `creature_template` SET `FactionAlliance`='31', `FactionHorde`='31' WHERE `Entry`='4075'; -- Rat
UPDATE `creature_template` SET `FactionAlliance`='188', `FactionHorde`='188' WHERE `Entry`='4076'; -- Roach

UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11441'; -- Gordok Brute
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11444'; -- Gordok Mage-Lord
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='13036'; -- Gordok Mastiff
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11448'; -- Gordok Warlock
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11450'; -- Gordok Reaver
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11445'; -- Gordok Captain
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11446'; -- Gordok Spirit
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14351'; -- Gordok Bushwacker
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14385'; -- Doomguard Minion
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14386'; -- Wandering Eye of Kilrogg
UPDATE `creature_template` SET `FactionAlliance`='14', `FactionHorde`='14' WHERE `Entry`='13160'; -- Carrion Swarmer

UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14322'; -- Stomper Kreeg <The Drunk>
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14326'; -- Guard Mol'dar
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14321'; -- Guard Fengus
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14323'; -- Guard Slip'kik
UPDATE `creature_template` SET `FactionAlliance`='1374', `FactionHorde`='1374' WHERE `Entry`='14325'; -- Captain Kromcrush
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='14324'; -- Cho'Rush the Observer
UPDATE `creature_template` SET `FactionAlliance`='45', `FactionHorde`='45' WHERE `Entry`='11501'; -- King Gordok

UPDATE `creature_template` SET `FactionAlliance`='35', `FactionHorde`='35' WHERE `Entry`='14338'; -- Knot Thimblejack
UPDATE `creature_template` SET `FactionAlliance`='35', `FactionHorde`='35' WHERE `Entry`='14353'; -- Mizzle the Crafty
