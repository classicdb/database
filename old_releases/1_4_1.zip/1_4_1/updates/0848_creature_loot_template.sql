
-- ---------------------------------

DELETE FROM `creature_loot_template` WHERE `item`='5796' AND `entry` IN ('4457', '4458', '4459', '4460', '4461');
