
-- -----------------------------

REPLACE INTO `creature_ai_texts` (`entry`, `content_default`, `sound`, `type`, `language`, `emote`, `comment`) VALUES
('-1320', '%s splits into two new Lava Spawns!', '0', '2', '0', '0', 'Lava Spawn - Split Emote');
