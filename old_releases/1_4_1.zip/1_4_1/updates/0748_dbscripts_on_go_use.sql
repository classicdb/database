
DELETE FROM `dbscripts_on_go_use` WHERE `id`='12148'; -- ClassicDB

-- ------------------------------
