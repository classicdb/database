-- Fixed faction of traps in Suppression Room of Blackwing Lair
UPDATE `gameobject_template` SET `faction` = 14 WHERE `entry` = 179784;
