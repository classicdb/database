


-- -------------------------

UPDATE `gameobject` SET `position_x`='491.2043', `position_y`='515.1331', `position_z`='29.467530', `orientation`='0', `rotation2`='0.70710660', `rotation3`='0.7071069', `spawntimesecs`='0', `animprogress`='100' WHERE `id`='177217';
UPDATE `gameobject` SET `position_x`='385.3268', `position_y`='374.2315', `position_z`='-1.343140', `orientation`='0', `rotation2`='0.70710660', `rotation3`='0.7071069', `spawntimesecs`='0', `animprogress`='100' WHERE `id`='177219';
UPDATE `gameobject` SET `position_x`='351.5679', `position_y`='88.67347', `position_z`='-36.39297', `orientation`='0', `rotation2`='0.70710660', `rotation3`='0.7071069', `spawntimesecs`='0', `animprogress`='100' WHERE `id`='179549';
UPDATE `gameobject` SET `position_x`='83.25511', `position_y`='630.5456', `position_z`='-24.63151', `orientation`='0', `rotation2`='-0.3131638', `rotation3`='0.9496992', `spawntimesecs`='0', `animprogress`='100' WHERE `id`='179550';
UPDATE `gameobject` SET `position_x`='50.58631', `position_y`='501.9406', `position_z`='-23.14985', `orientation`='0', `rotation2`='-0.7071066', `rotation3`='0.7071069', `spawntimesecs`='0', `animprogress`='100' WHERE `id`='177221';
