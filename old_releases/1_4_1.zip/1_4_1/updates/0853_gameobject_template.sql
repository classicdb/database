


-- ----------------

UPDATE `gameobject_template` SET `flags`='4' WHERE `entry`='179517';
