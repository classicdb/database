UPDATE creature_template SET armormultiplier = 1 WHERE entry = 30; -- Forest Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 38; -- Defias Thug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 46; -- Murloc Forager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 60; -- Ruklar the Trapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 95; -- Defias Smuggler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 97; -- Riverpaw Runt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 98; -- Riverpaw Taskmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 99; -- Morgaine the Sly
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 113; -- Stonetusk Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 114; -- Harvest Watcher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 115; -- Harvest Reaper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 116; -- Defias Bandit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 117; -- Riverpaw Gnoll
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 118; -- Prowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 119; -- Longsnout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 121; -- Defias Pathstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 124; -- Riverpaw Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 127; -- Murloc Tidehunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 154; -- Greater Fleshripper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 157; -- Goretusk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 171; -- Murloc Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 199; -- Young Fleshripper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 213; -- Starving Dire Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 217; -- Venom Web Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 285; -- Murloc
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 327; -- Goldtooth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 330; -- Princess
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 422; -- Murloc Flesheater
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 423; -- Redridge Mongrel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 426; -- Redridge Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 428; -- Dire Condor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 430; -- Redridge Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 436; -- Blackrock Shadowcaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 440; -- Blackrock Grunt
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 441; -- Black Dragon Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 452; -- Riverpaw Bandit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 453; -- Riverpaw Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 454; -- Young Goretusk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 473; -- Morgan the Collector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 478; -- Riverpaw Outrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 480; -- Rusty Harvest Golem
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 481; -- Defias Footpad
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 500; -- Riverpaw Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 502; -- Benny Blaanco
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 504; -- Defias Trapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 506; -- Sergeant Brashclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 513; -- Murloc Netter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 515; -- Murloc Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 519; -- Slark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 524; -- Rockhide Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 525; -- Mangy Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 539; -- Pygmy Venom Web Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 545; -- Murloc Tidecaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 547; -- Great Goretusk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 548; -- Murloc Minor Tidecaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 550; -- Defias Messenger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 572; -- Leprithus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 573; -- Foe Reaper 4000
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 578; -- Murloc Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 583; -- Defias Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 589; -- Defias Pillager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 590; -- Defias Looter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 594; -- Defias Henchman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 619; -- Defias Conjurer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 623; -- Skeletal Miner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 704; -- Ragged Timber Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 705; -- Ragged Young Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 706; -- Frostmane Troll Whelp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 707; -- Rockjaw Trogg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 708; -- Small Crag Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 712; -- Redridge Thrasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 724; -- Burly Rockjaw Trogg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 732; -- Murloc Lurker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 824; -- Defias Digger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 831; -- Sea Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 832; -- Dust Devil
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 833; -- Coyote Packleader
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 834; -- Coyote
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 846; -- Rotten Ghoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 946; -- Frostmane Novice
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1051; -- Dark Iron Dwarf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1052; -- Dark Iron Saboteur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1053; -- Dark Iron Tunneler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1054; -- Dark Iron Demolitionist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1083; -- Murloc Shorestriker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1109; -- Fleshripper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1115; -- Rockjaw Skullthumper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1116; -- Rockjaw Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1117; -- Rockjaw Bonesnapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1118; -- Rockjaw Backbreaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1121; -- Frostmane Snowstrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1125; -- Crag Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1126; -- Large Crag Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1127; -- Elder Crag Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1131; -- Winter Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1133; -- Starving Winter Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1134; -- Young Wendigo
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1135; -- Wendigo
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1161; -- Stonesplinter Trogg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1162; -- Stonesplinter Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1163; -- Stonesplinter Skullthumper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1164; -- Stonesplinter Bonesnapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1166; -- Stonesplinter Seer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1167; -- Stonesplinter Digger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1169; -- Dark Iron Insurgent
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1174; -- Tunnel Rat Geomancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1175; -- Tunnel Rat Digger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1176; -- Tunnel Rat Forager
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1178; -- Mo'grosh Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1179; -- Mo'grosh Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1180; -- Mo'grosh Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1181; -- Mo'grosh Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1183; -- Mo'grosh Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1185; -- Wood Lurker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1191; -- Mangy Mountain Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1192; -- Elder Mountain Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1193; -- Loch Frenzy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1194; -- Mountain Buzzard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1197; -- Stonesplinter Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1201; -- Snow Leopard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1205; -- Grawmug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1211; -- Leper Gnome
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1216; -- Shore Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1222; -- Dark Iron Sapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1225; -- Ol' Sooty
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1260; -- Great Father Arctikus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1388; -- Vagash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1393; -- Berserk Trogg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1425; -- Grizlak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1426; -- Riverpaw Miner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1504; -- Young Night Web Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1505; -- Night Web Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1506; -- Scarlet Convert
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1507; -- Scarlet Initiate
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1512; -- Duskbat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1525; -- Rotting Dead
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1528; -- Shambling Horror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1530; -- Rotting Ancestor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1531; -- Lost Soul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1532; -- Wandering Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1534; -- Wailing Ancestor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1535; -- Scarlet Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1536; -- Scarlet Missionary
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1537; -- Scarlet Zealot
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1538; -- Scarlet Friar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1539; -- Scarlet Neophyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1540; -- Scarlet Vanguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1543; -- Vile Fin Puddlejumper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1549; -- Ravenous Darkhound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1555; -- Vicious Night Web Spider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1654; -- Gregor Agamand
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1658; -- Captain Dargol
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1660; -- Scarlet Bodyguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1665; -- Captain Melrache
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1669; -- Defias Profiteer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1674; -- Rot Hide Gnoll
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1688; -- Night Web Matriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1693; -- Loch Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1718; -- Rockjaw Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1725; -- Defias Watchman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1726; -- Defias Magician
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1727; -- Defias Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1766; -- Mottled Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1767; -- Vile Fin Shredder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1768; -- Vile Fin Tidehunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1769; -- Moonrage Whitescalp
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1770; -- Moonrage Darkrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1772; -- Rot Hide Gladerunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1773; -- Rot Hide Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1779; -- Moonrage Glutton
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1780; -- Moss Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1781; -- Mist Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1782; -- Moonrage Darksoul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1865; -- Ravenclaw Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1866; -- Ravenclaw Slave
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1867; -- Dalaran Apprentice
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1868; -- Ravenclaw Servant
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1869; -- Ravenclaw Champion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1889; -- Dalaran Wizard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1908; -- Vile Fin Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1909; -- Vile Fin Lakestalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1912; -- Dalaran Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1913; -- Dalaran Warder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1914; -- Dalaran Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1915; -- Dalaran Conjuror
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1916; -- Stephen Bhartec
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1919; -- Samuel Fipps
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1922; -- Gray Forest Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1923; -- Bloodsnout Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1924; -- Moonrage Bloodhowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1939; -- Rot Hide Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1940; -- Rot Hide Plague Weaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1941; -- Rot Hide Graverobber
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1942; -- Rot Hide Savage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1946; -- Lillith Nefara
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1953; -- Lake Skulker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1955; -- Lake Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1956; -- Elder Lake Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1957; -- Vile Fin Shorecreeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1958; -- Vile Fin Tidecaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1961; -- Mangeclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1971; -- Ivar the Foul
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1972; -- Grimson the Pale
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1974; -- Ravenclaw Drudger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1983; -- Nightlash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1985; -- Thistle Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1989; -- Grellkin
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1993; -- Greenpaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1996; -- Strigid Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 1997; -- Strigid Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2000; -- Webwood Silkspinner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2006; -- Gnarlpine Ursa
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2009; -- Gnarlpine Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2010; -- Gnarlpine Defender
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2011; -- Gnarlpine Augur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2012; -- Gnarlpine Pathfinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2013; -- Gnarlpine Avenger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2014; -- Gnarlpine Totemic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2015; -- Bloodfeather Harpy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2019; -- Bloodfeather Fury
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2020; -- Bloodfeather Wind Witch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2021; -- Bloodfeather Matriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2025; -- Timberling Bark Ripper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2027; -- Timberling Trampler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2029; -- Timberling Mire Beast
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2030; -- Elder Timberling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2034; -- Feral Nightsaber
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2038; -- Lord Melenas
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2039; -- Ursal the Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2043; -- Nightsaber Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2069; -- Moonstalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2071; -- Moonstalker Matriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2103; -- Dragonmaw Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2149; -- Dark Iron Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2152; -- Gnarlpine Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2158; -- Gravelflint Scout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2159; -- Gravelflint Bonesnapper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2166; -- Oakenscowl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2167; -- Blackwood Pathfinder
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2168; -- Blackwood Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2170; -- Blackwood Ursa
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2171; -- Blackwood Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2172; -- Strider Clutchmother
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2173; -- Reef Frenzy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2179; -- Stormscale Wave Rider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2181; -- Stormscale Myrmidon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2182; -- Stormscale Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2184; -- Lady Moongazer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2190; -- Wild Grell
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2192; -- Firecaller Radison
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2201; -- Greymist Raider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2202; -- Greymist Coastrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2203; -- Greymist Seer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2204; -- Greymist Netter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2205; -- Greymist Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2206; -- Greymist Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2207; -- Greymist Oracle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2208; -- Greymist Tidehunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2212; -- Deth'ryll Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2231; -- Pygmy Tide Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2233; -- Encrusted Tide Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2235; -- Reef Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2237; -- Moonstalker Sire
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2252; -- Crushridge Ogre
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2253; -- Crushridge Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2254; -- Crushridge Mauler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2255; -- Crushridge Mage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2256; -- Crushridge Enforcer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2257; -- Mug'thol
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2287; -- Crushridge Warmonger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2304; -- Captain Ironhill
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2321; -- Foreststrider Fledgling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2322; -- Foreststrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2323; -- Giant Foreststrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2324; -- Blackwood Windtalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2336; -- Dark Strand Fanatic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2338; -- Twilight Disciple
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2339; -- Twilight Thug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2344; -- Dun Garok Mountaineer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2345; -- Dun Garok Rifleman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2346; -- Dun Garok Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2416; -- Crushridge Plunderer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2421; -- Muckrake
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2422; -- Glommus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2541; -- Lord Sakrasis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2588; -- Syndicate Prowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2645; -- Vilebranch Shadow Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2646; -- Vilebranch Blood Drinker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2681; -- Vilebranch Raiding Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2773; -- Or'Kalar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2922; -- Servo
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2952; -- Bristleback Quilboar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2953; -- Bristleback Shaman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2955; -- Plainstrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2957; -- Elder Plainstrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2958; -- Prairie Wolf
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2959; -- Prairie Stalker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2960; -- Prairie Wolf Alpha
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2961; -- Mountain Cougar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2962; -- Windfury Harpy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2963; -- Windfury Wind Witch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2964; -- Windfury Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2965; -- Windfury Matriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2966; -- Battleboar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2967; -- Galak Centaur
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2968; -- Galak Outrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2975; -- Venture Co. Hireling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2976; -- Venture Co. Laborer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2978; -- Venture Co. Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2979; -- Venture Co. Supervisor
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2989; -- Bael'dun Digger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2990; -- Bael'dun Appraiser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 2994; -- Ancestral Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3035; -- Flatland Cougar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3051; -- Supervisor Fizsprocket
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3056; -- Ghost Howl
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3068; -- Mazzranache
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3098; -- Mottled Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3105; -- Makrura Snapclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3108; -- Encrusted Surf Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3110; -- Dreadmaw Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3113; -- Razormane Dustrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3114; -- Razormane Battleguard
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3117; -- Dustwind Savage
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3121; -- Durotar Tiger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3122; -- Bloodtalon Taillasher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3123; -- Bloodtalon Scythemaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3125; -- Clattering Scorpid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3127; -- Venomtail Scorpid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3192; -- Lieutenant Benedict
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3195; -- Burning Blade Thug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3196; -- Burning Blade Neophyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3197; -- Burning Blade Fanatic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3198; -- Burning Blade Apprentice
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3199; -- Burning Blade Cultist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3206; -- Voodoo Troll
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3225; -- Corrupted Mottled Boar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3227; -- Corrupted Bloodtalon Scythemaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3228; -- Corrupted Surf Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3232; -- Bristleback Interloper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3240; -- Stormsnout
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3241; -- Savannah Patriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3242; -- Zhevra Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3243; -- Savannah Highmane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3244; -- Greater Plainstrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3245; -- Ornery Plainstrider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3248; -- Barrens Giraffe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3255; -- Sunscale Screecher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3256; -- Sunscale Scytheclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3257; -- Ishamuhale
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3258; -- Bristleback Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3260; -- Bristleback Water Seeker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3261; -- Bristleback Thornweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3263; -- Bristleback Geomancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3265; -- Razormane Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3266; -- Razormane Defender
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3267; -- Razormane Water Seeker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3268; -- Razormane Thornweaver
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3269; -- Razormane Geomancer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3271; -- Razormane Mystic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3276; -- Witchwing Harpy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3277; -- Witchwing Roguefeather
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3278; -- Witchwing Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3279; -- Witchwing Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3280; -- Witchwing Windcaller
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3282; -- Venture Co. Mercenary
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3284; -- Venture Co. Drudger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3285; -- Venture Co. Peon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3379; -- Burning Blade Bruiser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3380; -- Burning Blade Acolyte
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3381; -- Southsea Brigand
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3382; -- Southsea Cannoneer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3394; -- Barak Kodobane
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3395; -- Verog the Dervish
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3396; -- Hezrul Bloodmark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3415; -- Savannah Huntress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3416; -- Savannah Matriarch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3425; -- Savannah Prowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3426; -- Zhevra Charger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3445; -- Supervisor Lugwizzle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3455; -- Cannoneer Whessan
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3461; -- Oasis Snapjaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3463; -- Wandering Barrens Giraffe
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3467; -- Baron Longshore
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3470; -- Rathorian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3475; -- Echeyakee
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3503; -- Silithid Protector
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3535; -- Blackmoss the Fetid
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3566; -- Flatland Prowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3577; -- Dalaran Brewmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3619; -- Ghost Saber
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3630; -- Deviate Coiler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3631; -- Deviate Stinglash
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3632; -- Deviate Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3633; -- Deviate Slayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3638; -- Devouring Ectoplasm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3641; -- Deviate Lurker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3662; -- Delmanis the Hated
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3667; -- Anaya Dawnrunner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3695; -- Grimclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3712; -- Wrathtail Razortail
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3713; -- Wrathtail Wave Rider
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3715; -- Wrathtail Sea Witch
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3717; -- Wrathtail Sorceress
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3721; -- Mystlash Hydra
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3725; -- Dark Strand Cultist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3730; -- Dark Strand Excavator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3733; -- Forsaken Herbalist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3734; -- Forsaken Thug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3737; -- Saltspittle Puddlejumper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3739; -- Saltspittle Warrior
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3812; -- Clattering Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3816; -- Wild Buck
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3823; -- Ghostpaw Runner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3988; -- Venture Co. Operator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3989; -- Venture Co. Logger
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 3991; -- Venture Co. Deforester
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4001; -- Windshear Tunnel Rat
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4005; -- Deepmoss Creeper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4006; -- Deepmoss Webspinner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4008; -- Cliff Stormer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4011; -- Young Pridewing
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4061; -- Mirkfallon Dryad
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4065; -- Blackrock Sentry
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4127; -- Hecklefang Hyena
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4129; -- Hecklefang Snarler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4263; -- Deepmoss Hatchling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4409; -- Gatekeeper Kordurus
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4416; -- Defias Strip Miner
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4462; -- Blackrock Hunter
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4464; -- Blackrock Gladiator
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4468; -- Jade Sludge
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4469; -- Emerald Ooze
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 4788; -- Fallenroot Satyr
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5053; -- Deviate Crocolisk
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5327; -- Coast Crawl Snapclaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5328; -- Coast Crawl Deepseer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5622; -- Ongeku
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5823; -- Death Flayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5826; -- Geolord Mottle
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5829; -- Snort the Heckler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5836; -- Engineer Whirleygig
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5837; -- Stonearm
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5838; -- Brokespear
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5863; -- Geopriest Gukk'rok
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 5865; -- Dishu
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6020; -- Slimeshell Makrura
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6033; -- Lake Frenzy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6093; -- Dead-Tooth Jack
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6113; -- Vejrek
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6123; -- Dark Iron Spy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6133; -- Shade of Elura
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6523; -- Dark Iron Rifleman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6606; -- Overseer Glibby
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6846; -- Defias Dockmaster
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6909; -- Sethir the Ancient
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 6927; -- Defias Dockworker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7015; -- Flagglemurk the Cruel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7017; -- Lord Sinslayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7175; -- Stonevault Ambusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7734; -- Ilifar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7735; -- Felcular
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7897; -- Alarm-a-bomb 2600
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 7903; -- Jewel
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8023; -- Sharpbeak
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8236; -- Muck Frenzy
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 8437; -- Hakkari Minion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9336; -- Boss Copperplug
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9545; -- Grim Patron
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9547; -- Guzzling Patron
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 9696; -- Bloodaxe Worg
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10261; -- Burning Felhound
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10356; -- Bayne
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10358; -- Fellicent's Shade
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10373; -- Xabraxxis
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10375; -- Spire Spiderling
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10391; -- Skeletal Berserker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10581; -- Young Arikara
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 10947; -- Darrowshire Betrayer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11054; -- Crimson Rifleman
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11360; -- Zulian Cub
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11387; -- Sandfury Speaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11389; -- Bloodscalp Speaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11390; -- Skullsplitter Speaker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11562; -- Drysnap Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11563; -- Drysnap Pincer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11685; -- Maraudine Priest
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11713; -- Blackwood Tracker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11714; -- Marosh the Devious
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11721; -- Hive'Ashi Worker
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11858; -- Grundig Darkcloud
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11910; -- Grimtotem Ruffian
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11911; -- Grimtotem Mercenary
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11912; -- Grimtotem Brute
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 11921; -- Besseleth
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12319; -- Burning Blade Toxicologist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12320; -- Burning Blade Crusher
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12321; -- Stormscale Toxicologist
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12347; -- Enraged Reef Crawler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12431; -- Gorefang
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 12579; -- Bloodfury Ripper
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13157; -- Makasgar
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13158; -- Lieutenant Sanders
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 13159; -- James Clark
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14224; -- 7:XT
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14269; -- Seeker Aqualon
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14270; -- Squiddic
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14271; -- Ribchaser
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14273; -- Boulderheart
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14429; -- Grimmaw
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 14489; -- Scourge Archer
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15101; -- Zulian Prowler
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15117; -- Chained Spirit
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15172; -- Glibb
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 15317; -- Qiraji Scorpion
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16427; -- Soldier of the Frozen Wastes
UPDATE creature_template SET armormultiplier = 1 WHERE entry = 16429; -- Soul Weaver
