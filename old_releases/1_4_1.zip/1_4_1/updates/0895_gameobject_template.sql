


-- -------------------------

UPDATE `gameobject_template` SET `faction`='0' WHERE `entry`='179549';
