


-- -------------------------------------

UPDATE `creature` SET `position_x`='-2890.217', `position_y`='-3427.3110', `position_z`='40.13894', `orientation`='3.33208500', `spawndist`='1', `MovementType`='1' WHERE `guid`='33895';
UPDATE `creature` SET `position_x`='-2885.137', `position_y`='-3434.4910', `position_z`='40.13694', `orientation`='2.89824200', `spawndist`='1', `MovementType`='1' WHERE `guid`='33917';
UPDATE `creature` SET `position_x`='-2885.085', `position_y`='-3419.2660', `position_z`='48.02174', `orientation`='1.74031200', `spawndist`='1', `MovementType`='1' WHERE `guid`='31322';
UPDATE `creature` SET `position_x`='-2882.128', `position_y`='-3433.5160', `position_z`='53.84687', `orientation`='6.01700900', `spawndist`='1', `MovementType`='1' WHERE `guid`='31323';
UPDATE `creature` SET `position_x`='-2895.764', `position_y`='-3429.3700', `position_z`='59.45377', `orientation`='4.12601600', `spawndist`='1', `MovementType`='1' WHERE `guid`='31324';
UPDATE `creature` SET `position_x`='-2891.701', `position_y`='-3420.8070', `position_z`='75.22581', `orientation`='2.79531600', `spawndist`='1', `MovementType`='1' WHERE `guid`='31326';
UPDATE `creature` SET `position_x`='-2892.788', `position_y`='-3433.1530', `position_z`='75.22582', `orientation`='3.13859600', `spawndist`='1', `MovementType`='1' WHERE `guid`='31327';
UPDATE `creature` SET `position_x`='-2896.232', `position_y`='-3349.9230', `position_z`='31.42304', `orientation`='1.63860700', `spawndist`='1', `MovementType`='1' WHERE `guid`='31274';
UPDATE `creature` SET `position_x`='-2891.220', `position_y`='-3344.7020', `position_z`='32.34992', `orientation`='2.97209500', `spawndist`='1', `MovementType`='1' WHERE `guid`='31271';
UPDATE `creature` SET `position_x`='-2889.718', `position_y`='-3337.9230', `position_z`='32.47049', `orientation`='5.58505300', `spawndist`='1', `MovementType`='1' WHERE `guid`='31268';
UPDATE `creature` SET `position_x`='-3093.748', `position_y`='-3214.6560', `position_z`='33.97084', `orientation`='1.74532900', `spawndist`='1', `MovementType`='1' WHERE `guid`='31273';
UPDATE `creature` SET `position_x`='-3101.218', `position_y`='-3211.5910', `position_z`='33.96617', `orientation`='0.06981317', `spawndist`='1', `MovementType`='1' WHERE `guid`='31262';
UPDATE `creature` SET `position_x`='-3006.095', `position_y`='-3244.0720', `position_z`='34.71600', `orientation`='0.45505880', `spawndist`='1', `MovementType`='1' WHERE `guid`='31434';
UPDATE `creature` SET `position_x`='-2997.980', `position_y`='-3249.8850', `position_z`='34.80450', `orientation`='1.69891700', `spawndist`='1', `MovementType`='1' WHERE `guid`='31437';
