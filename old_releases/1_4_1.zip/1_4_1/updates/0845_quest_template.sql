


-- --------------------

-- Stormwind
UPDATE `quest_template` SET `ExclusiveGroup`='-7791' WHERE `entry`='7791';
UPDATE `quest_template` SET `ExclusiveGroup`='-7791' WHERE `entry`='7793';
UPDATE `quest_template` SET `ExclusiveGroup`='-7791' WHERE `entry`='7794';
UPDATE `quest_template` SET `PrevQuestId`='7791' WHERE `entry`='7795';

-- Darnassus
UPDATE `quest_template` SET `ExclusiveGroup`='-7792' WHERE `entry`='7792';
UPDATE `quest_template` SET `ExclusiveGroup`='-7792' WHERE `entry`='7798';
UPDATE `quest_template` SET `ExclusiveGroup`='-7792' WHERE `entry`='7799';
UPDATE `quest_template` SET `PrevQuestId`='7792' WHERE `entry`='7800';

-- Ironforge
UPDATE `quest_template` SET `ExclusiveGroup`='-7802' WHERE `entry`='7802';
UPDATE `quest_template` SET `ExclusiveGroup`='-7802' WHERE `entry`='7803';
UPDATE `quest_template` SET `ExclusiveGroup`='-7802' WHERE `entry`='7804';
UPDATE `quest_template` SET `PrevQuestId`='7802' WHERE `entry`='7805';

-- Gnomeregan
UPDATE `quest_template` SET `ExclusiveGroup`='-7807' WHERE `entry`='7807';
UPDATE `quest_template` SET `ExclusiveGroup`='-7807' WHERE `entry`='7808';
UPDATE `quest_template` SET `ExclusiveGroup`='-7807' WHERE `entry`='7809';
UPDATE `quest_template` SET `PrevQuestId`='7807' WHERE `entry`='7811';

-- Undercity
UPDATE `quest_template` SET `ExclusiveGroup`='-7813' WHERE `entry`='7813';
UPDATE `quest_template` SET `ExclusiveGroup`='-7813' WHERE `entry`='7814';
UPDATE `quest_template` SET `ExclusiveGroup`='-7813' WHERE `entry`='7817';
UPDATE `quest_template` SET `PrevQuestId`='7813' WHERE `entry`='7818';

-- Thunder Bluff
UPDATE `quest_template` SET `ExclusiveGroup`='-7820' WHERE `entry`='7820';
UPDATE `quest_template` SET `ExclusiveGroup`='-7820' WHERE `entry`='7821';
UPDATE `quest_template` SET `ExclusiveGroup`='-7820' WHERE `entry`='7822';
UPDATE `quest_template` SET `PrevQuestId`='7820' WHERE `entry`='7823';

-- Orgrimmar
UPDATE `quest_template` SET `ExclusiveGroup`='-7826' WHERE `entry`='7826';
UPDATE `quest_template` SET `ExclusiveGroup`='-7826' WHERE `entry`='7827';
UPDATE `quest_template` SET `ExclusiveGroup`='-7826' WHERE `entry`='7831';
UPDATE `quest_template` SET `PrevQuestId`='7826' WHERE `entry`='7824';

-- Darkspear Trolls
UPDATE `quest_template` SET `ExclusiveGroup`='-7833' WHERE `entry`='7833';
UPDATE `quest_template` SET `ExclusiveGroup`='-7833' WHERE `entry`='7834';
UPDATE `quest_template` SET `ExclusiveGroup`='-7833' WHERE `entry`='7835';
UPDATE `quest_template` SET `PrevQuestId`='7833' WHERE `entry`='7836';
