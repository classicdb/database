


-- ---------------------------------

DELETE FROM `creature_involvedrelation` WHERE `quest`='1318';
