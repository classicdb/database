
-- --------------------

UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE `entry`='349';
