-- ** AQ WAR EFFORT ** --
--  War Effort Commanders Now Have Their Correct Mounts  --
INSERT INTO `creature_template_addon` (`entry`,`mount`) VALUES
(15701,14347),
(15700,14573),
(15458,14346),
(15539,14575);