-- Set The Molten Core -> BRD areatrigger to level 48
UPDATE `areatrigger_teleport` SET `required_level` = 48 WHERE `id` = 2890;
