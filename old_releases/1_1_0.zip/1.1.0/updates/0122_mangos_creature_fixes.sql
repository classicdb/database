-- ** STORMWIND UPDATES ** -- 
-- Melris Malagan updated slanted position --
UPDATE creature SET position_x = '-8823.625000', position_y = '630.498901', position_z = '94.014442', orientation = '3.803255' WHERE guid = '79694';
-- High Sorcerer Andromath Position --
UPDATE creature SET position_x = '-9010.791992', position_y = '876.604919', position_z = '148.617188', orientation = '4.737573' WHERE guid = '90470';
-- Stormwind Royal Guard Position At Entrance of SW Keep GUID = 10508 -- 
UPDATE creature SET position_x = '-8530.925781', position_y = '439.034271', position_z = '105.048889', orientation = '0.652942' WHERE guid = '10508';
-- Angus Stern half-way into the bar --
UPDATE creature SET position_x = '-9080.482422', position_y = '823.150574', position_z = '108.419243', orientation = '0.492888' WHERE guid = '38225';
-- Officer Areyn slanted and out of place --
UPDATE creature SET position_x = '-8759.895508', position_y = '388.538177', position_z = '101.056473', orientation = '0.648394' WHERE guid = '590006';