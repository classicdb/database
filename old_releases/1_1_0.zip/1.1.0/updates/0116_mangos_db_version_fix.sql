-- Updates database version (at last)
UPDATE `db_version` SET `version` = 'Classic DB version 1.1.0 "Public release". For CMaNGOS z2351 and Scriptdev2 z2666';
